import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const UploadProgressTracker = ({
  uploads = [],
  isVisible = false,
  onToggle,
  onRetry,
  onCancel,
  onViewFile,
  position = 'bottom-right'
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeUploads, setActiveUploads] = useState([]);

  useEffect(() => {
    const processing = uploads?.filter(upload => 
      upload?.status === 'uploading' || 
      upload?.status === 'processing' || 
      upload?.status === 'analyzing'
    );
    setActiveUploads(processing);
  }, [uploads]);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'uploading':
        return 'Upload';
      case 'processing':
        return 'Loader';
      case 'analyzing':
        return 'Brain';
      case 'completed':
        return 'CheckCircle';
      case 'error':
        return 'AlertCircle';
      case 'cancelled':
        return 'XCircle';
      default:
        return 'File';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'uploading': case'processing': case'analyzing':
        return 'text-primary';
      case 'completed':
        return 'text-success';
      case 'error':
        return 'text-error';
      case 'cancelled':
        return 'text-muted-foreground';
      default:
        return 'text-muted-foreground';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'processing':
        return 'Processing...';
      case 'analyzing':
        return 'Analyzing content...';
      case 'completed':
        return 'Ready for study';
      case 'error':
        return 'Upload failed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return 'Unknown status';
    }
  };

  const getPositionClasses = () => {
    switch (position) {
      case 'top-right':
        return 'top-20 right-4';
      case 'bottom-right':
        return 'bottom-4 right-4';
      case 'bottom-left':
        return 'bottom-4 left-4';
      default:
        return 'bottom-4 right-4';
    }
  };

  const hasActiveUploads = activeUploads?.length > 0;
  const completedCount = uploads?.filter(u => u?.status === 'completed')?.length;
  const errorCount = uploads?.filter(u => u?.status === 'error')?.length;

  if (!isVisible && !hasActiveUploads) return null;

  return (
    <div className={`fixed ${getPositionClasses()} z-notification`}>
      {/* Compact Indicator */}
      {!isExpanded && hasActiveUploads && (
        <div 
          className="bg-card border border-border rounded-lg shadow-modal p-3 cursor-pointer hover:shadow-elevation-2 transition-shadow"
          onClick={() => setIsExpanded(true)}
        >
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Icon 
                name="Upload" 
                size={20} 
                className="text-primary animate-pulse" 
              />
              {activeUploads?.length > 1 && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-primary text-primary-foreground rounded-full text-xs flex items-center justify-center font-data">
                  {activeUploads?.length}
                </div>
              )}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-card-foreground truncate">
                {activeUploads?.[0]?.fileName || 'Processing files...'}
              </p>
              <div className="flex items-center space-x-2">
                <div className="w-16 bg-muted rounded-full h-1">
                  <div 
                    className="progress-indicator h-1 rounded-full"
                    style={{ width: `${activeUploads?.[0]?.progress || 0}%` }}
                  />
                </div>
                <span className="text-xs font-data text-muted-foreground">
                  {activeUploads?.[0]?.progress || 0}%
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Expanded View */}
      {isExpanded && (
        <div className="bg-card border border-border rounded-lg shadow-modal w-80 max-h-96 overflow-hidden">
          {/* Header */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-heading font-semibold text-card-foreground">
                Upload Progress
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsExpanded(false)}
                className="w-6 h-6"
              >
                <Icon name="X" size={14} />
              </Button>
            </div>
            
            {/* Summary Stats */}
            <div className="flex items-center space-x-4 mt-2 text-xs font-caption">
              <span className="text-primary">
                {activeUploads?.length} processing
              </span>
              {completedCount > 0 && (
                <span className="text-success">
                  {completedCount} completed
                </span>
              )}
              {errorCount > 0 && (
                <span className="text-error">
                  {errorCount} failed
                </span>
              )}
            </div>
          </div>

          {/* Upload List */}
          <div className="max-h-64 overflow-y-auto">
            {uploads?.map((upload) => (
              <UploadItem
                key={upload?.id}
                upload={upload}
                onRetry={onRetry}
                onCancel={onCancel}
                onViewFile={onViewFile}
                getStatusIcon={getStatusIcon}
                getStatusColor={getStatusColor}
                getStatusText={getStatusText}
              />
            ))}
          </div>

          {/* Footer Actions */}
          {uploads?.length > 0 && (
            <div className="p-3 border-t border-border">
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  fullWidth
                  onClick={() => {
                    uploads?.filter(u => u?.status === 'completed')?.forEach(u => onViewFile?.(u));
                  }}
                  disabled={completedCount === 0}
                >
                  View All ({completedCount})
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsExpanded(false)}
                >
                  Minimize
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const UploadItem = ({ 
  upload, 
  onRetry, 
  onCancel, 
  onViewFile, 
  getStatusIcon, 
  getStatusColor, 
  getStatusText 
}) => {
  const isActive = ['uploading', 'processing', 'analyzing']?.includes(upload?.status);
  const canRetry = upload?.status === 'error';
  const canCancel = isActive;
  const canView = upload?.status === 'completed';

  return (
    <div className="p-3 border-b border-border last:border-b-0">
      <div className="flex items-start space-x-3">
        {/* Status Icon */}
        <div className={`flex-shrink-0 ${getStatusColor(upload?.status)}`}>
          <Icon 
            name={getStatusIcon(upload?.status)} 
            size={16} 
            className={isActive ? 'animate-spin' : ''}
          />
        </div>

        {/* File Info */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-card-foreground truncate">
            {upload?.fileName}
          </p>
          <p className="text-xs text-muted-foreground">
            {getStatusText(upload?.status)}
          </p>

          {/* Progress Bar */}
          {isActive && (
            <div className="mt-2">
              <div className="flex items-center justify-between text-xs font-data mb-1">
                <span className="text-muted-foreground">
                  {upload?.currentStep || 'Processing'}
                </span>
                <span className="text-muted-foreground">
                  {upload?.progress}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-1">
                <div 
                  className="progress-indicator h-1 rounded-full"
                  style={{ width: `${upload?.progress}%` }}
                />
              </div>
              {upload?.estimatedTime && (
                <p className="text-xs text-muted-foreground mt-1">
                  ~{upload?.estimatedTime} remaining
                </p>
              )}
            </div>
          )}

          {/* Error Message */}
          {upload?.status === 'error' && upload?.errorMessage && (
            <p className="text-xs text-error mt-1">
              {upload?.errorMessage}
            </p>
          )}

          {/* File Details */}
          {upload?.status === 'completed' && upload?.details && (
            <div className="mt-2 text-xs font-caption text-muted-foreground">
              <div className="flex items-center space-x-3">
                {upload?.details?.pages && (
                  <span>{upload?.details?.pages} pages</span>
                )}
                {upload?.details?.flashcards && (
                  <span>{upload?.details?.flashcards} flashcards</span>
                )}
                {upload?.details?.size && (
                  <span>{upload?.details?.size}</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex-shrink-0 flex items-center space-x-1">
          {canView && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onViewFile(upload)}
              className="w-6 h-6"
            >
              <Icon name="Eye" size={12} />
            </Button>
          )}
          {canRetry && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onRetry(upload)}
              className="w-6 h-6"
            >
              <Icon name="RotateCcw" size={12} />
            </Button>
          )}
          {canCancel && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onCancel(upload)}
              className="w-6 h-6 text-error hover:text-error"
            >
              <Icon name="X" size={12} />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default UploadProgressTracker;