import React from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const StudySessionHeader = ({ 
  currentCard = 1, 
  totalCards = 20, 
  sessionType = 'flashcards',
  onExit,
  onPause,
  onSettings,
  isPaused = false,
  timeElapsed = '05:23',
  streakCount = 7
}) => {
  const progressPercentage = (currentCard / totalCards) * 100;

  const getSessionIcon = () => {
    switch (sessionType) {
      case 'quiz':
        return 'Brain';
      case 'flashcards':
        return 'BookOpen';
      case 'review':
        return 'RotateCcw';
      default:
        return 'BookOpen';
    }
  };

  const getSessionTitle = () => {
    switch (sessionType) {
      case 'quiz':
        return 'Quiz Session';
      case 'flashcards':
        return 'Study Session';
      case 'review':
        return 'Review Session';
      default:
        return 'Study Session';
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-background border-b border-border z-header">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Left Section - Session Info */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name={getSessionIcon()} size={18} color="white" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-sm font-heading font-medium text-foreground">
                {getSessionTitle()}
              </h1>
              <p className="text-xs font-caption text-muted-foreground">
                Card {currentCard} of {totalCards}
              </p>
            </div>
          </div>

          {/* Mobile Progress Info */}
          <div className="sm:hidden">
            <span className="text-sm font-data text-foreground">
              {currentCard}/{totalCards}
            </span>
          </div>
        </div>

        {/* Center Section - Progress Bar */}
        <div className="flex-1 max-w-md mx-4">
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="progress-indicator h-2"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <div className="hidden lg:flex justify-between mt-1 text-xs font-caption text-muted-foreground">
            <span>Progress: {Math.round(progressPercentage)}%</span>
            <span>Time: {timeElapsed}</span>
          </div>
        </div>

        {/* Right Section - Controls */}
        <div className="flex items-center space-x-2">
          {/* Desktop Stats */}
          <div className="hidden lg:flex items-center space-x-4 mr-4">
            <div className="flex items-center space-x-1">
              <Icon name="Flame" size={16} color="var(--color-warning)" />
              <span className="text-sm font-data text-foreground">{streakCount}</span>
            </div>
            <div className="text-sm font-data text-muted-foreground">
              {timeElapsed}
            </div>
          </div>

          {/* Control Buttons */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onPause}
            className="micro-interaction"
          >
            <Icon name={isPaused ? 'Play' : 'Pause'} size={18} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={onSettings}
            className="micro-interaction hidden sm:flex"
          >
            <Icon name="Settings" size={18} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={onExit}
            className="micro-interaction text-destructive hover:text-destructive"
          >
            <Icon name="X" size={18} />
          </Button>
        </div>
      </div>

      {/* Mobile Stats Bar */}
      <div className="lg:hidden bg-muted/50 px-4 py-2 border-t border-border">
        <div className="flex justify-between items-center text-xs font-caption">
          <div className="flex items-center space-x-4">
            <span className="text-muted-foreground">Progress: {Math.round(progressPercentage)}%</span>
            <div className="flex items-center space-x-1">
              <Icon name="Flame" size={14} color="var(--color-warning)" />
              <span className="text-foreground">{streakCount} streak</span>
            </div>
          </div>
          <span className="font-data text-muted-foreground">{timeElapsed}</span>
        </div>
      </div>
    </header>
  );
};

export default StudySessionHeader;