import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const ProgressNotificationSystem = ({
  notifications = [],
  onDismiss,
  onViewDetails,
  position = 'top-right'
}) => {
  const [visibleNotifications, setVisibleNotifications] = useState([]);

  useEffect(() => {
    setVisibleNotifications(notifications);
  }, [notifications]);

  const handleDismiss = (id) => {
    setVisibleNotifications(prev => prev?.filter(n => n?.id !== id));
    onDismiss?.(id);
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'achievement':
        return 'Trophy';
      case 'streak':
        return 'Flame';
      case 'milestone':
        return 'Target';
      case 'level_up':
        return 'TrendingUp';
      case 'perfect_score':
        return 'Star';
      case 'study_goal':
        return 'CheckCircle';
      default:
        return 'Bell';
    }
  };

  const getNotificationColor = (type) => {
    switch (type) {
      case 'achievement': case'perfect_score':
        return 'text-warning';
      case 'streak':
        return 'text-destructive';
      case 'milestone': case'level_up':
        return 'text-primary';
      case 'study_goal':
        return 'text-success';
      default:
        return 'text-muted-foreground';
    }
  };

  const getPositionClasses = () => {
    switch (position) {
      case 'top-left':
        return 'top-20 left-4';
      case 'top-right':
        return 'top-20 right-4';
      case 'bottom-left':
        return 'bottom-4 left-4';
      case 'bottom-right':
        return 'bottom-4 right-4';
      default:
        return 'top-20 right-4';
    }
  };

  if (visibleNotifications?.length === 0) return null;

  return (
    <div className={`fixed ${getPositionClasses()} z-notification space-y-3 max-w-sm w-full`}>
      {visibleNotifications?.map((notification) => (
        <NotificationCard
          key={notification?.id}
          notification={notification}
          onDismiss={handleDismiss}
          onViewDetails={onViewDetails}
          getIcon={getNotificationIcon}
          getColor={getNotificationColor}
        />
      ))}
    </div>
  );
};

const NotificationCard = ({ 
  notification, 
  onDismiss, 
  onViewDetails, 
  getIcon, 
  getColor 
}) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (notification?.autoHide !== false) {
      const timer = setTimeout(() => {
        onDismiss(notification?.id);
      }, notification?.duration || 5000);
      return () => clearTimeout(timer);
    }
  }, [notification, onDismiss]);

  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(() => onDismiss(notification?.id), 200);
  };

  return (
    <div
      className={`
        transform transition-all duration-300 ease-out
        ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
      `}
    >
      <div className="bg-card border border-border rounded-lg shadow-modal p-4 achievement-celebration">
        <div className="flex items-start space-x-3">
          {/* Icon */}
          <div className={`flex-shrink-0 ${getColor(notification?.type)}`}>
            <Icon name={getIcon(notification?.type)} size={24} />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-heading font-semibold text-card-foreground mb-1">
              {notification?.title}
            </h4>
            <p className="text-sm text-muted-foreground mb-2">
              {notification?.message}
            </p>

            {/* Achievement Details */}
            {notification?.details && (
              <div className="flex items-center space-x-4 text-xs font-caption text-muted-foreground">
                {notification?.details?.points && (
                  <span className="flex items-center space-x-1">
                    <Icon name="Plus" size={12} />
                    <span>{notification?.details?.points} points</span>
                  </span>
                )}
                {notification?.details?.streak && (
                  <span className="flex items-center space-x-1">
                    <Icon name="Flame" size={12} />
                    <span>{notification?.details?.streak} day streak</span>
                  </span>
                )}
                {notification?.details?.level && (
                  <span className="flex items-center space-x-1">
                    <Icon name="TrendingUp" size={12} />
                    <span>Level {notification?.details?.level}</span>
                  </span>
                )}
              </div>
            )}

            {/* Actions */}
            {(notification?.actionLabel || onViewDetails) && (
              <div className="flex items-center space-x-2 mt-3">
                {notification?.actionLabel && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => notification?.onAction?.(notification)}
                  >
                    {notification?.actionLabel}
                  </Button>
                )}
                {onViewDetails && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onViewDetails(notification)}
                  >
                    View Details
                  </Button>
                )}
              </div>
            )}
          </div>

          {/* Dismiss Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={handleDismiss}
            className="flex-shrink-0 w-6 h-6"
          >
            <Icon name="X" size={14} />
          </Button>
        </div>

        {/* Progress Bar for Timed Notifications */}
        {notification?.showProgress && notification?.duration && (
          <div className="mt-3">
            <div className="w-full bg-muted rounded-full h-1">
              <div 
                className="progress-indicator h-1 rounded-full"
                style={{
                  animation: `shrink ${notification?.duration}ms linear forwards`
                }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Achievement Celebration Modal for Major Milestones
const AchievementModal = ({ 
  achievement, 
  isOpen, 
  onClose, 
  onShare, 
  onContinue 
}) => {
  if (!isOpen || !achievement) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-modal flex items-center justify-center p-4">
      <div className="bg-card rounded-lg shadow-modal max-w-md w-full p-6 text-center achievement-celebration">
        {/* Achievement Icon */}
        <div className="w-20 h-20 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Trophy" size={40} color="var(--color-warning)" />
        </div>

        {/* Achievement Content */}
        <h2 className="text-2xl font-heading font-bold text-card-foreground mb-2">
          {achievement?.title}
        </h2>
        <p className="text-muted-foreground mb-6">
          {achievement?.description}
        </p>

        {/* Achievement Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-primary">
              {achievement?.points}
            </div>
            <div className="text-sm text-muted-foreground">Points Earned</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-success">
              {achievement?.level}
            </div>
            <div className="text-sm text-muted-foreground">New Level</div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-3">
          <Button
            variant="outline"
            fullWidth
            onClick={onShare}
            iconName="Share"
            iconPosition="left"
          >
            Share
          </Button>
          <Button
            variant="default"
            fullWidth
            onClick={onContinue}
          >
            Continue Learning
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProgressNotificationSystem;
export { AchievementModal };