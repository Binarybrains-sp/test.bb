import React, { useState } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const QuizNavigationPanel = ({
  questions = [],
  currentQuestion = 0,
  answeredQuestions = [],
  flaggedQuestions = [],
  onQuestionSelect,
  onToggleFlag,
  onSubmitQuiz,
  onReviewMode,
  isReviewMode = false,
  timeRemaining = '45:30',
  isVisible = true,
  onTogglePanel
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const getQuestionStatus = (index) => {
    if (answeredQuestions?.includes(index)) {
      return 'answered';
    }
    if (flaggedQuestions?.includes(index)) {
      return 'flagged';
    }
    if (index === currentQuestion) {
      return 'current';
    }
    return 'unanswered';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'answered':
        return 'bg-success text-success-foreground';
      case 'flagged':
        return 'bg-warning text-warning-foreground';
      case 'current':
        return 'bg-primary text-primary-foreground';
      default:
        return 'bg-muted text-muted-foreground hover:bg-muted/80';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'answered':
        return 'Check';
      case 'flagged':
        return 'Flag';
      case 'current':
        return 'Circle';
      default:
        return 'Circle';
    }
  };

  const answeredCount = answeredQuestions?.length;
  const flaggedCount = flaggedQuestions?.length;
  const unansweredCount = questions?.length - answeredCount;

  if (!isVisible) return null;

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden lg:block fixed right-0 top-16 bottom-0 w-80 bg-card border-l border-border z-navigation">
        <div className="h-full flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-heading font-semibold text-card-foreground">
                Quiz Navigation
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsCollapsed(!isCollapsed)}
              >
                <Icon name={isCollapsed ? 'ChevronLeft' : 'ChevronRight'} size={18} />
              </Button>
            </div>
            
            {!isCollapsed && (
              <>
                <div className="flex items-center justify-between text-sm font-caption">
                  <span className="text-muted-foreground">Time Remaining</span>
                  <span className="font-data text-destructive font-medium">{timeRemaining}</span>
                </div>
                
                <div className="grid grid-cols-3 gap-2 mt-3 text-xs font-caption">
                  <div className="text-center">
                    <div className="text-success font-medium">{answeredCount}</div>
                    <div className="text-muted-foreground">Answered</div>
                  </div>
                  <div className="text-center">
                    <div className="text-warning font-medium">{flaggedCount}</div>
                    <div className="text-muted-foreground">Flagged</div>
                  </div>
                  <div className="text-center">
                    <div className="text-muted-foreground font-medium">{unansweredCount}</div>
                    <div className="text-muted-foreground">Remaining</div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Question Grid */}
          {!isCollapsed && (
            <div className="flex-1 overflow-y-auto p-4">
              <div className="grid grid-cols-5 gap-2">
                {questions?.map((_, index) => {
                  const status = getQuestionStatus(index);
                  return (
                    <button
                      key={index}
                      onClick={() => onQuestionSelect(index)}
                      className={`
                        w-10 h-10 rounded-lg text-sm font-medium transition-all duration-200
                        ${getStatusColor(status)}
                        hover:scale-105 micro-interaction
                      `}
                    >
                      {index + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Actions */}
          {!isCollapsed && (
            <div className="p-4 border-t border-border space-y-2">
              <Button
                variant="outline"
                fullWidth
                onClick={() => onToggleFlag(currentQuestion)}
                iconName={flaggedQuestions?.includes(currentQuestion) ? 'FlagOff' : 'Flag'}
                iconPosition="left"
              >
                {flaggedQuestions?.includes(currentQuestion) ? 'Unflag' : 'Flag'} Question
              </Button>
              
              <Button
                variant="secondary"
                fullWidth
                onClick={onReviewMode}
                iconName="Eye"
                iconPosition="left"
              >
                Review Mode
              </Button>
              
              <Button
                variant="default"
                fullWidth
                onClick={onSubmitQuiz}
                iconName="Send"
                iconPosition="left"
              >
                Submit Quiz
              </Button>
            </div>
          )}
        </div>
      </div>
      {/* Mobile Bottom Sheet */}
      <div className="lg:hidden">
        {/* Toggle Button */}
        <button
          onClick={onTogglePanel}
          className="fixed bottom-4 right-4 w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-modal z-notification flex items-center justify-center"
        >
          <Icon name="Grid3x3" size={20} />
        </button>

        {/* Bottom Sheet */}
        <div className="fixed inset-x-0 bottom-0 bg-card border-t border-border z-modal transform transition-transform duration-300">
          <div className="p-4">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-heading font-semibold text-card-foreground">
                Questions
              </h3>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-data text-destructive">{timeRemaining}</span>
                <Button variant="ghost" size="icon" onClick={onTogglePanel}>
                  <Icon name="X" size={18} />
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mb-4 text-center text-sm font-caption">
              <div>
                <div className="text-success font-medium">{answeredCount}</div>
                <div className="text-muted-foreground">Answered</div>
              </div>
              <div>
                <div className="text-warning font-medium">{flaggedCount}</div>
                <div className="text-muted-foreground">Flagged</div>
              </div>
              <div>
                <div className="text-muted-foreground font-medium">{unansweredCount}</div>
                <div className="text-muted-foreground">Remaining</div>
              </div>
            </div>

            {/* Question Grid */}
            <div className="grid grid-cols-6 gap-2 mb-4 max-h-32 overflow-y-auto">
              {questions?.map((_, index) => {
                const status = getQuestionStatus(index);
                return (
                  <button
                    key={index}
                    onClick={() => {
                      onQuestionSelect(index);
                      onTogglePanel();
                    }}
                    className={`
                      w-10 h-10 rounded-lg text-sm font-medium transition-all duration-200
                      ${getStatusColor(status)}
                    `}
                  >
                    {index + 1}
                  </button>
                );
              })}
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                onClick={() => onToggleFlag(currentQuestion)}
                iconName={flaggedQuestions?.includes(currentQuestion) ? 'FlagOff' : 'Flag'}
                iconPosition="left"
              >
                {flaggedQuestions?.includes(currentQuestion) ? 'Unflag' : 'Flag'}
              </Button>
              
              <Button
                variant="default"
                onClick={onSubmitQuiz}
                iconName="Send"
                iconPosition="left"
              >
                Submit
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default QuizNavigationPanel;