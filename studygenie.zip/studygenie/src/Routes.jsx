import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import LandingPage from './pages/landing-page';
import StudySessionFlashcards from './pages/study-session-flashcards';
import Dashboard from './pages/dashboard';
import MaterialUpload from './pages/material-upload';
import QuizInterface from './pages/quiz-interface';
import ProgressAnalytics from './pages/progress-analytics';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<Dashboard />} />
        <Route path="/landing-page" element={<LandingPage />} />
        <Route path="/study-session-flashcards" element={<StudySessionFlashcards />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/material-upload" element={<MaterialUpload />} />
        <Route path="/quiz-interface" element={<QuizInterface />} />
        <Route path="/progress-analytics" element={<ProgressAnalytics />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
