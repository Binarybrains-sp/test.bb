import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import UploadDropzone from './components/UploadDropzone';
import FileCard from './components/FileCard';
import BatchActions from './components/BatchActions';
import ProcessingQueue from './components/ProcessingQueue';
import LanguageSelector from './components/LanguageSelector';
import UploadSettings from './components/UploadSettings';
import TextPreviewModal from './components/TextPreviewModal';
import UploadProgressTracker from '../../components/ui/UploadProgressTracker';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const MaterialUpload = () => {
  const navigate = useNavigate();
  const [language, setLanguage] = useState('en');
  const [ocrLanguage, setOcrLanguage] = useState('auto');
  const [files, setFiles] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [processingFiles, setProcessingFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [previewFile, setPreviewFile] = useState(null);
  const [uploadSettings, setUploadSettings] = useState({});
  const [activeView, setActiveView] = useState('grid'); // 'grid' or 'list'

  // Load language preference from localStorage
  useEffect(() => {
    const savedLanguage = localStorage.getItem('studyGenie_language') || 'en';
    setLanguage(savedLanguage);
  }, []);

  // Save language preference to localStorage
  const handleLanguageChange = (newLanguage) => {
    setLanguage(newLanguage);
    localStorage.setItem('studyGenie_language', newLanguage);
  };

  // Mock data for demonstration
  const mockFiles = [
    {
      id: 'file-1',
      name: 'Machine Learning Fundamentals.pdf',
      type: 'pdf',
      size: 2457600,
      pages: 45,
      uploadDate: new Date(Date.now() - 3600000),
      lastModified: new Date(Date.now() - 7200000),
      status: 'completed',
      thumbnail: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=100&h=100&fit=crop',
      progress: 100,
      ocrResults: {
        language: 'English',
        confidence: 94.5,
        wordCount: 12450,
        preview: 'Machine learning is a subset of artificial intelligence that provides systems...'
      }
    },
    {
      id: 'file-2',
      name: 'Data Structures Notes.jpg',
      type: 'image',
      size: 1234567,
      pages: 1,
      uploadDate: new Date(Date.now() - 1800000),
      status: 'processing',
      progress: 65,
      currentStep: 'analyzing',
      estimatedTimeRemaining: 45
    },
    {
      id: 'file-3',
      name: 'Algorithm Analysis.pdf',
      type: 'pdf',
      size: 3456789,
      pages: 78,
      uploadDate: new Date(Date.now() - 900000),
      status: 'failed',
      errorMessage: 'OCR extraction failed. The document may be corrupted or contain unsupported formatting.'
    },
    {
      id: 'file-4',
      name: 'Database Design Concepts.png',
      type: 'image',
      size: 987654,
      pages: 1,
      uploadDate: new Date(Date.now() - 300000),
      status: 'extracting',
      progress: 25,
      currentStep: 'extracting',
      estimatedTimeRemaining: 120
    }
  ];

  useEffect(() => {
    setFiles(mockFiles);
    setProcessingFiles(mockFiles?.filter(f => 
      ['uploading', 'processing', 'extracting', 'analyzing']?.includes(f?.status)
    ));
  }, []);

  const translations = {
    en: {
      materialUpload: "Material Upload",
      uploadYourFiles: "Upload Your Study Materials",
      description: "Transform your PDFs, images, and handwritten notes into interactive study content with AI-powered processing.",
      noFilesUploaded: "No files uploaded yet",
      startUploading: "Start by uploading your first study material",
      uploadFiles: "Upload Files",
      viewToggle: "View",
      gridView: "Grid",
      listView: "List",
      filterBy: "Filter by status",
      allFiles: "All Files",
      completed: "Completed",
      processing: "Processing",
      failed: "Failed"
    },
    hi: {
      materialUpload: "सामग्री अपलोड",
      uploadYourFiles: "अपनी अध्ययन सामग्री अपलोड करें",
      description: "AI-संचालित प्रसंस्करण के साथ अपनी PDF, छवियों और हस्तलिखित नोट्स को इंटरैक्टिव अध्ययन सामग्री में बदलें।",
      noFilesUploaded: "अभी तक कोई फाइल अपलोड नहीं की गई",
      startUploading: "अपनी पहली अध्ययन सामग्री अपलोड करके शुरुआत करें",
      uploadFiles: "फाइलें अपलोड करें",
      viewToggle: "दृश्य",
      gridView: "ग्रिड",
      listView: "सूची",
      filterBy: "स्थिति के अनुसार फ़िल्टर करें",
      allFiles: "सभी फाइलें",
      completed: "पूर्ण",
      processing: "प्रसंस्करण",
      failed: "असफल"
    },
    mr: {
      materialUpload: "सामग्री अपलोड",
      uploadYourFiles: "तुमची अभ्यास सामग्री अपलोड करा",
      description: "AI-चालित प्रक्रियेसह तुमच्या PDF, प्रतिमा आणि हस्तलिखित नोट्स इंटरॅक्टिव्ह अभ्यास सामग्रीमध्ये रूपांतरित करा।",
      noFilesUploaded: "अजून कोणतीही फाइल अपलोड केली नाही",
      startUploading: "तुमची पहिली अभ्यास सामग्री अपलोड करून सुरुवात करा",
      uploadFiles: "फाइल्स अपलोड करा",
      viewToggle: "दृश्य",
      gridView: "ग्रिड",
      listView: "यादी",
      filterBy: "स्थितीनुसार फिल्टर करा",
      allFiles: "सर्व फाइल्स",
      completed: "पूर्ण",
      processing: "प्रक्रिया",
      failed: "अयशस्वी"
    }
  };

  const t = translations?.[language] || translations?.en;

  const handleFilesSelected = async (newFiles) => {
    setIsUploading(true);
    
    // Simulate file upload process
    const uploadedFiles = newFiles?.map((file, index) => ({
      id: `file-${Date.now()}-${index}`,
      name: file?.name,
      type: file?.type?.includes('pdf') ? 'pdf' : 'image',
      size: file?.size,
      pages: file?.type?.includes('pdf') ? Math.floor(Math.random() * 50) + 10 : 1,
      uploadDate: new Date(),
      status: 'uploading',
      progress: 0,
      file: file
    }));

    setFiles(prev => [...prev, ...uploadedFiles]);
    setProcessingFiles(prev => [...prev, ...uploadedFiles]);

    // Simulate upload progress
    for (const uploadedFile of uploadedFiles) {
      simulateFileProcessing(uploadedFile?.id);
    }

    setIsUploading(false);
  };

  const simulateFileProcessing = (fileId) => {
    const steps = ['uploading', 'processing', 'extracting', 'analyzing', 'completed'];
    let currentStepIndex = 0;
    let progress = 0;

    const interval = setInterval(() => {
      progress += Math.random() * 15 + 5;
      
      if (progress >= 100) {
        progress = 100;
        currentStepIndex = steps?.length - 1;
      } else if (progress > 80) {
        currentStepIndex = 3;
      } else if (progress > 60) {
        currentStepIndex = 2;
      } else if (progress > 30) {
        currentStepIndex = 1;
      }

      const status = steps?.[currentStepIndex];
      
      setFiles(prev => prev?.map(file => 
        file?.id === fileId 
          ? { 
              ...file, 
              status, 
              progress: Math.round(progress),
              currentStep: status,
              estimatedTimeRemaining: status === 'completed' ? 0 : Math.max(0, Math.round((100 - progress) * 2))
            }
          : file
      ));

      if (status === 'completed') {
        setProcessingFiles(prev => prev?.filter(f => f?.id !== fileId));
        
        // Add mock OCR results for completed files
        setFiles(prev => prev?.map(file => 
          file?.id === fileId 
            ? {
                ...file,
                ocrResults: {
                  language: 'English',
                  confidence: Math.round(Math.random() * 20 + 80),
                  wordCount: Math.round(Math.random() * 10000 + 1000),
                  preview: 'This is a preview of the extracted text content...'
                }
              }
            : file
        ));
        
        clearInterval(interval);
      }
    }, 1000);
  };

  const handleGenerateContent = (file) => {
    // Navigate to study session with the generated content
    navigate('/study-session-flashcards', { 
      state: { 
        sourceFile: file,
        generatedContent: true 
      } 
    });
  };

  const handlePreviewText = (file) => {
    setPreviewFile(file);
  };

  const handleDeleteFile = (file) => {
    setFiles(prev => prev?.filter(f => f?.id !== file?.id));
    setSelectedFiles(prev => prev?.filter(id => id !== file?.id));
    setProcessingFiles(prev => prev?.filter(f => f?.id !== file?.id));
  };

  const handleRetryFile = (file) => {
    setFiles(prev => prev?.map(f => 
      f?.id === file?.id 
        ? { ...f, status: 'uploading', progress: 0, errorMessage: null }
        : f
    ));
    simulateFileProcessing(file?.id);
  };

  const handleBatchGenerate = (fileIds) => {
    const selectedFileObjects = files?.filter(f => fileIds?.includes(f?.id));
    navigate('/study-session-flashcards', { 
      state: { 
        sourceFiles: selectedFileObjects,
        batchGenerated: true 
      } 
    });
  };

  const handleBatchDelete = (fileIds) => {
    setFiles(prev => prev?.filter(f => !fileIds?.includes(f?.id)));
    setSelectedFiles([]);
  };

  const handleBatchRetry = (fileIds) => {
    setFiles(prev => prev?.map(f => 
      fileIds?.includes(f?.id) 
        ? { ...f, status: 'uploading', progress: 0, errorMessage: null }
        : f
    ));
    fileIds?.forEach(id => simulateFileProcessing(id));
  };

  const filteredFiles = files;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="Upload" size={24} color="white" />
              </div>
              <div>
                <h1 className="text-2xl font-heading font-bold text-foreground">
                  {t?.materialUpload}
                </h1>
                <p className="text-muted-foreground">
                  {t?.description}
                </p>
              </div>
            </div>
          </div>

          {/* Language Selector */}
          <LanguageSelector
            selectedLanguage={language}
            onLanguageChange={handleLanguageChange}
            ocrLanguage={ocrLanguage}
            onOcrLanguageChange={setOcrLanguage}
            language={language}
          />

          {/* Upload Settings */}
          <UploadSettings
            settings={uploadSettings}
            onSettingsChange={setUploadSettings}
            language={language}
          />

          {/* Processing Queue */}
          <ProcessingQueue
            processingFiles={processingFiles}
            onPauseProcessing={() => {}}
            onResumeProcessing={() => {}}
            onCancelProcessing={() => {}}
            language={language}
          />

          {/* Upload Dropzone */}
          <div className="mb-8">
            <UploadDropzone
              onFilesSelected={handleFilesSelected}
              isUploading={isUploading}
              maxFileSize={parseInt(uploadSettings?.maxFileSize) || 10}
              language={language}
            />
          </div>

          {/* Files Section */}
          {files?.length > 0 ? (
            <>
              {/* Batch Actions */}
              <BatchActions
                files={files}
                selectedFiles={selectedFiles}
                onSelectAll={setSelectedFiles}
                onSelectFile={(fileId) => {
                  setSelectedFiles(prev => 
                    prev?.includes(fileId) 
                      ? prev?.filter(id => id !== fileId)
                      : [...prev, fileId]
                  );
                }}
                onBatchGenerate={handleBatchGenerate}
                onBatchDelete={handleBatchDelete}
                onBatchRetry={handleBatchRetry}
                language={language}
              />

              {/* View Controls */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium text-muted-foreground">
                    {files?.length} files uploaded
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">{t?.viewToggle}:</span>
                  <Button
                    variant={activeView === 'grid' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveView('grid')}
                    iconName="Grid3x3"
                  >
                    {t?.gridView}
                  </Button>
                  <Button
                    variant={activeView === 'list' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveView('list')}
                    iconName="List"
                  >
                    {t?.listView}
                  </Button>
                </div>
              </div>

              {/* Files Grid/List */}
              <div className={
                activeView === 'grid' ? 'grid grid-cols-1 lg:grid-cols-2 gap-6' : 'space-y-4'
              }>
                {filteredFiles?.map((file) => (
                  <div key={file?.id} className="relative">
                    {selectedFiles?.includes(file?.id) && (
                      <div className="absolute top-2 left-2 z-10">
                        <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                          <Icon name="Check" size={12} color="white" />
                        </div>
                      </div>
                    )}
                    <FileCard
                      file={file}
                      onGenerateContent={handleGenerateContent}
                      onPreviewText={handlePreviewText}
                      onDelete={handleDeleteFile}
                      onRetry={handleRetryFile}
                      language={language}
                    />
                  </div>
                ))}
              </div>
            </>
          ) : (
            /* Empty State */
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                <Icon name="Upload" size={48} className="text-muted-foreground" />
              </div>
              <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
                {t?.noFilesUploaded}
              </h3>
              <p className="text-muted-foreground mb-6">
                {t?.startUploading}
              </p>
              <Button
                variant="default"
                onClick={() => document.querySelector('input[type="file"]')?.click()}
                iconName="Upload"
                iconPosition="left"
              >
                {t?.uploadFiles}
              </Button>
            </div>
          )}
        </div>
      </main>
      {/* Text Preview Modal */}
      <TextPreviewModal
        isOpen={!!previewFile}
        onClose={() => setPreviewFile(null)}
        file={previewFile}
        language={language}
      />
      {/* Upload Progress Tracker */}
      <UploadProgressTracker
        uploads={files?.filter(f => ['uploading', 'processing', 'extracting', 'analyzing']?.includes(f?.status))}
        isVisible={processingFiles?.length > 0}
        onRetry={handleRetryFile}
        onCancel={handleDeleteFile}
        onViewFile={handlePreviewText}
        onToggle={() => {}}
      />
    </div>
  );
};

export default MaterialUpload;