import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';

const UploadSettings = ({ 
  settings = {}, 
  onSettingsChange, 
  language = 'en'
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const translations = {
    en: {
      advancedSettings: "Advanced Settings",
      contentGeneration: "Content Generation",
      generateFlashcards: "Generate Flashcards",
      generateQuiz: "Generate Quiz Questions",
      generateSummary: "Generate Summary",
      processingOptions: "Processing Options",
      ocrQuality: "OCR Quality",
      high: "High (Slower)",
      medium: "Medium (Balanced)",
      fast: "Fast (Lower accuracy)",
      autoChunking: "Auto-chunk large documents",
      preserveFormatting: "Preserve document formatting",
      extractImages: "Extract embedded images",
      fileSettings: "File Settings",
      maxFileSize: "Maximum file size",
      allowedFormats: "Allowed formats",
      compressionLevel: "Image compression",
      none: "None",
      low: "Low",
      reset: "Reset to Defaults"
    },
    hi: {
      advancedSettings: "उन्नत सेटिंग्स",
      contentGeneration: "सामग्री निर्माण",
      generateFlashcards: "फ्लैशकार्ड बनाएं",
      generateQuiz: "क्विज़ प्रश्न बनाएं",
      generateSummary: "सारांश बनाएं",
      processingOptions: "प्रोसेसिंग विकल्प",
      ocrQuality: "OCR गुणवत्ता",
      high: "उच्च (धीमा)",
      medium: "मध्यम (संतुलित)",
      fast: "तेज़ (कम सटीकता)",
      autoChunking: "बड़े दस्तावेज़ों को स्वचालित रूप से विभाजित करें",
      preserveFormatting: "दस्तावेज़ स्वरूपण संरक्षित करें",
      extractImages: "एम्बेडेड छवियां निकालें",
      fileSettings: "फाइल सेटिंग्स",
      maxFileSize: "अधिकतम फाइल आकार",
      allowedFormats: "अनुमतित प्रारूप",
      compressionLevel: "छवि संपीड़न",
      none: "कोई नहीं",
      low: "कम",
      reset: "डिफ़ॉल्ट पर रीसेट करें"
    },
    mr: {
      advancedSettings: "प्रगत सेटिंग्ज",
      contentGeneration: "सामग्री निर्मिती",
      generateFlashcards: "फ्लॅशकार्ड तयार करा",
      generateQuiz: "क्विझ प्रश्न तयार करा",
      generateSummary: "सारांश तयार करा",
      processingOptions: "प्रक्रिया पर्याय",
      ocrQuality: "OCR गुणवत्ता",
      high: "उच्च (हळू)",
      medium: "मध्यम (संतुलित)",
      fast: "जलद (कमी अचूकता)",
      autoChunking: "मोठे दस्तऐवज स्वयंचलितपणे विभाजित करा",
      preserveFormatting: "दस्तऐवज स्वरूपन जतन करा",
      extractImages: "एम्बेडेड प्रतिमा काढा",
      fileSettings: "फाइल सेटिंग्ज",
      maxFileSize: "कमाल फाइल आकार",
      allowedFormats: "परवानगी असलेले स्वरूप",
      compressionLevel: "प्रतिमा संकुचन",
      none: "काहीही नाही",
      low: "कमी",
      reset: "डीफॉल्टवर रीसेट करा"
    }
  };

  const t = translations?.[language] || translations?.en;

  const defaultSettings = {
    generateFlashcards: true,
    generateQuiz: true,
    generateSummary: true,
    ocrQuality: 'medium',
    autoChunking: true,
    preserveFormatting: false,
    extractImages: true,
    maxFileSize: '10',
    compressionLevel: 'low'
  };

  const currentSettings = { ...defaultSettings, ...settings };

  const handleSettingChange = (key, value) => {
    const newSettings = { ...currentSettings, [key]: value };
    onSettingsChange(newSettings);
  };

  const handleReset = () => {
    onSettingsChange(defaultSettings);
  };

  const ocrQualityOptions = [
    { value: 'fast', label: t?.fast },
    { value: 'medium', label: t?.medium },
    { value: 'high', label: t?.high }
  ];

  const fileSizeOptions = [
    { value: '5', label: '5 MB' },
    { value: '10', label: '10 MB' },
    { value: '25', label: '25 MB' },
    { value: '50', label: '50 MB' }
  ];

  const compressionOptions = [
    { value: 'none', label: t?.none },
    { value: 'low', label: t?.low },
    { value: 'medium', label: t?.medium },
    { value: 'high', label: t?.high }
  ];

  return (
    <div className="bg-card border border-border rounded-lg mb-6">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Settings" size={20} className="text-primary" />
            <h3 className="text-sm font-heading font-semibold text-card-foreground">
              {t?.advancedSettings}
            </h3>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            <Icon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={18} />
          </Button>
        </div>
      </div>
      {/* Settings Content */}
      {isExpanded && (
        <div className="p-4 space-y-6">
          {/* Content Generation */}
          <div>
            <h4 className="text-sm font-heading font-medium text-card-foreground mb-3">
              {t?.contentGeneration}
            </h4>
            <div className="space-y-3">
              <Checkbox
                label={t?.generateFlashcards}
                checked={currentSettings?.generateFlashcards}
                onChange={(e) => handleSettingChange('generateFlashcards', e?.target?.checked)}
              />
              <Checkbox
                label={t?.generateQuiz}
                checked={currentSettings?.generateQuiz}
                onChange={(e) => handleSettingChange('generateQuiz', e?.target?.checked)}
              />
              <Checkbox
                label={t?.generateSummary}
                checked={currentSettings?.generateSummary}
                onChange={(e) => handleSettingChange('generateSummary', e?.target?.checked)}
              />
            </div>
          </div>

          {/* Processing Options */}
          <div>
            <h4 className="text-sm font-heading font-medium text-card-foreground mb-3">
              {t?.processingOptions}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select
                label={t?.ocrQuality}
                options={ocrQualityOptions}
                value={currentSettings?.ocrQuality}
                onChange={(value) => handleSettingChange('ocrQuality', value)}
              />
              
              <Select
                label={t?.compressionLevel}
                options={compressionOptions}
                value={currentSettings?.compressionLevel}
                onChange={(value) => handleSettingChange('compressionLevel', value)}
              />
            </div>
            
            <div className="space-y-3 mt-4">
              <Checkbox
                label={t?.autoChunking}
                description="Split large documents into smaller sections for better processing"
                checked={currentSettings?.autoChunking}
                onChange={(e) => handleSettingChange('autoChunking', e?.target?.checked)}
              />
              <Checkbox
                label={t?.preserveFormatting}
                description="Maintain original document structure and formatting"
                checked={currentSettings?.preserveFormatting}
                onChange={(e) => handleSettingChange('preserveFormatting', e?.target?.checked)}
              />
              <Checkbox
                label={t?.extractImages}
                description="Extract and process images embedded in documents"
                checked={currentSettings?.extractImages}
                onChange={(e) => handleSettingChange('extractImages', e?.target?.checked)}
              />
            </div>
          </div>

          {/* File Settings */}
          <div>
            <h4 className="text-sm font-heading font-medium text-card-foreground mb-3">
              {t?.fileSettings}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select
                label={t?.maxFileSize}
                options={fileSizeOptions}
                value={currentSettings?.maxFileSize}
                onChange={(value) => handleSettingChange('maxFileSize', value)}
              />
            </div>
          </div>

          {/* Reset Button */}
          <div className="pt-4 border-t border-border">
            <Button
              variant="outline"
              onClick={handleReset}
              iconName="RotateCcw"
              iconPosition="left"
            >
              {t?.reset}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UploadSettings;