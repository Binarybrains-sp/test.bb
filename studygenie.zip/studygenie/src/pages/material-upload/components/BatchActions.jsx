import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const BatchActions = ({ 
  files = [], 
  selectedFiles = [], 
  onSelectAll, 
  onSelectFile, 
  onBatchGenerate, 
  onBatchDelete, 
  onBatchRetry,
  language = 'en'
}) => {
  const [isActionsOpen, setIsActionsOpen] = useState(false);

  const translations = {
    en: {
      selectAll: "Select All",
      selected: "selected",
      batchActions: "Batch Actions",
      generateAll: "Generate Content for All",
      deleteSelected: "Delete Selected",
      retryFailed: "Retry Failed",
      clearSelection: "Clear Selection",
      noFilesSelected: "No files selected"
    },
    hi: {
      selectAll: "सभी चुनें",
      selected: "चयनित",
      batchActions: "बैच क्रियाएं",
      generateAll: "सभी के लिए सामग्री बनाएं",
      deleteSelected: "चयनित को हटाएं",
      retryFailed: "असफल को पुनः प्रयास करें",
      clearSelection: "चयन साफ़ करें",
      noFilesSelected: "कोई फाइल चयनित नहीं"
    },
    mr: {
      selectAll: "सर्व निवडा",
      selected: "निवडलेले",
      batchActions: "बॅच क्रिया",
      generateAll: "सर्वांसाठी सामग्री तयार करा",
      deleteSelected: "निवडलेले हटवा",
      retryFailed: "अयशस्वी पुन्हा प्रयत्न करा",
      clearSelection: "निवड साफ करा",
      noFilesSelected: "कोणतीही फाइल निवडली नाही"
    }
  };

  const t = translations?.[language] || translations?.en;

  const allSelected = files?.length > 0 && selectedFiles?.length === files?.length;
  const someSelected = selectedFiles?.length > 0 && selectedFiles?.length < files?.length;
  const hasSelection = selectedFiles?.length > 0;
  const failedFiles = files?.filter(f => f?.status === 'failed');
  const completedFiles = files?.filter(f => f?.status === 'completed');
  const selectedCompletedFiles = selectedFiles?.filter(id => {
    const file = files?.find(f => f?.id === id);
    return file && file?.status === 'completed';
  });

  const handleSelectAll = () => {
    if (allSelected) {
      onSelectAll([]);
    } else {
      onSelectAll(files?.map(f => f?.id));
    }
  };

  const handleBatchGenerate = () => {
    const validFiles = selectedFiles?.filter(id => {
      const file = files?.find(f => f?.id === id);
      return file && file?.status === 'completed';
    });
    
    if (validFiles?.length > 0) {
      onBatchGenerate(validFiles);
      setIsActionsOpen(false);
    }
  };

  const handleBatchDelete = () => {
    if (hasSelection) {
      onBatchDelete(selectedFiles);
      setIsActionsOpen(false);
    }
  };

  const handleBatchRetry = () => {
    const failedFileIds = failedFiles?.map(f => f?.id);
    if (failedFileIds?.length > 0) {
      onBatchRetry(failedFileIds);
      setIsActionsOpen(false);
    }
  };

  if (files?.length === 0) return null;

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between">
        {/* Selection Controls */}
        <div className="flex items-center space-x-4">
          <Checkbox
            checked={allSelected}
            indeterminate={someSelected}
            onChange={handleSelectAll}
            label={t?.selectAll}
          />
          
          {hasSelection && (
            <span className="text-sm font-caption text-muted-foreground">
              {selectedFiles?.length} {t?.selected}
            </span>
          )}
        </div>

        {/* Batch Actions */}
        <div className="flex items-center space-x-2">
          {hasSelection && (
            <>
              {/* Desktop Actions */}
              <div className="hidden md:flex items-center space-x-2">
                {selectedCompletedFiles?.length > 0 && (
                  <Button
                    variant="default"
                    size="sm"
                    onClick={handleBatchGenerate}
                    iconName="Sparkles"
                    iconPosition="left"
                  >
                    {t?.generateAll} ({selectedCompletedFiles?.length})
                  </Button>
                )}
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleBatchDelete}
                  iconName="Trash2"
                  iconPosition="left"
                  className="text-error hover:text-error"
                >
                  {t?.deleteSelected}
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onSelectAll([])}
                  iconName="X"
                  iconPosition="left"
                >
                  {t?.clearSelection}
                </Button>
              </div>

              {/* Mobile Actions Menu */}
              <div className="md:hidden relative">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsActionsOpen(!isActionsOpen)}
                  iconName="MoreVertical"
                  iconPosition="left"
                >
                  {t?.batchActions}
                </Button>

                {isActionsOpen && (
                  <div className="absolute right-0 top-full mt-2 w-56 bg-popover border border-border rounded-lg shadow-modal z-10">
                    <div className="py-2">
                      {selectedCompletedFiles?.length > 0 && (
                        <button
                          onClick={handleBatchGenerate}
                          className="w-full flex items-center px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-colors"
                        >
                          <Icon name="Sparkles" size={16} className="mr-3" />
                          {t?.generateAll} ({selectedCompletedFiles?.length})
                        </button>
                      )}
                      
                      <button
                        onClick={handleBatchDelete}
                        className="w-full flex items-center px-4 py-2 text-sm text-error hover:bg-muted transition-colors"
                      >
                        <Icon name="Trash2" size={16} className="mr-3" />
                        {t?.deleteSelected}
                      </button>
                      
                      <button
                        onClick={() => {
                          onSelectAll([]);
                          setIsActionsOpen(false);
                        }}
                        className="w-full flex items-center px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-colors"
                      >
                        <Icon name="X" size={16} className="mr-3" />
                        {t?.clearSelection}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Retry Failed Files */}
          {failedFiles?.length > 0 && !hasSelection && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleBatchRetry}
              iconName="RotateCcw"
              iconPosition="left"
              className="text-warning hover:text-warning"
            >
              {t?.retryFailed} ({failedFiles?.length})
            </Button>
          )}
        </div>
      </div>
      {/* Selection Info */}
      {hasSelection && (
        <div className="mt-3 pt-3 border-t border-border">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center text-xs font-caption">
            <div>
              <div className="text-foreground font-medium">{selectedFiles?.length}</div>
              <div className="text-muted-foreground">Total Selected</div>
            </div>
            <div>
              <div className="text-success font-medium">{selectedCompletedFiles?.length}</div>
              <div className="text-muted-foreground">Ready to Generate</div>
            </div>
            <div>
              <div className="text-primary font-medium">
                {selectedFiles?.filter(id => {
                  const file = files?.find(f => f?.id === id);
                  return file && ['uploading', 'processing', 'extracting', 'analyzing']?.includes(file?.status);
                })?.length}
              </div>
              <div className="text-muted-foreground">Processing</div>
            </div>
            <div>
              <div className="text-error font-medium">
                {selectedFiles?.filter(id => {
                  const file = files?.find(f => f?.id === id);
                  return file && file?.status === 'failed';
                })?.length}
              </div>
              <div className="text-muted-foreground">Failed</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BatchActions;