import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProcessingQueue = ({ 
  processingFiles = [], 
  onPauseProcessing, 
  onResumeProcessing, 
  onCancelProcessing,
  language = 'en'
}) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const translations = {
    en: {
      processingQueue: "Processing Queue",
      estimatedTime: "Estimated time remaining",
      pauseAll: "Pause All",
      resumeAll: "Resume All",
      cancelAll: "Cancel All",
      minutes: "min",
      seconds: "sec",
      extractingText: "Extracting text...",
      analyzingContent: "Analyzing content...",
      generatingFlashcards: "Generating flashcards...",
      creatingQuiz: "Creating quiz questions...",
      finalizing: "Finalizing...",
      paused: "Paused",
      queueEmpty: "No files currently processing"
    },
    hi: {
      processingQueue: "प्रोसेसिंग क्यू",
      estimatedTime: "अनुमानित समय शेष",
      pauseAll: "सभी को रोकें",
      resumeAll: "सभी को जारी रखें",
      cancelAll: "सभी को रद्द करें",
      minutes: "मिनट",
      seconds: "सेकंड",
      extractingText: "टेक्स्ट निकाला जा रहा है...",
      analyzingContent: "सामग्री का विश्लेषण...",
      generatingFlashcards: "फ्लैशकार्ड बनाए जा रहे हैं...",
      creatingQuiz: "क्विज़ प्रश्न बनाए जा रहे हैं...",
      finalizing: "अंतिम रूप दिया जा रहा है...",
      paused: "रोका गया",
      queueEmpty: "कोई फाइल प्रोसेसिंग नहीं हो रही"
    },
    mr: {
      processingQueue: "प्रक्रिया रांग",
      estimatedTime: "अंदाजित वेळ उरलेली",
      pauseAll: "सर्व थांबवा",
      resumeAll: "सर्व सुरू करा",
      cancelAll: "सर्व रद्द करा",
      minutes: "मिनिटे",
      seconds: "सेकंद",
      extractingText: "मजकूर काढत आहे...",
      analyzingContent: "सामग्रीचे विश्लेषण...",
      generatingFlashcards: "फ्लॅशकार्ड तयार करत आहे...",
      creatingQuiz: "क्विझ प्रश्न तयार करत आहे...",
      finalizing: "अंतिम रूप देत आहे...",
      paused: "थांबवले",
      queueEmpty: "सध्या कोणतीही फाइल प्रक्रिया होत नाही"
    }
  };

  const t = translations?.[language] || translations?.en;

  const activeFiles = processingFiles?.filter(f => !f?.isPaused);
  const pausedFiles = processingFiles?.filter(f => f?.isPaused);
  const totalEstimatedTime = processingFiles?.reduce((acc, file) => acc + (file?.estimatedTimeRemaining || 0), 0);

  const formatTime = (seconds) => {
    if (seconds < 60) {
      return `${seconds} ${t?.seconds}`;
    }
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return remainingSeconds > 0 ? `${minutes} ${t?.minutes} ${remainingSeconds} ${t?.seconds}` : `${minutes} ${t?.minutes}`;
  };

  const getStepText = (step) => {
    switch (step) {
      case 'extracting':
        return t?.extractingText;
      case 'analyzing':
        return t?.analyzingContent;
      case 'generating_flashcards':
        return t?.generatingFlashcards;
      case 'creating_quiz':
        return t?.creatingQuiz;
      case 'finalizing':
        return t?.finalizing;
      default:
        return step;
    }
  };

  if (processingFiles?.length === 0) return null;

  return (
    <div className="bg-card border border-border rounded-lg mb-6">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="Loader" size={18} className="text-primary animate-spin" />
            </div>
            <div>
              <h3 className="text-sm font-heading font-semibold text-card-foreground">
                {t?.processingQueue}
              </h3>
              <p className="text-xs font-caption text-muted-foreground">
                {activeFiles?.length} active, {pausedFiles?.length} paused
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {totalEstimatedTime > 0 && (
              <div className="text-right mr-4 hidden sm:block">
                <p className="text-xs font-caption text-muted-foreground">
                  {t?.estimatedTime}
                </p>
                <p className="text-sm font-data text-foreground">
                  {formatTime(totalEstimatedTime)}
                </p>
              </div>
            )}

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              <Icon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={18} />
            </Button>
          </div>
        </div>

        {/* Queue Controls */}
        {isExpanded && (
          <div className="flex items-center space-x-2 mt-4">
            {activeFiles?.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={onPauseProcessing}
                iconName="Pause"
                iconPosition="left"
              >
                {t?.pauseAll}
              </Button>
            )}
            
            {pausedFiles?.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={onResumeProcessing}
                iconName="Play"
                iconPosition="left"
              >
                {t?.resumeAll}
              </Button>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onCancelProcessing}
              iconName="X"
              iconPosition="left"
              className="text-error hover:text-error"
            >
              {t?.cancelAll}
            </Button>
          </div>
        )}
      </div>
      {/* Processing Files List */}
      {isExpanded && (
        <div className="max-h-64 overflow-y-auto">
          {processingFiles?.length === 0 ? (
            <div className="p-8 text-center">
              <Icon name="CheckCircle" size={32} className="text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">{t?.queueEmpty}</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {processingFiles?.map((file) => (
                <ProcessingFileItem
                  key={file?.id}
                  file={file}
                  onPause={() => onPauseProcessing(file?.id)}
                  onResume={() => onResumeProcessing(file?.id)}
                  onCancel={() => onCancelProcessing(file?.id)}
                  getStepText={getStepText}
                  formatTime={formatTime}
                  translations={t}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const ProcessingFileItem = ({ 
  file, 
  onPause, 
  onResume, 
  onCancel, 
  getStepText, 
  formatTime, 
  translations: t 
}) => {
  return (
    <div className="p-4">
      <div className="flex items-center space-x-3">
        {/* File Icon */}
        <div className="flex-shrink-0">
          <div className="w-8 h-8 bg-muted rounded flex items-center justify-center">
            <Icon 
              name={file?.type === 'pdf' ? 'FileText' : 'Image'} 
              size={16} 
              className="text-muted-foreground"
            />
          </div>
        </div>

        {/* File Info */}
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-medium text-card-foreground truncate">
            {file?.name}
          </h4>
          <div className="flex items-center space-x-2 mt-1">
            <span className={`text-xs font-caption ${file?.isPaused ? 'text-warning' : 'text-primary'}`}>
              {file?.isPaused ? t?.paused : getStepText(file?.currentStep)}
            </span>
            {file?.estimatedTimeRemaining && !file?.isPaused && (
              <>
                <span className="text-xs text-muted-foreground">•</span>
                <span className="text-xs font-data text-muted-foreground">
                  {formatTime(file?.estimatedTimeRemaining)}
                </span>
              </>
            )}
          </div>

          {/* Progress Bar */}
          <div className="mt-2">
            <div className="flex items-center justify-between text-xs font-data mb-1">
              <span className="text-muted-foreground">
                Step {file?.currentStepIndex || 1} of {file?.totalSteps || 5}
              </span>
              <span className="text-muted-foreground">
                {file?.progress || 0}%
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-1">
              <div 
                className={`h-1 rounded-full transition-all duration-300 ${
                  file?.isPaused ? 'bg-warning' : 'bg-primary'
                }`}
                style={{ width: `${file?.progress || 0}%` }}
              />
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-1">
          {file?.isPaused ? (
            <Button
              variant="ghost"
              size="icon"
              onClick={onResume}
              className="w-8 h-8"
            >
              <Icon name="Play" size={14} />
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              onClick={onPause}
              className="w-8 h-8"
            >
              <Icon name="Pause" size={14} />
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            onClick={onCancel}
            className="w-8 h-8 text-error hover:text-error"
          >
            <Icon name="X" size={14} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProcessingQueue;