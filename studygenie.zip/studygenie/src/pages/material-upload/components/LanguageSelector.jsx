import React from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';

const LanguageSelector = ({ 
  selectedLanguage = 'en', 
  onLanguageChange, 
  ocrLanguage = 'auto', 
  onOcrLanguageChange,
  language = 'en'
}) => {
  const translations = {
    en: {
      interfaceLanguage: "Interface Language",
      ocrLanguage: "OCR Language",
      autoDetect: "Auto Detect",
      selectLanguage: "Select language for text extraction"
    },
    hi: {
      interfaceLanguage: "इंटरफ़ेस भाषा",
      ocrLanguage: "OCR भाषा",
      autoDetect: "स्वचालित पहचान",
      selectLanguage: "टेक्स्ट निकालने के लिए भाषा चुनें"
    },
    mr: {
      interfaceLanguage: "इंटरफेस भाषा",
      ocrLanguage: "OCR भाषा",
      autoDetect: "स्वयंचलित ओळख",
      selectLanguage: "मजकूर काढण्यासाठी भाषा निवडा"
    }
  };

  const t = translations?.[language] || translations?.en;

  const interfaceLanguages = [
    { value: 'en', label: 'English', flag: '🇺🇸' },
    { value: 'hi', label: 'हिन्दी', flag: '🇮🇳' },
    { value: 'mr', label: 'मराठी', flag: '🇮🇳' }
  ];

  const ocrLanguages = [
    { value: 'auto', label: t?.autoDetect },
    { value: 'en', label: 'English' },
    { value: 'hi', label: 'हिन्दी (Hindi)' },
    { value: 'mr', label: 'मराठी (Marathi)' },
    { value: 'bn', label: 'বাংলা (Bengali)' },
    { value: 'gu', label: 'ગુજરાતી (Gujarati)' },
    { value: 'kn', label: 'ಕನ್ನಡ (Kannada)' },
    { value: 'ml', label: 'മലയാളം (Malayalam)' },
    { value: 'or', label: 'ଓଡ଼ିଆ (Odia)' },
    { value: 'pa', label: 'ਪੰਜਾਬੀ (Punjabi)' },
    { value: 'ta', label: 'தமிழ் (Tamil)' },
    { value: 'te', label: 'తెలుగు (Telugu)' },
    { value: 'ur', label: 'اردو (Urdu)' }
  ];

  const formatInterfaceOption = (option) => (
    <div className="flex items-center space-x-2">
      <span className="text-base">{option?.flag}</span>
      <span>{option?.label}</span>
    </div>
  );

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Globe" size={20} className="text-primary" />
        <h3 className="text-sm font-heading font-semibold text-card-foreground">
          Language Settings
        </h3>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Interface Language */}
        <div>
          <Select
            label={t?.interfaceLanguage}
            options={interfaceLanguages?.map(lang => ({
              value: lang?.value,
              label: (
                <div className="flex items-center space-x-2">
                  <span className="text-base">{lang?.flag}</span>
                  <span>{lang?.label}</span>
                </div>
              ),
              searchLabel: lang?.label // For search functionality
            }))}
            value={selectedLanguage}
            onChange={onLanguageChange}
            className="w-full"
          />
        </div>

        {/* OCR Language */}
        <div>
          <Select
            label={t?.ocrLanguage}
            description={t?.selectLanguage}
            options={ocrLanguages}
            value={ocrLanguage}
            onChange={onOcrLanguageChange}
            searchable
            className="w-full"
          />
        </div>
      </div>
      {/* Language Info */}
      <div className="mt-4 p-3 bg-muted/50 rounded-lg">
        <div className="flex items-start space-x-2">
          <Icon name="Info" size={16} className="text-primary mt-0.5" />
          <div className="text-xs font-caption text-muted-foreground">
            <p className="mb-1">
              <strong>Interface Language:</strong> Changes the app's display language
            </p>
            <p>
              <strong>OCR Language:</strong> Improves text extraction accuracy for specific languages. 
              Auto-detect works well for most documents.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LanguageSelector;