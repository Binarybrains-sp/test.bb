import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const UploadDropzone = ({ 
  onFilesSelected, 
  isUploading = false, 
  acceptedTypes = '.pdf,.jpg,.jpeg,.png,.webp',
  maxFileSize = 10,
  language = 'en'
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef(null);

  const translations = {
    en: {
      dragDrop: "Drag and drop your files here",
      or: "or",
      browse: "Browse Files",
      supportedFormats: "Supported formats: PDF, JPG, PNG, WebP",
      maxSize: `Max file size: ${maxFileSize}MB`,
      uploading: "Processing files..."
    },
    hi: {
      dragDrop: "अपनी फाइलें यहाँ खींचें और छोड़ें",
      or: "या",
      browse: "फाइलें चुनें",
      supportedFormats: "समर्थित प्रारूप: PDF, JPG, PNG, WebP",
      maxSize: `अधिकतम फाइल आकार: ${maxFileSize}MB`,
      uploading: "फाइलें प्रोसेस हो रही हैं..."
    },
    mr: {
      dragDrop: "तुमच्या फाइल्स इथे ड्रॅग आणि ड्रॉप करा",
      or: "किंवा",
      browse: "फाइल्स निवडा",
      supportedFormats: "समर्थित स्वरूप: PDF, JPG, PNG, WebP",
      maxSize: `कमाल फाइल आकार: ${maxFileSize}MB`,
      uploading: "फाइल्स प्रक्रिया करत आहेत..."
    }
  };

  const t = translations?.[language] || translations?.en;

  const handleDragOver = (e) => {
    e?.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e?.dataTransfer?.files);
    handleFiles(files);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e?.target?.files);
    handleFiles(files);
  };

  const handleFiles = (files) => {
    const validFiles = files?.filter(file => {
      const isValidType = acceptedTypes?.split(',')?.some(type => 
        file?.name?.toLowerCase()?.endsWith(type?.replace('.', ''))
      );
      const isValidSize = file?.size <= maxFileSize * 1024 * 1024;
      return isValidType && isValidSize;
    });

    if (validFiles?.length > 0) {
      onFilesSelected(validFiles);
    }
  };

  const handleBrowseClick = () => {
    fileInputRef?.current?.click();
  };

  return (
    <div className="w-full">
      <div
        className={`
          relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200
          ${isDragOver 
            ? 'border-primary bg-primary/5 scale-[1.02]' 
            : 'border-border hover:border-primary/50 hover:bg-muted/30'
          }
          ${isUploading ? 'pointer-events-none opacity-60' : 'cursor-pointer'}
        `}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleBrowseClick}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={acceptedTypes}
          onChange={handleFileSelect}
          className="hidden"
          disabled={isUploading}
        />

        {/* Upload Icon */}
        <div className="mb-4">
          <div className={`
            w-16 h-16 mx-auto rounded-full flex items-center justify-center transition-colors
            ${isDragOver ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}
          `}>
            <Icon 
              name={isUploading ? "Loader" : "CloudUpload"} 
              size={32} 
              className={isUploading ? "animate-spin" : ""}
            />
          </div>
        </div>

        {/* Upload Text */}
        <div className="space-y-2">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            {isUploading ? t?.uploading : t?.dragDrop}
          </h3>
          
          {!isUploading && (
            <>
              <p className="text-muted-foreground">{t?.or}</p>
              
              <Button
                variant="outline"
                onClick={handleBrowseClick}
                iconName="Upload"
                iconPosition="left"
                className="mt-4"
              >
                {t?.browse}
              </Button>
            </>
          )}
        </div>

        {/* File Format Info */}
        {!isUploading && (
          <div className="mt-6 pt-4 border-t border-border">
            <p className="text-sm text-muted-foreground mb-1">
              {t?.supportedFormats}
            </p>
            <p className="text-xs text-muted-foreground">
              {t?.maxSize}
            </p>
          </div>
        )}

        {/* Loading Overlay */}
        {isUploading && (
          <div className="absolute inset-0 bg-background/80 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Icon name="Loader" size={24} className="animate-spin text-primary mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">{t?.uploading}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UploadDropzone;