import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TextPreviewModal = ({ 
  isOpen, 
  onClose, 
  file, 
  language = 'en' 
}) => {
  const [activeTab, setActiveTab] = useState('extracted');

  const translations = {
    en: {
      textPreview: "Text Preview",
      extractedText: "Extracted Text",
      metadata: "Metadata",
      statistics: "Statistics",
      close: "Close",
      copyText: "Copy Text",
      downloadText: "Download as TXT",
      confidence: "Confidence",
      language: "Language",
      pages: "Pages",
      wordCount: "Word Count",
      characterCount: "Character Count",
      fileSize: "File Size",
      processingTime: "Processing Time",
      ocrEngine: "OCR Engine",
      textCopied: "Text copied to clipboard!",
      noTextAvailable: "No extracted text available"
    },
    hi: {
      textPreview: "टेक्स्ट पूर्वावलोकन",
      extractedText: "निकाला गया टेक्स्ट",
      metadata: "मेटाडेटा",
      statistics: "आंकड़े",
      close: "बंद करें",
      copyText: "टेक्स्ट कॉपी करें",
      downloadText: "TXT के रूप में डाउनलोड करें",
      confidence: "विश्वसनीयता",
      language: "भाषा",
      pages: "पृष्ठ",
      wordCount: "शब्द संख्या",
      characterCount: "अक्षर संख्या",
      fileSize: "फाइल का आकार",
      processingTime: "प्रोसेसिंग समय",
      ocrEngine: "OCR इंजन",
      textCopied: "टेक्स्ट क्लिपबोर्ड में कॉपी हो गया!",
      noTextAvailable: "कोई निकाला गया टेक्स्ट उपलब्ध नहीं"
    },
    mr: {
      textPreview: "मजकूर पूर्वावलोकन",
      extractedText: "काढलेला मजकूर",
      metadata: "मेटाडेटा",
      statistics: "आकडेवारी",
      close: "बंद करा",
      copyText: "मजकूर कॉपी करा",
      downloadText: "TXT म्हणून डाउनलोड करा",
      confidence: "विश्वसनीयता",
      language: "भाषा",
      pages: "पृष्ठे",
      wordCount: "शब्द संख्या",
      characterCount: "अक्षर संख्या",
      fileSize: "फाइल आकार",
      processingTime: "प्रक्रिया वेळ",
      ocrEngine: "OCR इंजिन",
      textCopied: "मजकूर क्लिपबोर्डमध्ये कॉपी झाला!",
      noTextAvailable: "काढलेला मजकूर उपलब्ध नाही"
    }
  };

  const t = translations?.[language] || translations?.en;

  if (!isOpen || !file) return null;

  const mockExtractedText = `Chapter 1: Introduction to Machine Learning

Machine learning is a subset of artificial intelligence (AI) that provides systems the ability to automatically learn and improve from experience without being explicitly programmed. Machine learning focuses on the development of computer programs that can access data and use it to learn for themselves.

The process of learning begins with observations or data, such as examples, direct experience, or instruction, in order to look for patterns in data and make better decisions in the future based on the examples that we provide. The primary aim is to allow the computers learn automatically without human intervention or assistance and adjust actions accordingly.

Key Concepts:
• Supervised Learning: Learning with labeled examples
• Unsupervised Learning: Finding patterns in data without labels  
• Reinforcement Learning: Learning through interaction with environment
• Deep Learning: Neural networks with multiple layers

Applications:
Machine learning is widely used in various domains including:
- Image recognition and computer vision
- Natural language processing
- Recommendation systems
- Fraud detection
- Medical diagnosis
- Autonomous vehicles

The field continues to evolve rapidly with new algorithms and techniques being developed to solve complex real-world problems.`;

  const mockMetadata = {
    confidence: 94.5,
    detectedLanguage: 'English',
    pages: file?.pages || 1,
    wordCount: 187,
    characterCount: 1245,
    processingTime: '2.3 seconds',
    ocrEngine: 'Tesseract 5.0'
  };

  const handleCopyText = async () => {
    try {
      await navigator.clipboard?.writeText(mockExtractedText);
      // You could show a toast notification here
      alert(t?.textCopied);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const handleDownloadText = () => {
    const element = document.createElement('a');
    const file = new Blob([mockExtractedText], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${file?.name}_extracted.txt`;
    document.body?.appendChild(element);
    element?.click();
    document.body?.removeChild(element);
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i))?.toFixed(2)) + ' ' + sizes?.[i];
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-modal flex items-center justify-center p-4">
      <div className="bg-card rounded-lg shadow-modal max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-heading font-semibold text-card-foreground">
                {t?.textPreview}
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                {file?.name}
              </p>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                onClick={handleCopyText}
                iconName="Copy"
                iconPosition="left"
              >
                {t?.copyText}
              </Button>
              
              <Button
                variant="outline"
                onClick={handleDownloadText}
                iconName="Download"
                iconPosition="left"
              >
                {t?.downloadText}
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
              >
                <Icon name="X" size={20} />
              </Button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex space-x-1 mt-4">
            <button
              onClick={() => setActiveTab('extracted')}
              className={`nav-tab ${activeTab === 'extracted' ? 'active' : ''}`}
            >
              <Icon name="FileText" size={16} className="mr-2" />
              {t?.extractedText}
            </button>
            <button
              onClick={() => setActiveTab('metadata')}
              className={`nav-tab ${activeTab === 'metadata' ? 'active' : ''}`}
            >
              <Icon name="Info" size={16} className="mr-2" />
              {t?.metadata}
            </button>
            <button
              onClick={() => setActiveTab('statistics')}
              className={`nav-tab ${activeTab === 'statistics' ? 'active' : ''}`}
            >
              <Icon name="BarChart3" size={16} className="mr-2" />
              {t?.statistics}
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'extracted' && (
            <div>
              {mockExtractedText ? (
                <div className="bg-muted p-4 rounded-lg">
                  <pre className="whitespace-pre-wrap text-sm font-caption text-foreground leading-relaxed">
                    {mockExtractedText}
                  </pre>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Icon name="FileX" size={48} className="text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">{t?.noTextAvailable}</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'metadata' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.confidence}:</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-muted rounded-full h-2">
                        <div 
                          className="progress-indicator h-2 rounded-full"
                          style={{ width: `${mockMetadata?.confidence}%` }}
                        />
                      </div>
                      <span className="text-sm font-data text-foreground">{mockMetadata?.confidence}%</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.language}:</span>
                    <span className="text-sm text-foreground">{mockMetadata?.detectedLanguage}</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.pages}:</span>
                    <span className="text-sm text-foreground">{mockMetadata?.pages}</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.processingTime}:</span>
                    <span className="text-sm text-foreground">{mockMetadata?.processingTime}</span>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.wordCount}:</span>
                    <span className="text-sm text-foreground">{mockMetadata?.wordCount?.toLocaleString()}</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.characterCount}:</span>
                    <span className="text-sm text-foreground">{mockMetadata?.characterCount?.toLocaleString()}</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.fileSize}:</span>
                    <span className="text-sm text-foreground">{formatFileSize(file?.size)}</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-sm font-medium text-muted-foreground">{t?.ocrEngine}:</span>
                    <span className="text-sm text-foreground">{mockMetadata?.ocrEngine}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'statistics' && (
            <div className="space-y-6">
              {/* Text Statistics */}
              <div>
                <h4 className="text-sm font-heading font-medium text-card-foreground mb-4">
                  Text Analysis
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-data font-bold text-primary">
                      {mockMetadata?.wordCount}
                    </div>
                    <div className="text-xs text-muted-foreground">Words</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-data font-bold text-success">
                      {mockMetadata?.characterCount}
                    </div>
                    <div className="text-xs text-muted-foreground">Characters</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-data font-bold text-warning">
                      {Math.round(mockMetadata?.wordCount / mockMetadata?.pages)}
                    </div>
                    <div className="text-xs text-muted-foreground">Words/Page</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-data font-bold text-error">
                      {mockMetadata?.confidence}%
                    </div>
                    <div className="text-xs text-muted-foreground">Accuracy</div>
                  </div>
                </div>
              </div>

              {/* Quality Metrics */}
              <div>
                <h4 className="text-sm font-heading font-medium text-card-foreground mb-4">
                  Quality Metrics
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Text Clarity</span>
                      <span className="font-data text-foreground">92%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-success h-2 rounded-full" style={{ width: '92%' }} />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Language Detection</span>
                      <span className="font-data text-foreground">98%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: '98%' }} />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Structure Recognition</span>
                      <span className="font-data text-foreground">87%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-warning h-2 rounded-full" style={{ width: '87%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TextPreviewModal;