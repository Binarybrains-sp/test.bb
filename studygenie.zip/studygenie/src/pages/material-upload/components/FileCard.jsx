import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const FileCard = ({ 
  file, 
  onGenerateContent, 
  onPreviewText, 
  onDelete, 
  onRetry,
  language = 'en'
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const translations = {
    en: {
      pages: "pages",
      uploaded: "Uploaded",
      processing: "Processing...",
      completed: "Ready",
      failed: "Failed",
      generateContent: "Generate Content",
      previewText: "Preview Text",
      delete: "Delete",
      retry: "Retry",
      extracting: "Extracting text...",
      analyzing: "Analyzing content...",
      viewDetails: "View Details",
      hideDetails: "Hide Details",
      fileSize: "File Size",
      lastModified: "Last Modified",
      ocrLanguage: "OCR Language",
      extractedText: "Extracted Text",
      confidence: "Confidence"
    },
    hi: {
      pages: "पृष्ठ",
      uploaded: "अपलोड किया गया",
      processing: "प्रोसेसिंग...",
      completed: "तैयार",
      failed: "असफल",
      generateContent: "सामग्री बनाएं",
      previewText: "टेक्स्ट देखें",
      delete: "हटाएं",
      retry: "पुनः प्रयास",
      extracting: "टेक्स्ट निकाला जा रहा है...",
      analyzing: "सामग्री का विश्लेषण...",
      viewDetails: "विवरण देखें",
      hideDetails: "विवरण छुपाएं",
      fileSize: "फाइल का आकार",
      lastModified: "अंतिम संशोधन",
      ocrLanguage: "OCR भाषा",
      extractedText: "निकाला गया टेक्स्ट",
      confidence: "विश्वसनीयता"
    },
    mr: {
      pages: "पृष्ठे",
      uploaded: "अपलोड केले",
      processing: "प्रक्रिया करत आहे...",
      completed: "तयार",
      failed: "अयशस्वी",
      generateContent: "सामग्री तयार करा",
      previewText: "मजकूर पहा",
      delete: "हटवा",
      retry: "पुन्हा प्रयत्न करा",
      extracting: "मजकूर काढत आहे...",
      analyzing: "सामग्रीचे विश्लेषण...",
      viewDetails: "तपशील पहा",
      hideDetails: "तपशील लपवा",
      fileSize: "फाइल आकार",
      lastModified: "शेवटचा बदल",
      ocrLanguage: "OCR भाषा",
      extractedText: "काढलेला मजकूर",
      confidence: "विश्वसनीयता"
    }
  };

  const t = translations?.[language] || translations?.en;

  const getStatusIcon = () => {
    switch (file?.status) {
      case 'uploading':
        return 'Upload';
      case 'processing':
        return 'Loader';
      case 'extracting':
        return 'FileText';
      case 'analyzing':
        return 'Brain';
      case 'completed':
        return 'CheckCircle';
      case 'failed':
        return 'AlertCircle';
      default:
        return 'File';
    }
  };

  const getStatusColor = () => {
    switch (file?.status) {
      case 'uploading': case'processing': case'extracting': case'analyzing':
        return 'text-primary';
      case 'completed':
        return 'text-success';
      case 'failed':
        return 'text-error';
      default:
        return 'text-muted-foreground';
    }
  };

  const getStatusText = () => {
    switch (file?.status) {
      case 'uploading':
        return t?.uploaded;
      case 'processing':
        return t?.processing;
      case 'extracting':
        return t?.extracting;
      case 'analyzing':
        return t?.analyzing;
      case 'completed':
        return t?.completed;
      case 'failed':
        return t?.failed;
      default:
        return file?.status;
    }
  };

  const isProcessing = ['uploading', 'processing', 'extracting', 'analyzing']?.includes(file?.status);
  const canGenerateContent = file?.status === 'completed';
  const canRetry = file?.status === 'failed';

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i))?.toFixed(2)) + ' ' + sizes?.[i];
  };

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-GB');
  };

  return (
    <div className="study-card p-4">
      <div className="flex items-start space-x-4">
        {/* File Thumbnail */}
        <div className="flex-shrink-0">
          <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
            {file?.thumbnail ? (
              <Image 
                src={file?.thumbnail} 
                alt={file?.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <Icon 
                name={file?.type === 'pdf' ? 'FileText' : 'Image'} 
                size={20} 
                className="text-muted-foreground"
              />
            )}
          </div>
        </div>

        {/* File Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="min-w-0 flex-1">
              <h3 className="text-sm font-heading font-semibold text-foreground truncate">
                {file?.name}
              </h3>
              <div className="flex items-center space-x-3 mt-1 text-xs font-caption text-muted-foreground">
                <span>{formatFileSize(file?.size)}</span>
                {file?.pages && (
                  <span>{file?.pages} {t?.pages}</span>
                )}
                <span>{formatDate(file?.uploadDate)}</span>
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center space-x-2 ml-4">
              <Icon 
                name={getStatusIcon()} 
                size={16} 
                className={`${getStatusColor()} ${isProcessing ? 'animate-spin' : ''}`}
              />
              <span className={`text-xs font-caption ${getStatusColor()}`}>
                {getStatusText()}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          {isProcessing && file?.progress !== undefined && (
            <div className="mt-3">
              <div className="flex items-center justify-between text-xs font-data mb-1">
                <span className="text-muted-foreground">
                  {file?.currentStep || t?.processing}
                </span>
                <span className="text-muted-foreground">
                  {file?.progress}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-1">
                <div 
                  className="progress-indicator h-1 rounded-full"
                  style={{ width: `${file?.progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Error Message */}
          {file?.status === 'failed' && file?.errorMessage && (
            <div className="mt-2 p-2 bg-error/10 border border-error/20 rounded text-xs text-error">
              {file?.errorMessage}
            </div>
          )}

          {/* OCR Results Preview */}
          {file?.status === 'completed' && file?.ocrResults && (
            <div className="mt-3">
              <div className="flex items-center space-x-4 text-xs font-caption text-muted-foreground">
                {file?.ocrResults?.language && (
                  <span className="flex items-center space-x-1">
                    <Icon name="Globe" size={12} />
                    <span>{file?.ocrResults?.language}</span>
                  </span>
                )}
                {file?.ocrResults?.confidence && (
                  <span className="flex items-center space-x-1">
                    <Icon name="Target" size={12} />
                    <span>{file?.ocrResults?.confidence}% {t?.confidence}</span>
                  </span>
                )}
                {file?.ocrResults?.wordCount && (
                  <span>{file?.ocrResults?.wordCount} words</span>
                )}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center space-x-2 mt-4">
            {canGenerateContent && (
              <Button
                variant="default"
                size="sm"
                onClick={() => onGenerateContent(file)}
                iconName="Sparkles"
                iconPosition="left"
              >
                {t?.generateContent}
              </Button>
            )}
            
            {file?.status === 'completed' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onPreviewText(file)}
                iconName="Eye"
                iconPosition="left"
              >
                {t?.previewText}
              </Button>
            )}
            
            {canRetry && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onRetry(file)}
                iconName="RotateCcw"
                iconPosition="left"
              >
                {t?.retry}
              </Button>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
              iconPosition="left"
              className="hidden sm:flex"
            >
              {isExpanded ? t?.hideDetails : t?.viewDetails}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(file)}
              className="text-error hover:text-error"
            >
              <Icon name="Trash2" size={16} />
            </Button>
          </div>

          {/* Expanded Details */}
          {isExpanded && (
            <div className="mt-4 pt-4 border-t border-border">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-medium text-foreground mb-2">File Details</h4>
                  <div className="space-y-1 text-xs font-caption text-muted-foreground">
                    <div className="flex justify-between">
                      <span>{t?.fileSize}:</span>
                      <span>{formatFileSize(file?.size)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{t?.lastModified}:</span>
                      <span>{formatDate(file?.lastModified || file?.uploadDate)}</span>
                    </div>
                    {file?.ocrResults?.language && (
                      <div className="flex justify-between">
                        <span>{t?.ocrLanguage}:</span>
                        <span>{file?.ocrResults?.language}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                {file?.ocrResults?.preview && (
                  <div>
                    <h4 className="font-medium text-foreground mb-2">{t?.extractedText}</h4>
                    <div className="text-xs text-muted-foreground bg-muted p-2 rounded max-h-20 overflow-y-auto">
                      {file?.ocrResults?.preview}...
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FileCard;