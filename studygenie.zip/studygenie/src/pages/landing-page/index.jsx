import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';

// Components
import LandingHeader from './components/LandingHeader';
import HeroSection from './components/HeroSection';
import FeatureShowcase from './components/FeatureShowcase';
import SocialProofSection from './components/SocialProofSection';
import InteractiveDemoSection from './components/InteractiveDemoSection';
import LandingFooter from './components/LandingFooter';
import StickyCtaBar from './components/StickyCtaBar';

const LandingPage = () => {
  useEffect(() => {
    // Smooth scroll behavior for anchor links
    const handleAnchorClick = (e) => {
      const href = e?.target?.getAttribute('href');
      if (href && href?.startsWith('#')) {
        e?.preventDefault();
        const element = document.querySelector(href);
        element?.scrollIntoView({ behavior: 'smooth' });
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <>
      <Helmet>
        <title>StudyGenie - AI-Powered Learning Platform | Transform Study Materials</title>
        <meta 
          name="description" 
          content="Transform PDFs, images, and handwritten notes into interactive flashcards and quizzes with AI. Join 50,000+ students using StudyGenie for personalized learning with spaced repetition and multilingual support." 
        />
        <meta name="keywords" content="AI study platform, flashcards generator, quiz maker, spaced repetition, multilingual learning, PDF to flashcards, study materials, personalized tutoring" />
        <meta property="og:title" content="StudyGenie - AI-Powered Learning Platform" />
        <meta property="og:description" content="Transform your study materials into interactive learning experiences with AI-powered flashcards, quizzes, and personalized tutoring." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://studygenie.in" />
        <meta property="og:image" content="https://studygenie.in/og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="StudyGenie - AI-Powered Learning Platform" />
        <meta name="twitter:description" content="Transform your study materials into interactive learning experiences with AI." />
        <link rel="canonical" href="https://studygenie.in" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "StudyGenie",
            "description": "AI-powered learning platform that transforms study materials into interactive content",
            "url": "https://studygenie.in",
            "applicationCategory": "EducationalApplication",
            "operatingSystem": "Web Browser",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "INR"
            }
          })}
        </script>
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header */}
        <LandingHeader />

        {/* Main Content */}
        <main>
          {/* Hero Section */}
          <HeroSection />

          {/* Feature Showcase */}
          <section id="features">
            <FeatureShowcase />
          </section>

          {/* Social Proof */}
          <section id="testimonials">
            <SocialProofSection />
          </section>

          {/* Interactive Demo */}
          <InteractiveDemoSection />
        </main>

        {/* Footer */}
        <LandingFooter />

        {/* Sticky CTA Bar */}
        <StickyCtaBar />
      </div>
    </>
  );
};

export default LandingPage;