import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

import Button from '../../../components/ui/Button';

const InteractiveDemoSection = () => {
  const navigate = useNavigate();
  const [isDemoActive, setIsDemoActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [uploadedFile, setUploadedFile] = useState(null);

  const demoSteps = [
    {
      title: "Upload Your Material",
      description: "Drop a PDF, image, or handwritten notes",
      action: "upload"
    },
    {
      title: "AI Processing",
      description: "Our AI analyzes and extracts key concepts",
      action: "process"
    },
    {
      title: "Generate Content",
      description: "Flashcards and quizzes are created instantly",
      action: "generate"
    },
    {
      title: "Start Learning",
      description: "Begin your personalized study session",
      action: "learn"
    }
  ];

  const sampleFlashcards = [
    {
      id: 1,
      front: "What is photosynthesis?",
      back: "The process by which plants convert light energy into chemical energy (glucose) using carbon dioxide and water.",
      subject: "Biology",
      difficulty: "Medium"
    },
    {
      id: 2,
      front: "Newton\'s First Law of Motion",
      back: "An object at rest stays at rest and an object in motion stays in motion unless acted upon by an external force.",
      subject: "Physics",
      difficulty: "Easy"
    },
    {
      id: 3,
      front: "What is the derivative of x²?",
      back: "The derivative of x² is 2x, using the power rule where d/dx(xⁿ) = nxⁿ⁻¹",
      subject: "Mathematics",
      difficulty: "Easy"
    }
  ];

  const handleFileUpload = (event) => {
    const file = event?.target?.files?.[0];
    if (file) {
      setUploadedFile(file);
      setIsDemoActive(true);
      setCurrentStep(0);
      simulateDemo();
    }
  };

  const simulateDemo = () => {
    const steps = [1, 2, 3];
    steps?.forEach((step, index) => {
      setTimeout(() => {
        setCurrentStep(step);
      }, (index + 1) * 2000);
    });
  };

  const handleStartDemo = () => {
    setIsDemoActive(true);
    setCurrentStep(0);
    setUploadedFile({ name: "sample-biology-notes.pdf", size: "2.4 MB" });
    simulateDemo();
  };

  const handleTryFull = () => {
    navigate('/material-upload');
  };

  return (
    <section id="interactive-demo" className="py-20 bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-accent/10 rounded-full text-accent text-sm font-medium mb-4">
            <Icon name="Play" size={16} className="mr-2" />
            Interactive Demo
          </div>
          <h2 className="text-3xl lg:text-5xl font-heading font-bold text-foreground mb-6">
            See StudyGenie in
            <span className="text-primary block">Action</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Experience the magic of AI-powered learning. Upload a sample document and watch 
            as it transforms into interactive study materials in real-time.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Demo Interface */}
            <div className="order-2 lg:order-1">
              <div className="study-card p-8">
                <h3 className="text-2xl font-heading font-bold text-card-foreground mb-6">
                  Try It Yourself
                </h3>

                {!isDemoActive ? (
                  <DemoUploadArea 
                    onFileUpload={handleFileUpload}
                    onStartDemo={handleStartDemo}
                  />
                ) : (
                  <DemoProgress 
                    currentStep={currentStep}
                    uploadedFile={uploadedFile}
                    flashcards={sampleFlashcards}
                    onTryFull={handleTryFull}
                  />
                )}
              </div>
            </div>

            {/* Process Steps */}
            <div className="order-1 lg:order-2">
              <div className="space-y-6">
                {demoSteps?.map((step, index) => (
                  <div
                    key={index}
                    className={`flex items-start space-x-4 p-4 rounded-lg transition-all ${
                      isDemoActive && currentStep >= index
                        ? 'bg-primary/10 border border-primary/20' :'bg-muted/30'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                        isDemoActive && currentStep >= index
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {isDemoActive && currentStep > index ? (
                        <Icon name="Check" size={20} />
                      ) : (
                        <span className="text-sm font-bold">{index + 1}</span>
                      )}
                    </div>
                    <div>
                      <h4 className="font-heading font-semibold text-foreground mb-1">
                        {step?.title}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {step?.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Benefits */}
              <div className="mt-8 p-6 bg-success/10 rounded-lg border border-success/20">
                <h4 className="font-heading font-semibold text-success mb-4 flex items-center">
                  <Icon name="Sparkles" size={20} className="mr-2" />
                  What You'll Get
                </h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center text-muted-foreground">
                    <Icon name="Check" size={14} className="text-success mr-2" />
                    Instant flashcard generation
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Icon name="Check" size={14} className="text-success mr-2" />
                    Multiple choice quizzes
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Icon name="Check" size={14} className="text-success mr-2" />
                    AI-powered summaries
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Icon name="Check" size={14} className="text-success mr-2" />
                    Personalized study plan
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const DemoUploadArea = ({ onFileUpload, onStartDemo }) => {
  return (
    <div className="text-center">
      <div className="border-2 border-dashed border-primary/30 rounded-lg p-12 mb-6 hover:border-primary/50 transition-colors">
        <Icon name="Upload" size={48} className="text-primary mx-auto mb-4" />
        <h4 className="text-lg font-heading font-semibold text-foreground mb-2">
          Upload Your Study Material
        </h4>
        <p className="text-muted-foreground mb-6">
          Drop a PDF, image, or handwritten notes to see the magic happen
        </p>
        
        <input
          type="file"
          accept=".pdf,.jpg,.jpeg,.png"
          onChange={onFileUpload}
          className="hidden"
          id="demo-file-upload"
        />
        <label htmlFor="demo-file-upload">
          <Button
            variant="outline"
            iconName="Upload"
            iconPosition="left"
            className="cursor-pointer"
            asChild
          >
            <span>Choose File</span>
          </Button>
        </label>
      </div>

      <div className="flex items-center mb-6">
        <div className="flex-1 h-px bg-border"></div>
        <span className="px-4 text-sm text-muted-foreground">or</span>
        <div className="flex-1 h-px bg-border"></div>
      </div>

      <Button
        variant="default"
        onClick={onStartDemo}
        iconName="Play"
        iconPosition="left"
        size="lg"
      >
        Try Sample Demo
      </Button>
    </div>
  );
};

const DemoProgress = ({ currentStep, uploadedFile, flashcards, onTryFull }) => {
  const [currentCard, setCurrentCard] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  if (currentStep < 3) {
    return (
      <div className="text-center">
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <Icon name="Loader" size={32} className="text-primary animate-spin" />
        </div>
        <h4 className="text-lg font-heading font-semibold text-foreground mb-2">
          Processing {uploadedFile?.name}
        </h4>
        <p className="text-muted-foreground mb-6">
          {currentStep === 0 && "Uploading file..."}
          {currentStep === 1 && "Analyzing content with AI..."}
          {currentStep === 2 && "Generating flashcards and quizzes..."}
        </p>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="progress-indicator h-2 rounded-full transition-all duration-1000"
            style={{ width: `${((currentStep + 1) / 4) * 100}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h4 className="text-lg font-heading font-semibold text-foreground">
          Generated Flashcards
        </h4>
        <div className="text-sm text-muted-foreground">
          {currentCard + 1} of {flashcards?.length}
        </div>
      </div>
      {/* Flashcard */}
      <div 
        className="relative h-64 mb-6 cursor-pointer"
        onClick={() => setIsFlipped(!isFlipped)}
      >
        <div className={`absolute inset-0 w-full h-full transition-transform duration-500 preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
          {/* Front */}
          <div className="absolute inset-0 w-full h-full bg-card border border-border rounded-lg p-6 flex items-center justify-center backface-hidden">
            <div className="text-center">
              <p className="text-lg font-medium text-card-foreground mb-4">
                {flashcards?.[currentCard]?.front}
              </p>
              <div className="text-xs text-muted-foreground">
                Click to reveal answer
              </div>
            </div>
          </div>
          
          {/* Back */}
          <div className="absolute inset-0 w-full h-full bg-primary/5 border border-primary/20 rounded-lg p-6 flex items-center justify-center backface-hidden rotate-y-180">
            <div className="text-center">
              <p className="text-card-foreground mb-4">
                {flashcards?.[currentCard]?.back}
              </p>
              <div className="flex items-center justify-center space-x-4 text-xs">
                <span className="px-2 py-1 bg-primary/10 rounded text-primary">
                  {flashcards?.[currentCard]?.subject}
                </span>
                <span className="px-2 py-1 bg-warning/10 rounded text-warning">
                  {flashcards?.[currentCard]?.difficulty}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Navigation */}
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="outline"
          onClick={() => {
            setCurrentCard(Math.max(0, currentCard - 1));
            setIsFlipped(false);
          }}
          disabled={currentCard === 0}
          iconName="ChevronLeft"
          iconPosition="left"
        >
          Previous
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            setCurrentCard(Math.min(flashcards?.length - 1, currentCard + 1));
            setIsFlipped(false);
          }}
          disabled={currentCard === flashcards?.length - 1}
          iconName="ChevronRight"
          iconPosition="right"
        >
          Next
        </Button>
      </div>
      {/* CTA */}
      <div className="text-center">
        <Button
          variant="default"
          onClick={onTryFull}
          iconName="ArrowRight"
          iconPosition="right"
          size="lg"
          fullWidth
        >
          Try Full Version
        </Button>
      </div>
    </div>
  );
};

export default InteractiveDemoSection;