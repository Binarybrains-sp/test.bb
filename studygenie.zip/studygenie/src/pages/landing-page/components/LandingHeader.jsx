import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LandingHeader = () => {
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  const navigationItems = [
    { label: 'Features', href: '#features', icon: 'Star' },
    { label: 'Demo', href: '#interactive-demo', icon: 'Play' },
    { label: 'Testimonials', href: '#testimonials', icon: 'Users' },
    { label: 'Pricing', href: '#pricing', icon: 'CreditCard' }
  ];

  const languages = [
    { code: 'en', label: 'English', flag: '🇺🇸' },
    { code: 'hi', label: 'हिंदी', flag: '🇮🇳' },
    { code: 'mr', label: 'मराठी', flag: '🇮🇳' }
  ];

  const handleNavigation = (href) => {
    if (href?.startsWith('#')) {
      const element = document.querySelector(href);
      element?.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate(href);
    }
    setIsMobileMenuOpen(false);
  };

  const handleLogin = () => {
    navigate('/dashboard');
  };

  const handleSignup = () => {
    navigate('/dashboard');
  };

  const Logo = () => (
    <div className="flex items-center space-x-2">
      <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
        <Icon name="GraduationCap" size={24} color="white" />
      </div>
      <div>
        <span className="text-2xl font-heading font-bold text-foreground">
          StudyGenie
        </span>
        <div className="text-xs text-primary font-medium">AI-Powered Learning</div>
      </div>
    </div>
  );

  return (
    <header className="fixed top-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-b border-border z-navigation">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Logo />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navigationItems?.map((item) => (
              <button
                key={item?.label}
                onClick={() => handleNavigation(item?.href)}
                className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors font-medium"
              >
                <Icon name={item?.icon} size={16} />
                <span>{item?.label}</span>
              </button>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            {/* Language Selector */}
            <div className="relative group">
              <button className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-muted transition-colors">
                <span className="text-lg">
                  {languages?.find(lang => lang?.code === selectedLanguage)?.flag}
                </span>
                <span className="text-sm font-medium text-foreground">
                  {languages?.find(lang => lang?.code === selectedLanguage)?.label}
                </span>
                <Icon name="ChevronDown" size={14} />
              </button>
              
              <div className="absolute right-0 top-full mt-2 w-40 bg-popover border border-border rounded-lg shadow-modal opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                <div className="py-2">
                  {languages?.map((language) => (
                    <button
                      key={language?.code}
                      onClick={() => setSelectedLanguage(language?.code)}
                      className={`w-full flex items-center space-x-3 px-4 py-2 text-sm hover:bg-muted transition-colors ${
                        selectedLanguage === language?.code ? 'bg-muted' : ''
                      }`}
                    >
                      <span>{language?.flag}</span>
                      <span>{language?.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <Button
              variant="ghost"
              onClick={handleLogin}
            >
              Login
            </Button>
            <Button
              variant="default"
              onClick={handleSignup}
              iconName="ArrowRight"
              iconPosition="right"
            >
              Start Free
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <Icon name={isMobileMenuOpen ? 'X' : 'Menu'} size={20} />
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-background border-t border-border">
            <nav className="px-4 py-6 space-y-4">
              {navigationItems?.map((item) => (
                <button
                  key={item?.label}
                  onClick={() => handleNavigation(item?.href)}
                  className="w-full flex items-center space-x-3 px-4 py-3 text-left text-foreground hover:bg-muted rounded-lg transition-colors"
                >
                  <Icon name={item?.icon} size={18} />
                  <span className="font-medium">{item?.label}</span>
                </button>
              ))}
              
              <div className="border-t border-border pt-4 mt-4">
                {/* Mobile Language Selector */}
                <div className="mb-4">
                  <p className="text-sm font-medium text-muted-foreground mb-2">Language</p>
                  <div className="grid grid-cols-3 gap-2">
                    {languages?.map((language) => (
                      <button
                        key={language?.code}
                        onClick={() => setSelectedLanguage(language?.code)}
                        className={`flex items-center justify-center space-x-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                          selectedLanguage === language?.code
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted text-muted-foreground hover:bg-muted/80'
                        }`}
                      >
                        <span>{language?.flag}</span>
                        <span>{language?.code?.toUpperCase()}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Mobile Actions */}
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    fullWidth
                    onClick={handleLogin}
                  >
                    Login
                  </Button>
                  <Button
                    variant="default"
                    fullWidth
                    onClick={handleSignup}
                    iconName="ArrowRight"
                    iconPosition="right"
                  >
                    Start Free
                  </Button>
                </div>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default LandingHeader;