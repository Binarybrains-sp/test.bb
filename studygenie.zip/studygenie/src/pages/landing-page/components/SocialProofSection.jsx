import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const SocialProofSection = () => {
  const testimonials = [
    {
      id: 1,
      name: "Priya Sharma",
      role: "NEET Aspirant",
      location: "Mumbai, Maharashtra",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: `StudyGenie ने मेरी NEET की तैयारी को बिल्कुल बदल दिया है। अब मैं अपने नोट्स को flashcards में convert कर सकती हूं और AI tutor से doubt clear कर सकती हूं।`,
      achievement: "Improved score by 40%",
      language: "hi"
    },
    {
      id: 2,
      name: "Arjun Patel",
      role: "Engineering Student",
      location: "Pune, Maharashtra",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "The spaced repetition feature is incredible! I can actually remember complex engineering concepts for my exams. The multilingual support helps me understand better in Marathi.",
      achievement: "95% retention rate",
      language: "en"
    },
    {
      id: 3,
      name: "Sneha Deshmukh",
      role: "CA Student",
      location: "Nagpur, Maharashtra",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: `CA च्या अभ्यासासाठी हे app खूप उपयुक्त आहे। PDF upload करून लगेच quiz मिळतात आणि weak areas identify होतात।`,
      achievement: "Cleared CA Inter",
      language: "mr"
    },
    {
      id: 4,
      name: "Rahul Kumar",
      role: "JEE Aspirant",
      location: "Delhi",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "The AI explanations are so detailed! I love the ELI5 mode - it breaks down complex physics problems into simple analogies that I can actually understand.",
      achievement: "JEE Main 98.5 percentile",
      language: "en"
    },
    {
      id: 5,
      name: "Anita Singh",
      role: "Medical Student",
      location: "Lucknow, UP",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Anatomy और Physiology के लिए यह app बहुत helpful है। Handwritten notes को भी recognize करता है और perfect flashcards बनाता है।",
      achievement: "Top 5% in batch",
      language: "hi"
    },
    {
      id: 6,
      name: "Vikram Joshi",
      role: "MBA Student",
      location: "Bangalore, Karnataka",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Perfect for case study preparation! The AI tutor helps me analyze business scenarios and the gamification keeps me motivated during long study sessions.",
      achievement: "Dean\'s List 3 semesters",
      language: "en"
    }
  ];

  const stats = [
    { number: "50,000+", label: "Active Students", icon: "Users" },
    { number: "2M+", label: "Flashcards Created", icon: "BookOpen" },
    { number: "95%", label: "Success Rate", icon: "TrendingUp" },
    { number: "4.9/5", label: "Average Rating", icon: "Star" }
  ];

  const universities = [
    { name: "IIT Delhi", logo: "https://images.unsplash.com/photo-1562774053-701939374585?w=120&h=60&fit=crop" },
    { name: "Mumbai University", logo: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=120&h=60&fit=crop" },
    { name: "AIIMS", logo: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=120&h=60&fit=crop" },
    { name: "Pune University", logo: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=120&h=60&fit=crop" }
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-success/10 rounded-full text-success text-sm font-medium mb-4">
            <Icon name="Heart" size={16} className="mr-2" />
            Loved by Students
          </div>
          <h2 className="text-3xl lg:text-5xl font-heading font-bold text-foreground mb-6">
            Join Thousands of
            <span className="text-primary block">Successful Students</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Students across India are achieving their academic goals with StudyGenie. 
            See what they have to say about their learning journey.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats?.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name={stat?.icon} size={24} className="text-primary" />
              </div>
              <div className="text-3xl font-heading font-bold text-foreground mb-2">
                {stat?.number}
              </div>
              <div className="text-sm text-muted-foreground">
                {stat?.label}
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {testimonials?.map((testimonial) => (
            <TestimonialCard key={testimonial?.id} testimonial={testimonial} />
          ))}
        </div>

        {/* University Partnerships */}
        <div className="text-center">
          <h3 className="text-xl font-heading font-semibold text-foreground mb-8">
            Trusted by Students from Top Institutions
          </h3>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            {universities?.map((university, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Image
                  src={university?.logo}
                  alt={university?.name}
                  className="w-12 h-12 object-contain grayscale hover:grayscale-0 transition-all"
                />
                <span className="text-sm font-medium text-muted-foreground">
                  {university?.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const TestimonialCard = ({ testimonial }) => {
  return (
    <div className="study-card p-6 h-full">
      {/* Rating */}
      <div className="flex items-center mb-4">
        {[...Array(testimonial?.rating)]?.map((_, i) => (
          <Icon key={i} name="Star" size={16} className="text-warning fill-current" />
        ))}
      </div>
      {/* Testimonial Text */}
      <blockquote className="text-muted-foreground mb-6 leading-relaxed">
        "{testimonial?.text}"
      </blockquote>
      {/* Achievement Badge */}
      <div className="inline-flex items-center px-3 py-1 bg-success/10 rounded-full text-success text-xs font-medium mb-4">
        <Icon name="Trophy" size={12} className="mr-1" />
        {testimonial?.achievement}
      </div>
      {/* User Info */}
      <div className="flex items-center">
        <Image
          src={testimonial?.image}
          alt={testimonial?.name}
          className="w-12 h-12 rounded-full object-cover mr-4"
        />
        <div>
          <h4 className="font-heading font-semibold text-card-foreground">
            {testimonial?.name}
          </h4>
          <p className="text-sm text-muted-foreground">
            {testimonial?.role}
          </p>
          <p className="text-xs text-muted-foreground flex items-center">
            <Icon name="MapPin" size={12} className="mr-1" />
            {testimonial?.location}
          </p>
        </div>
      </div>
    </div>
  );
};

export default SocialProofSection;