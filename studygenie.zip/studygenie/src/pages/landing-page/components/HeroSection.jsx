import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const HeroSection = () => {
  const navigate = useNavigate();
  const [currentDemo, setCurrentDemo] = useState(0);

  const demoSteps = [
    {
      title: "Upload Your Study Material",
      description: "Drop any PDF, image, or handwritten notes",
      icon: "Upload",
      image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=300&fit=crop"
    },
    {
      title: "AI Analyzes Content",
      description: "Our AI extracts key concepts and information",
      icon: "Brain",
      image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?w=400&h=300&fit=crop"
    },
    {
      title: "Generate Interactive Content",
      description: "Get flashcards, quizzes, and summaries instantly",
      icon: "Zap",
      image: "https://images.pixabay.com/photo/2016/11/29/06/15/adult-1867743_960_720.jpg?w=400&h=300&fit=crop"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDemo((prev) => (prev + 1) % demoSteps?.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleStartLearning = () => {
    navigate('/dashboard');
  };

  const handleSeeDemo = () => {
    const demoSection = document.getElementById('interactive-demo');
    demoSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-gradient-to-br from-primary/5 via-background to-secondary/5 min-h-screen flex items-center">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-6">
              <Icon name="Sparkles" size={16} className="mr-2" />
              AI-Powered Learning Platform
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-heading font-bold text-foreground mb-6 leading-tight">
              Transform Your
              <span className="text-primary block">Study Materials</span>
              Into Interactive Learning
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
              Upload PDFs, images, or handwritten notes and instantly generate flashcards, quizzes, and summaries. 
              Study smarter with AI-powered personalized tutoring and spaced repetition.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <Button
                variant="default"
                size="lg"
                onClick={handleStartLearning}
                iconName="ArrowRight"
                iconPosition="right"
                className="text-lg px-8 py-4"
              >
                Start Learning Free
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleSeeDemo}
                iconName="Play"
                iconPosition="left"
                className="text-lg px-8 py-4"
              >
                See Demo
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Icon name="Users" size={16} />
                <span>50,000+ Students</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Star" size={16} className="text-warning" />
                <span>4.9/5 Rating</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Shield" size={16} className="text-success" />
                <span>Secure & Private</span>
              </div>
            </div>
          </div>

          {/* Demo Animation */}
          <div className="relative">
            <div className="bg-card rounded-2xl shadow-modal p-6 border border-border">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-heading font-semibold text-card-foreground">
                  {demoSteps?.[currentDemo]?.title}
                </h3>
                <div className={`w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center`}>
                  <Icon name={demoSteps?.[currentDemo]?.icon} size={24} className="text-primary" />
                </div>
              </div>
              
              <p className="text-muted-foreground mb-4">
                {demoSteps?.[currentDemo]?.description}
              </p>
              
              <div className="relative h-48 bg-muted rounded-lg overflow-hidden">
                <Image
                  src={demoSteps?.[currentDemo]?.image}
                  alt={demoSteps?.[currentDemo]?.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              </div>

              {/* Progress Indicators */}
              <div className="flex justify-center space-x-2 mt-4">
                {demoSteps?.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentDemo(index)}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentDemo ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-warning/20 rounded-full blur-xl animate-pulse" />
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-success/20 rounded-full blur-xl animate-pulse delay-1000" />
          </div>
        </div>
      </div>
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <Icon name="ChevronDown" size={24} className="text-muted-foreground" />
      </div>
    </section>
  );
};

export default HeroSection;