import React from 'react';
import Icon from '../../../components/AppIcon';

const FeatureShowcase = () => {
  const features = [
    {
      icon: "Brain",
      title: "AI-Powered Tutoring",
      description: "Get personalized explanations and answers from your study materials with our intelligent RAG-powered tutor.",
      benefits: ["24/7 availability", "Contextual answers", "Multiple explanation levels"],
      color: "text-primary"
    },
    {
      icon: "RotateCcw",
      title: "Spaced Repetition",
      description: "Scientifically proven algorithm that schedules reviews at optimal intervals for maximum retention.",
      benefits: ["Improved memory", "Efficient studying", "Automated scheduling"],
      color: "text-success"
    },
    {
      icon: "Globe",
      title: "Multilingual Support",
      description: "Study in your preferred language with support for English, Hindi, Marathi, and regional languages.",
      benefits: ["Native language learning", "Better comprehension", "Cultural context"],
      color: "text-warning"
    },
    {
      icon: "Trophy",
      title: "Gamified Learning",
      description: "Stay motivated with XP points, study streaks, achievements, and progress visualization.",
      benefits: ["Increased motivation", "Progress tracking", "Achievement rewards"],
      color: "text-destructive"
    },
    {
      icon: "Zap",
      title: "Instant Generation",
      description: "Transform any PDF, image, or handwritten note into flashcards and quizzes within seconds.",
      benefits: ["Time-saving", "Multiple formats", "OCR technology"],
      color: "text-accent"
    },
    {
      icon: "BarChart3",
      title: "Performance Analytics",
      description: "Track your progress with detailed analytics, knowledge heatmaps, and personalized insights.",
      benefits: ["Identify weak areas", "Track improvement", "Data-driven learning"],
      color: "text-secondary"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
            <Icon name="Star" size={16} className="mr-2" />
            Powerful Features
          </div>
          <h2 className="text-3xl lg:text-5xl font-heading font-bold text-foreground mb-6">
            Everything You Need to
            <span className="text-primary block">Study Effectively</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Our comprehensive platform combines cutting-edge AI technology with proven learning methodologies 
            to create the ultimate study experience.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features?.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-6">
            Join thousands of students who have transformed their learning experience
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Icon name="Check" size={16} className="text-success" />
              <span>Free to start</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Icon name="Check" size={16} className="text-success" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Icon name="Check" size={16} className="text-success" />
              <span>Cancel anytime</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const FeatureCard = ({ feature, index }) => {
  return (
    <div className="group study-card p-6 hover:shadow-elevation-2 transition-all duration-300 hover:-translate-y-1">
      <div className="flex items-center mb-4">
        <div className={`w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mr-4 group-hover:scale-110 transition-transform`}>
          <Icon name={feature?.icon} size={24} className={feature?.color} />
        </div>
        <h3 className="text-xl font-heading font-semibold text-card-foreground">
          {feature?.title}
        </h3>
      </div>
      <p className="text-muted-foreground mb-4 leading-relaxed">
        {feature?.description}
      </p>
      <ul className="space-y-2">
        {feature?.benefits?.map((benefit, benefitIndex) => (
          <li key={benefitIndex} className="flex items-center text-sm text-muted-foreground">
            <Icon name="Check" size={14} className="text-success mr-2 flex-shrink-0" />
            {benefit}
          </li>
        ))}
      </ul>
      {/* Hover Effect */}
      <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex items-center text-primary text-sm font-medium">
          <span>Learn more</span>
          <Icon name="ArrowRight" size={14} className="ml-1 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );
};

export default FeatureShowcase;