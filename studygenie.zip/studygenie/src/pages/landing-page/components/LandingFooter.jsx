import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LandingFooter = () => {
  const navigate = useNavigate();
  const currentYear = new Date()?.getFullYear();

  const footerSections = [
    {
      title: "Product",
      links: [
        { label: "Features", href: "#features" },
        { label: "Demo", href: "#interactive-demo" },
        { label: "Pricing", href: "#pricing" },
        { label: "API", href: "/api-docs" }
      ]
    },
    {
      title: "Resources",
      links: [
        { label: "Help Center", href: "/help" },
        { label: "Study Guides", href: "/guides" },
        { label: "Blog", href: "/blog" },
        { label: "Community", href: "/community" }
      ]
    },
    {
      title: "Company",
      links: [
        { label: "About Us", href: "/about" },
        { label: "Careers", href: "/careers" },
        { label: "Contact", href: "/contact" },
        { label: "Press", href: "/press" }
      ]
    },
    {
      title: "Legal",
      links: [
        { label: "Privacy Policy", href: "/privacy" },
        { label: "Terms of Service", href: "/terms" },
        { label: "Cookie Policy", href: "/cookies" },
        { label: "GDPR", href: "/gdpr" }
      ]
    }
  ];

  const socialLinks = [
    { name: "Twitter", icon: "Twitter", href: "https://twitter.com/studygenie" },
    { name: "Facebook", icon: "Facebook", href: "https://facebook.com/studygenie" },
    { name: "Instagram", icon: "Instagram", href: "https://instagram.com/studygenie" },
    { name: "LinkedIn", icon: "Linkedin", href: "https://linkedin.com/company/studygenie" },
    { name: "YouTube", icon: "Youtube", href: "https://youtube.com/studygenie" }
  ];

  const supportedLanguages = [
    { code: 'en', label: 'English' },
    { code: 'hi', label: 'हिंदी' },
    { code: 'mr', label: 'मराठी' }
  ];

  const trustBadges = [
    { name: "ISO 27001", icon: "Shield", description: "Security Certified" },
    { name: "GDPR", icon: "Lock", description: "Privacy Compliant" },
    { name: "SOC 2", icon: "CheckCircle", description: "Audit Certified" }
  ];

  const handleNavigation = (href) => {
    if (href?.startsWith('#')) {
      const element = document.querySelector(href);
      element?.scrollIntoView({ behavior: 'smooth' });
    } else if (href?.startsWith('http')) {
      window.open(href, '_blank');
    } else {
      navigate(href);
    }
  };

  const Logo = () => (
    <div className="flex items-center space-x-3">
      <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
        <Icon name="GraduationCap" size={28} color="white" />
      </div>
      <div>
        <span className="text-2xl font-heading font-bold text-foreground">
          StudyGenie
        </span>
        <div className="text-sm text-muted-foreground">AI-Powered Learning Platform</div>
      </div>
    </div>
  );

  return (
    <footer className="bg-muted/30 border-t border-border">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 lg:px-6 py-16">
        <div className="grid lg:grid-cols-6 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <Logo />
            <p className="text-muted-foreground mt-4 mb-6 leading-relaxed">
              Transform your study materials into interactive learning experiences with AI-powered 
              flashcards, quizzes, and personalized tutoring. Join thousands of students achieving 
              academic success.
            </p>

            {/* Newsletter Signup */}
            <div className="mb-6">
              <h4 className="font-heading font-semibold text-foreground mb-3">
                Stay Updated
              </h4>
              <div className="flex space-x-2">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-2 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
                <Button variant="default" size="sm">
                  Subscribe
                </Button>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-4">
              {socialLinks?.map((social) => (
                <button
                  key={social?.name}
                  onClick={() => handleNavigation(social?.href)}
                  className="w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center hover:bg-muted transition-colors"
                  title={social?.name}
                >
                  <Icon name={social?.icon} size={18} />
                </button>
              ))}
            </div>
          </div>

          {/* Footer Links */}
          {footerSections?.map((section) => (
            <div key={section?.title}>
              <h4 className="font-heading font-semibold text-foreground mb-4">
                {section?.title}
              </h4>
              <ul className="space-y-3">
                {section?.links?.map((link) => (
                  <li key={link?.label}>
                    <button
                      onClick={() => handleNavigation(link?.href)}
                      className="text-muted-foreground hover:text-foreground transition-colors text-sm"
                    >
                      {link?.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="mt-12 pt-8 border-t border-border">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h4 className="font-heading font-semibold text-foreground mb-4">
                Trusted & Secure
              </h4>
              <div className="flex flex-wrap gap-6">
                {trustBadges?.map((badge) => (
                  <div key={badge?.name} className="flex items-center space-x-2">
                    <Icon name={badge?.icon} size={16} className="text-success" />
                    <div>
                      <div className="text-sm font-medium text-foreground">
                        {badge?.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {badge?.description}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Contact Info */}
            <div className="mt-6 lg:mt-0">
              <h4 className="font-heading font-semibold text-foreground mb-4">
                Contact Support
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="Mail" size={14} />
                  <span>support@studygenie.in</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="Phone" size={14} />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="MapPin" size={14} />
                  <span>Mumbai, Maharashtra, India</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Bottom Bar */}
      <div className="bg-background border-t border-border">
        <div className="container mx-auto px-4 lg:px-6 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            {/* Copyright */}
            <div className="text-sm text-muted-foreground mb-4 lg:mb-0">
              © {currentYear} StudyGenie. All rights reserved. Made with ❤️ in India.
            </div>

            {/* Language Selector */}
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Available in:</span>
              <div className="flex items-center space-x-2">
                {supportedLanguages?.map((language, index) => (
                  <React.Fragment key={language?.code}>
                    <button className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {language?.label}
                    </button>
                    {index < supportedLanguages?.length - 1 && (
                      <span className="text-muted-foreground">•</span>
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default LandingFooter;