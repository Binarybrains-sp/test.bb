import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const StickyCtaBar = () => {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const heroSection = document.querySelector('section');
      if (heroSection) {
        const heroBottom = heroSection?.offsetTop + heroSection?.offsetHeight;
        const scrollPosition = window.scrollY + window.innerHeight;
        setIsVisible(scrollPosition > heroBottom + 200);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleStartLearning = () => {
    navigate('/dashboard');
  };

  const handleSeeDemo = () => {
    const demoSection = document.getElementById('interactive-demo');
    demoSection?.scrollIntoView({ behavior: 'smooth' });
  };

  if (!isVisible) return null;

  return (
    <>
      {/* Mobile Sticky CTA */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-notification">
        <div className="bg-background/95 backdrop-blur-sm border-t border-border p-4">
          {!isMinimized ? (
            <div className="flex items-center space-x-3">
              <div className="flex-1">
                <div className="text-sm font-heading font-semibold text-foreground">
                  Ready to transform your learning?
                </div>
                <div className="text-xs text-muted-foreground">
                  Join 50,000+ students • Free to start
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSeeDemo}
                >
                  Demo
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleStartLearning}
                  iconName="ArrowRight"
                  iconPosition="right"
                >
                  Start Free
                </Button>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(true)}
                className="w-8 h-8"
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <Button
                variant="default"
                onClick={handleStartLearning}
                iconName="ArrowRight"
                iconPosition="right"
                fullWidth
              >
                Start Learning Free
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(false)}
                className="ml-2 w-8 h-8"
              >
                <Icon name="ChevronUp" size={16} />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Desktop Floating CTA */}
      <div className="hidden lg:block fixed bottom-8 right-8 z-notification">
        <div className="bg-card border border-border rounded-lg shadow-modal p-4 max-w-sm">
          {!isMinimized ? (
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="Sparkles" size={16} className="text-primary" />
                  </div>
                  <div className="text-sm font-heading font-semibold text-card-foreground">
                    Start Your Journey
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMinimized(true)}
                  className="w-6 h-6"
                >
                  <Icon name="Minus" size={14} />
                </Button>
              </div>
              
              <p className="text-sm text-muted-foreground mb-4">
                Transform your study materials into interactive learning experiences
              </p>
              
              <div className="flex items-center space-x-2 text-xs text-muted-foreground mb-4">
                <Icon name="Check" size={12} className="text-success" />
                <span>Free to start</span>
                <Icon name="Check" size={12} className="text-success" />
                <span>No credit card</span>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSeeDemo}
                  iconName="Play"
                  iconPosition="left"
                >
                  Demo
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleStartLearning}
                  iconName="ArrowRight"
                  iconPosition="right"
                >
                  Start Free
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <Button
                variant="default"
                size="sm"
                onClick={handleStartLearning}
                iconName="ArrowRight"
                iconPosition="right"
              >
                Start Learning
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(false)}
                className="w-8 h-8"
              >
                <Icon name="Plus" size={16} />
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default StickyCtaBar;