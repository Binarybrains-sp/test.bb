import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import WelcomeCard from './components/WelcomeCard';
import ProgressOverview from './components/ProgressOverview';
import QuickActions from './components/QuickActions';
import RecentActivity from './components/RecentActivity';
import KnowledgeHeatmap from './components/KnowledgeHeatmap';
import UpcomingReviews from './components/UpcomingReviews';
import DailyGoals from './components/DailyGoals';
import AITutorWidget from './components/AITutorWidget';

const Dashboard = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isTutorExpanded, setIsTutorExpanded] = useState(false);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('studyGenie_language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  // Mock user data
  const userData = {
    name: "Arjun Sharma",
    currentStreak: 12,
    lastStudyTime: "3 hours ago",
    weeklyStudyTime: "18h 45m",
    xpPoints: 3250,
    level: 9,
    hasUploadedMaterials: true,
    continueStudyTopic: "Physics - Quantum Mechanics",
    pendingQuizzes: 5
  };

  const achievements = [
    { id: 1, name: "Quiz Master", icon: "Trophy", color: "var(--color-warning)" },
    { id: 2, name: "Speed Reader", icon: "Zap", color: "var(--color-primary)" },
    { id: 3, name: "Consistent Learner", icon: "Target", color: "var(--color-success)" },
    { id: 4, name: "Perfect Score", icon: "Star", color: "var(--color-warning)" }
  ];

  const subjects = [
    { name: 'Physics', performance: 88, topics: 15, color: 'bg-success' },
    { name: 'Chemistry', performance: 94, topics: 12, color: 'bg-success' },
    { name: 'Mathematics', performance: 76, topics: 18, color: 'bg-warning' },
    { name: 'Biology', performance: 82, topics: 14, color: 'bg-success' },
    { name: 'English', performance: 91, topics: 8, color: 'bg-success' },
    { name: 'Computer Science', performance: 67, topics: 11, color: 'bg-destructive' }
  ];

  const upcomingReviews = [
    {
      id: 1,
      subject: 'Physics',
      topic: 'Quantum Mechanics',
      dueCount: 18,
      priority: 'high',
      dueTime: 'Due now',
      lastReviewed: '4 days ago'
    },
    {
      id: 2,
      subject: 'Chemistry',
      topic: 'Organic Reactions',
      dueCount: 12,
      priority: 'medium',
      dueTime: 'Due in 1 hour',
      lastReviewed: '2 days ago'
    },
    {
      id: 3,
      subject: 'Mathematics',
      topic: 'Differential Equations',
      dueCount: 9,
      priority: 'low',
      dueTime: 'Due tomorrow',
      lastReviewed: '1 day ago'
    },
    {
      id: 4,
      subject: 'Biology',
      topic: 'Genetics',
      dueCount: 15,
      priority: 'medium',
      dueTime: 'Due in 3 hours',
      lastReviewed: '3 days ago'
    }
  ];

  const dailyGoals = [
    {
      id: 1,
      title: 'Study Time',
      current: 75,
      target: 90,
      unit: 'minutes',
      icon: 'Clock',
      color: 'var(--color-primary)'
    },
    {
      id: 2,
      title: 'Flashcards',
      current: 35,
      target: 40,
      unit: 'cards',
      icon: 'BookOpen',
      color: 'var(--color-success)'
    },
    {
      id: 3,
      title: 'Quiz Score',
      current: 92,
      target: 85,
      unit: '%',
      icon: 'Brain',
      color: 'var(--color-warning)'
    },
    {
      id: 4,
      title: 'XP Points',
      current: 180,
      target: 200,
      unit: 'XP',
      icon: 'Star',
      color: 'var(--color-secondary)'
    }
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'study',
      title: 'Completed Physics Flashcards',
      description: 'Quantum Mechanics - 28 cards reviewed',
      timestamp: '1 hour ago',
      score: 89,
      icon: 'BookOpen',
      color: 'var(--color-success)'
    },
    {
      id: 2,
      type: 'quiz',
      title: 'Chemistry Quiz Completed',
      description: 'Organic Chemistry - 20 questions',
      timestamp: '3 hours ago',
      score: 95,
      icon: 'Brain',
      color: 'var(--color-warning)'
    },
    {
      id: 3,
      type: 'upload',
      title: 'New Material Added',
      description: 'Computer Science - Data Structures.pdf',
      timestamp: '5 hours ago',
      icon: 'Upload',
      color: 'var(--color-primary)'
    },
    {
      id: 4,
      type: 'ai_tutor',
      title: 'AI Tutor Session',
      description: 'Asked 5 questions about Mathematics',
      timestamp: '1 day ago',
      icon: 'MessageCircle',
      color: 'var(--color-secondary)'
    },
    {
      id: 5,
      type: 'achievement',
      title: 'Achievement Unlocked',
      description: 'Perfect Score - 5 consecutive 100% quizzes',
      timestamp: '2 days ago',
      icon: 'Trophy',
      color: 'var(--color-warning)'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Dashboard - StudyGenie</title>
        <meta name="description" content="Your personalized learning dashboard with progress tracking, study materials, and AI-powered tutoring." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-16 pb-20 lg:pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {/* Mobile Layout */}
            <div className="lg:hidden space-y-6">
              <WelcomeCard 
                userName={userData?.name}
                currentStreak={userData?.currentStreak}
                lastStudyTime={userData?.lastStudyTime}
              />
              
              <QuickActions 
                hasUploadedMaterials={userData?.hasUploadedMaterials}
                continueStudyTopic={userData?.continueStudyTopic}
                pendingQuizzes={userData?.pendingQuizzes}
              />
              
              <ProgressOverview 
                weeklyStudyTime={userData?.weeklyStudyTime}
                xpPoints={userData?.xpPoints}
                level={userData?.level}
                achievements={achievements}
              />
              
              <DailyGoals goals={dailyGoals} />
              
              <UpcomingReviews reviews={upcomingReviews} />
              
              <RecentActivity activities={recentActivities} />
              
              <KnowledgeHeatmap subjects={subjects} />
            </div>

            {/* Desktop Layout */}
            <div className="hidden lg:grid lg:grid-cols-12 lg:gap-6">
              {/* Left Column */}
              <div className="lg:col-span-8 space-y-6">
                <WelcomeCard 
                  userName={userData?.name}
                  currentStreak={userData?.currentStreak}
                  lastStudyTime={userData?.lastStudyTime}
                />
                
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  <ProgressOverview 
                    weeklyStudyTime={userData?.weeklyStudyTime}
                    xpPoints={userData?.xpPoints}
                    level={userData?.level}
                    achievements={achievements}
                  />
                  
                  <QuickActions 
                    hasUploadedMaterials={userData?.hasUploadedMaterials}
                    continueStudyTopic={userData?.continueStudyTopic}
                    pendingQuizzes={userData?.pendingQuizzes}
                  />
                </div>
                
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  <RecentActivity activities={recentActivities} />
                  <KnowledgeHeatmap subjects={subjects} />
                </div>
              </div>

              {/* Right Column */}
              <div className="lg:col-span-4 space-y-6">
                <DailyGoals goals={dailyGoals} />
                <UpcomingReviews reviews={upcomingReviews} />
              </div>
            </div>
          </div>
        </main>

        {/* AI Tutor Widget */}
        <AITutorWidget 
          isExpanded={isTutorExpanded}
          onToggle={() => setIsTutorExpanded(!isTutorExpanded)}
          recentQuestions={[
            "Explain quantum entanglement in simple terms",
            "What's the difference between covalent and ionic bonds?",
            "How do I solve integration by parts?"
          ]}
        />

        {/* Mobile Bottom Navigation */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-navigation">
          <div className="grid grid-cols-5 h-16">
            <button className="flex flex-col items-center justify-center space-y-1 text-primary">
              <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-primary-foreground rounded-full"></div>
              </div>
              <span className="text-xs font-caption">Dashboard</span>
            </button>
            <button className="flex flex-col items-center justify-center space-y-1 text-muted-foreground hover:text-foreground">
              <div className="w-6 h-6 flex items-center justify-center">
                <div className="w-2 h-2 bg-current rounded-full"></div>
              </div>
              <span className="text-xs font-caption">Study</span>
            </button>
            <button className="flex flex-col items-center justify-center space-y-1 text-muted-foreground hover:text-foreground">
              <div className="w-6 h-6 flex items-center justify-center">
                <div className="w-2 h-2 bg-current rounded-full"></div>
              </div>
              <span className="text-xs font-caption">Upload</span>
            </button>
            <button className="flex flex-col items-center justify-center space-y-1 text-muted-foreground hover:text-foreground">
              <div className="w-6 h-6 flex items-center justify-center">
                <div className="w-2 h-2 bg-current rounded-full"></div>
              </div>
              <span className="text-xs font-caption">Progress</span>
            </button>
            <button className="flex flex-col items-center justify-center space-y-1 text-muted-foreground hover:text-foreground">
              <div className="w-6 h-6 flex items-center justify-center">
                <div className="w-2 h-2 bg-current rounded-full"></div>
              </div>
              <span className="text-xs font-caption">Profile</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;