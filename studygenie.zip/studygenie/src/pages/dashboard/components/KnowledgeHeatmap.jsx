import React from 'react';
import Icon from '../../../components/AppIcon';

const KnowledgeHeatmap = ({ 
  subjects = [
    { name: 'Physics', performance: 85, topics: 12, color: 'bg-success' },
    { name: 'Chemistry', performance: 92, topics: 8, color: 'bg-success' },
    { name: 'Mathematics', performance: 78, topics: 15, color: 'bg-warning' },
    { name: 'Biology', performance: 65, topics: 10, color: 'bg-destructive' },
    { name: 'English', performance: 88, topics: 6, color: 'bg-success' },
    { name: 'History', performance: 72, topics: 9, color: 'bg-warning' }
  ]
}) => {
  const getPerformanceLevel = (score) => {
    if (score >= 85) return { level: 'Strong', color: 'bg-success', textColor: 'text-success' };
    if (score >= 70) return { level: 'Good', color: 'bg-warning', textColor: 'text-warning' };
    return { level: 'Needs Work', color: 'bg-destructive', textColor: 'text-destructive' };
  };

  const getIntensity = (score) => {
    if (score >= 85) return 'opacity-100';
    if (score >= 70) return 'opacity-70';
    return 'opacity-50';
  };

  return (
    <div className="study-card p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-heading font-semibold text-foreground">
          Knowledge Heatmap
        </h2>
        <Icon name="BarChart3" size={20} color="var(--color-muted-foreground)" />
      </div>
      {/* Performance Legend */}
      <div className="flex items-center justify-center space-x-6 mb-6 text-xs font-caption">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-destructive rounded opacity-50"></div>
          <span className="text-muted-foreground">Needs Work</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-warning rounded opacity-70"></div>
          <span className="text-muted-foreground">Good</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-success rounded opacity-100"></div>
          <span className="text-muted-foreground">Strong</span>
        </div>
      </div>
      {/* Heatmap Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
        {subjects?.map((subject) => {
          const performance = getPerformanceLevel(subject?.performance);
          return (
            <div
              key={subject?.name}
              className={`
                relative p-4 rounded-lg border transition-all duration-200 hover:scale-105 cursor-pointer
                ${performance?.color} ${getIntensity(subject?.performance)}
              `}
            >
              <div className="text-center">
                <h3 className="text-sm font-medium text-white mb-1">
                  {subject?.name}
                </h3>
                <div className="text-lg font-data font-bold text-white mb-1">
                  {subject?.performance}%
                </div>
                <div className="text-xs text-white/80">
                  {subject?.topics} topics
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {/* Subject Performance List */}
      <div className="space-y-3">
        <h3 className="text-sm font-medium text-foreground mb-3">Subject Breakdown</h3>
        {subjects?.map((subject) => {
          const performance = getPerformanceLevel(subject?.performance);
          return (
            <div key={subject?.name} className="flex items-center justify-between p-2 rounded hover:bg-muted/50">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded ${performance?.color} ${getIntensity(subject?.performance)}`}></div>
                <span className="text-sm font-medium text-foreground">{subject?.name}</span>
              </div>
              <div className="flex items-center space-x-3">
                <span className={`text-sm font-data ${performance?.textColor}`}>
                  {subject?.performance}%
                </span>
                <span className="text-xs text-muted-foreground">
                  {subject?.topics} topics
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default KnowledgeHeatmap;