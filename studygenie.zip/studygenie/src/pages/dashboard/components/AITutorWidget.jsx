import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const AITutorWidget = ({ 
  isExpanded = false, 
  onToggle,
  recentQuestions = [
    "Explain photosynthesis in simple terms",
    "What is the difference between speed and velocity?",
    "How do I solve quadratic equations?"
  ]
}) => {
  const [question, setQuestion] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'ai',
      content: "Hi! I\'m your AI tutor. Ask me anything about your study materials! 🤖",
      timestamp: new Date(Date.now() - 300000)
    }
  ]);

  const handleSendQuestion = () => {
    if (!question?.trim()) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: question,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setQuestion('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = {
        id: Date.now() + 1,
        type: 'ai',
        content: `Great question! Let me help you understand that concept. Based on your study materials, here's a detailed explanation...\n\nWould you like me to create some practice questions on this topic?`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 2000);
  };

  const handleQuickQuestion = (quickQuestion) => {
    setQuestion(quickQuestion);
  };

  const formatTime = (date) => {
    return date?.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    });
  };

  if (!isExpanded) {
    return (
      <div className="fixed bottom-4 right-4 z-notification">
        <button
          onClick={onToggle}
          className="w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-modal flex items-center justify-center hover:scale-105 transition-transform"
        >
          <Icon name="MessageCircle" size={24} />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 w-80 h-96 bg-card border border-border rounded-lg shadow-modal z-notification flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
            <Icon name="Bot" size={18} color="var(--color-primary)" />
          </div>
          <div>
            <h3 className="text-sm font-heading font-semibold text-card-foreground">
              AI Tutor
            </h3>
            <p className="text-xs text-success">Online</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggle}
          className="w-8 h-8"
        >
          <Icon name="X" size={16} />
        </Button>
      </div>
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages?.map((message) => (
          <div
            key={message?.id}
            className={`flex ${message?.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`
                max-w-[80%] p-3 rounded-lg text-sm
                ${message?.type === 'user' ?'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground'
                }
              `}
            >
              <p className="whitespace-pre-wrap">{message?.content}</p>
              <p className={`
                text-xs mt-1 opacity-70
                ${message?.type === 'user' ? 'text-primary-foreground' : 'text-muted-foreground'}
              `}>
                {formatTime(message?.timestamp)}
              </p>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-muted text-muted-foreground p-3 rounded-lg text-sm">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-current rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-current rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-current rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Quick Questions */}
      {recentQuestions?.length > 0 && (
        <div className="px-4 py-2 border-t border-border">
          <p className="text-xs font-caption text-muted-foreground mb-2">Quick questions:</p>
          <div className="flex flex-wrap gap-1">
            {recentQuestions?.slice(0, 2)?.map((q, index) => (
              <button
                key={index}
                onClick={() => handleQuickQuestion(q)}
                className="text-xs bg-muted hover:bg-muted/80 text-muted-foreground px-2 py-1 rounded transition-colors"
              >
                {q?.length > 25 ? `${q?.substring(0, 25)}...` : q}
              </button>
            ))}
          </div>
        </div>
      )}
      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder="Ask me anything..."
            value={question}
            onChange={(e) => setQuestion(e?.target?.value)}
            onKeyPress={(e) => e?.key === 'Enter' && handleSendQuestion()}
            className="flex-1"
          />
          <Button
            variant="default"
            size="icon"
            onClick={handleSendQuestion}
            disabled={!question?.trim() || isTyping}
          >
            <Icon name="Send" size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AITutorWidget;