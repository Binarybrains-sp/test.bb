import React from 'react';
import Icon from '../../../components/AppIcon';

const DailyGoals = ({ 
  goals = [
    {
      id: 1,
      title: 'Study Time',
      current: 45,
      target: 60,
      unit: 'minutes',
      icon: 'Clock',
      color: 'var(--color-primary)'
    },
    {
      id: 2,
      title: 'Flashcards',
      current: 25,
      target: 30,
      unit: 'cards',
      icon: 'BookOpen',
      color: 'var(--color-success)'
    },
    {
      id: 3,
      title: 'Quiz Score',
      current: 85,
      target: 90,
      unit: '%',
      icon: 'Brain',
      color: 'var(--color-warning)'
    },
    {
      id: 4,
      title: 'XP Points',
      current: 120,
      target: 150,
      unit: 'XP',
      icon: 'Star',
      color: 'var(--color-secondary)'
    }
  ]
}) => {
  const getProgressPercentage = (current, target) => {
    return Math.min((current / target) * 100, 100);
  };

  const getProgressColor = (percentage) => {
    if (percentage >= 100) return 'text-success';
    if (percentage >= 75) return 'text-warning';
    return 'text-primary';
  };

  const completedGoals = goals?.filter(goal => goal?.current >= goal?.target)?.length;
  const totalGoals = goals?.length;

  return (
    <div className="study-card p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-heading font-semibold text-foreground">
          Daily Goals
        </h2>
        <div className="flex items-center space-x-2">
          <Icon name="Target" size={20} color="var(--color-success)" />
          <span className="text-sm font-data font-medium text-success">
            {completedGoals}/{totalGoals}
          </span>
        </div>
      </div>
      <div className="space-y-4">
        {goals?.map((goal) => {
          const percentage = getProgressPercentage(goal?.current, goal?.target);
          const isCompleted = goal?.current >= goal?.target;
          
          return (
            <div key={goal?.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Icon name={goal?.icon} size={16} color={goal?.color} />
                  <span className="text-sm font-medium text-foreground">
                    {goal?.title}
                  </span>
                  {isCompleted && (
                    <Icon name="CheckCircle" size={16} color="var(--color-success)" />
                  )}
                </div>
                <div className="text-sm font-data">
                  <span className={getProgressColor(percentage)}>
                    {goal?.current}
                  </span>
                  <span className="text-muted-foreground">
                    /{goal?.target} {goal?.unit}
                  </span>
                </div>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className={`
                    h-2 rounded-full transition-all duration-300
                    ${isCompleted ? 'bg-success' : 'progress-indicator'}
                  `}
                  style={{ width: `${percentage}%` }}
                />
              </div>
              <div className="flex justify-between text-xs font-caption text-muted-foreground">
                <span>{Math.round(percentage)}% complete</span>
                {!isCompleted && (
                  <span>{goal?.target - goal?.current} {goal?.unit} remaining</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
      {/* Overall Progress */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">Overall Progress</span>
          <span className="text-sm font-data text-primary">
            {Math.round((completedGoals / totalGoals) * 100)}%
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="progress-indicator h-2 rounded-full"
            style={{ width: `${(completedGoals / totalGoals) * 100}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          {completedGoals === totalGoals 
            ? "🎉 All goals completed today!" 
            : `${totalGoals - completedGoals} goals remaining`
          }
        </p>
      </div>
    </div>
  );
};

export default DailyGoals;