import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressOverview = ({ 
  weeklyStudyTime = "12h 30m", 
  xpPoints = 2450, 
  level = 8,
  achievements = [
    { id: 1, name: "Quiz Master", icon: "Trophy", color: "var(--color-warning)" },
    { id: 2, name: "Speed Reader", icon: "Zap", color: "var(--color-primary)" },
    { id: 3, name: "Consistent Learner", icon: "Target", color: "var(--color-success)" }
  ]
}) => {
  const nextLevelXP = 3000;
  const progressPercentage = (xpPoints / nextLevelXP) * 100;

  return (
    <div className="study-card p-6">
      <h2 className="text-lg font-heading font-semibold text-foreground mb-4">
        Progress Overview
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {/* Weekly Study Time */}
        <div className="text-center p-4 bg-primary/5 rounded-lg">
          <Icon name="Clock" size={24} color="var(--color-primary)" className="mx-auto mb-2" />
          <div className="text-2xl font-data font-bold text-primary">{weeklyStudyTime}</div>
          <div className="text-sm text-muted-foreground">This Week</div>
        </div>

        {/* XP Points */}
        <div className="text-center p-4 bg-success/5 rounded-lg">
          <Icon name="Star" size={24} color="var(--color-success)" className="mx-auto mb-2" />
          <div className="text-2xl font-data font-bold text-success">{xpPoints?.toLocaleString()}</div>
          <div className="text-sm text-muted-foreground">XP Points</div>
        </div>

        {/* Current Level */}
        <div className="text-center p-4 bg-warning/5 rounded-lg">
          <Icon name="Award" size={24} color="var(--color-warning)" className="mx-auto mb-2" />
          <div className="text-2xl font-data font-bold text-warning">Level {level}</div>
          <div className="text-sm text-muted-foreground">Current Level</div>
        </div>
      </div>
      {/* Level Progress */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-foreground">Level {level} Progress</span>
          <span className="text-sm text-muted-foreground">{xpPoints}/{nextLevelXP} XP</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="progress-indicator h-2 rounded-full"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          {nextLevelXP - xpPoints} XP to next level
        </p>
      </div>
      {/* Achievement Badges */}
      <div>
        <h3 className="text-sm font-medium text-foreground mb-3">Recent Achievements</h3>
        <div className="flex space-x-3 overflow-x-auto pb-2">
          {achievements?.map((achievement) => (
            <div 
              key={achievement?.id}
              className="flex-shrink-0 flex flex-col items-center p-3 bg-muted/50 rounded-lg min-w-[80px]"
            >
              <div className="w-10 h-10 bg-background rounded-full flex items-center justify-center mb-2">
                <Icon name={achievement?.icon} size={20} color={achievement?.color} />
              </div>
              <span className="text-xs font-caption text-center text-muted-foreground">
                {achievement?.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProgressOverview;