import React from 'react';
import Icon from '../../../components/AppIcon';

const RecentActivity = ({ 
  activities = [
    {
      id: 1,
      type: 'study',
      title: 'Completed Physics Flashcards',
      description: 'Thermodynamics - 25 cards reviewed',
      timestamp: '2 hours ago',
      score: 85,
      icon: 'BookOpen',
      color: 'var(--color-success)'
    },
    {
      id: 2,
      type: 'quiz',
      title: 'Chemistry Quiz Completed',
      description: 'Organic Chemistry - 15 questions',
      timestamp: '5 hours ago',
      score: 92,
      icon: 'Brain',
      color: 'var(--color-warning)'
    },
    {
      id: 3,
      type: 'upload',
      title: 'New Material Added',
      description: 'Mathematics - Calculus Notes.pdf',
      timestamp: '1 day ago',
      icon: 'Upload',
      color: 'var(--color-primary)'
    },
    {
      id: 4,
      type: 'ai_tutor',
      title: 'AI Tutor Session',
      description: 'Asked 3 questions about Biology',
      timestamp: '2 days ago',
      icon: 'MessageCircle',
      color: 'var(--color-secondary)'
    },
    {
      id: 5,
      type: 'achievement',
      title: 'Achievement Unlocked',
      description: 'Quiz Master - 10 perfect scores',
      timestamp: '3 days ago',
      icon: 'Trophy',
      color: 'var(--color-warning)'
    }
  ]
}) => {
  const getScoreColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 70) return 'text-warning';
    return 'text-destructive';
  };

  return (
    <div className="study-card p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-heading font-semibold text-foreground">
          Recent Activity
        </h2>
        <button className="text-sm text-primary hover:text-primary/80 font-medium">
          View All
        </button>
      </div>
      <div className="space-y-4 max-h-80 overflow-y-auto">
        {activities?.map((activity) => (
          <div key={activity?.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <div 
              className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center"
              style={{ backgroundColor: `${activity?.color}15` }}
            >
              <Icon name={activity?.icon} size={18} color={activity?.color} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-sm font-medium text-foreground truncate">
                  {activity?.title}
                </h3>
                {activity?.score && (
                  <span className={`text-sm font-data font-medium ${getScoreColor(activity?.score)}`}>
                    {activity?.score}%
                  </span>
                )}
              </div>
              <p className="text-sm text-muted-foreground mb-1">
                {activity?.description}
              </p>
              <span className="text-xs font-caption text-muted-foreground">
                {activity?.timestamp}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentActivity;