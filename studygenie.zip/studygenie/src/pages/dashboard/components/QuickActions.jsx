import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';


const QuickActions = ({ 
  hasUploadedMaterials = true, 
  continueStudyTopic = "Physics - Thermodynamics",
  pendingQuizzes = 3 
}) => {
  const navigate = useNavigate();

  const actions = [
    {
      id: 'upload',
      title: 'Upload Material',
      description: 'Add new study content',
      icon: 'Upload',
      color: 'var(--color-primary)',
      bgColor: 'bg-primary/10',
      onClick: () => navigate('/material-upload')
    },
    {
      id: 'study',
      title: 'Continue Studying',
      description: hasUploadedMaterials ? continueStudyTopic : 'No materials yet',
      icon: 'BookOpen',
      color: 'var(--color-success)',
      bgColor: 'bg-success/10',
      onClick: () => navigate('/study-session-flashcards'),
      disabled: !hasUploadedMaterials
    },
    {
      id: 'quiz',
      title: 'Take Quiz',
      description: `${pendingQuizzes} quizzes available`,
      icon: 'Brain',
      color: 'var(--color-warning)',
      bgColor: 'bg-warning/10',
      onClick: () => navigate('/quiz-interface'),
      badge: pendingQuizzes > 0 ? pendingQuizzes : null
    }
  ];

  return (
    <div className="study-card p-6">
      <h2 className="text-lg font-heading font-semibold text-foreground mb-4">
        Quick Actions
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {actions?.map((action) => (
          <button
            key={action?.id}
            onClick={action?.onClick}
            disabled={action?.disabled}
            className={`
              relative p-4 rounded-lg border-2 border-transparent transition-all duration-200
              ${action?.disabled 
                ? 'opacity-50 cursor-not-allowed bg-muted/30' 
                : `${action?.bgColor} hover:border-current hover:scale-105 micro-interaction`
              }
            `}
            style={{ color: action?.disabled ? 'var(--color-muted-foreground)' : action?.color }}
          >
            {/* Badge */}
            {action?.badge && (
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-destructive text-destructive-foreground rounded-full text-xs font-data flex items-center justify-center">
                {action?.badge}
              </div>
            )}
            
            <div className="flex flex-col items-center text-center space-y-3">
              <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center">
                <Icon 
                  name={action?.icon} 
                  size={24} 
                  color={action?.disabled ? 'var(--color-muted-foreground)' : action?.color} 
                />
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-1">{action?.title}</h3>
                <p className="text-sm text-muted-foreground">{action?.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;