import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const UpcomingReviews = ({ 
  reviews = [
    {
      id: 1,
      subject: 'Physics',
      topic: 'Thermodynamics',
      dueCount: 15,
      priority: 'high',
      dueTime: 'Due now',
      lastReviewed: '3 days ago'
    },
    {
      id: 2,
      subject: 'Chemistry',
      topic: 'Organic Chemistry',
      dueCount: 8,
      priority: 'medium',
      dueTime: 'Due in 2 hours',
      lastReviewed: '1 day ago'
    },
    {
      id: 3,
      subject: 'Mathematics',
      topic: 'Calculus',
      dueCount: 12,
      priority: 'low',
      dueTime: 'Due tomorrow',
      lastReviewed: '2 hours ago'
    },
    {
      id: 4,
      subject: 'Biology',
      topic: 'Cell Structure',
      dueCount: 6,
      priority: 'medium',
      dueTime: 'Due in 4 hours',
      lastReviewed: '2 days ago'
    }
  ]
}) => {
  const navigate = useNavigate();

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return { bg: 'bg-destructive/10', text: 'text-destructive', border: 'border-destructive/20' };
      case 'medium':
        return { bg: 'bg-warning/10', text: 'text-warning', border: 'border-warning/20' };
      case 'low':
        return { bg: 'bg-success/10', text: 'text-success', border: 'border-success/20' };
      default:
        return { bg: 'bg-muted/10', text: 'text-muted-foreground', border: 'border-muted/20' };
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 'high':
        return 'AlertTriangle';
      case 'medium':
        return 'Clock';
      case 'low':
        return 'CheckCircle';
      default:
        return 'Circle';
    }
  };

  const totalDueCards = reviews?.reduce((sum, review) => sum + review?.dueCount, 0);

  const handleStartReview = (review) => {
    navigate('/study-session-flashcards', { 
      state: { 
        subject: review?.subject, 
        topic: review?.topic,
        reviewMode: true 
      } 
    });
  };

  return (
    <div className="study-card p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-heading font-semibold text-foreground">
            Upcoming Reviews
          </h2>
          <p className="text-sm text-muted-foreground">
            {totalDueCards} flashcards ready for review
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Icon name="RotateCcw" size={20} color="var(--color-primary)" />
          <span className="text-sm font-data font-medium text-primary">
            {totalDueCards}
          </span>
        </div>
      </div>
      <div className="space-y-3 max-h-64 overflow-y-auto">
        {reviews?.map((review) => {
          const priority = getPriorityColor(review?.priority);
          return (
            <div 
              key={review?.id} 
              className={`
                p-4 rounded-lg border transition-all duration-200 hover:shadow-sm
                ${priority?.bg} ${priority?.border}
              `}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Icon 
                    name={getPriorityIcon(review?.priority)} 
                    size={16} 
                    color={priority?.text?.replace('text-', 'var(--color-')} 
                  />
                  <h3 className="text-sm font-medium text-foreground">
                    {review?.subject} - {review?.topic}
                  </h3>
                </div>
                <div className={`px-2 py-1 rounded text-xs font-data ${priority?.text} ${priority?.bg}`}>
                  {review?.dueCount} cards
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground space-y-1">
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={12} />
                    <span>{review?.dueTime}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="History" size={12} />
                    <span>Last reviewed {review?.lastReviewed}</span>
                  </div>
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleStartReview(review)}
                  iconName="Play"
                  iconPosition="left"
                >
                  Review
                </Button>
              </div>
            </div>
          );
        })}
      </div>
      {reviews?.length === 0 && (
        <div className="text-center py-8">
          <Icon name="CheckCircle" size={48} color="var(--color-success)" className="mx-auto mb-3" />
          <h3 className="text-lg font-medium text-foreground mb-2">All caught up!</h3>
          <p className="text-muted-foreground">No reviews due at the moment.</p>
        </div>
      )}
      {reviews?.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <Button
            variant="default"
            fullWidth
            onClick={() => navigate('/study-session-flashcards', { state: { reviewMode: true } })}
            iconName="RotateCcw"
            iconPosition="left"
          >
            Start All Reviews ({totalDueCards} cards)
          </Button>
        </div>
      )}
    </div>
  );
};

export default UpcomingReviews;