import React from 'react';
import Icon from '../../../components/AppIcon';

const WelcomeCard = ({ userName = "Student", currentStreak = 7, lastStudyTime = "2 hours ago" }) => {
  const getGreeting = () => {
    const hour = new Date()?.getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  return (
    <div className="study-card p-6 bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-heading font-bold text-foreground mb-1">
            {getGreeting()}, {userName}! 👋
          </h1>
          <p className="text-muted-foreground">
            Ready to continue your learning journey?
          </p>
        </div>
        <div className="hidden sm:flex items-center space-x-2 bg-warning/10 px-3 py-2 rounded-lg">
          <Icon name="Flame" size={20} color="var(--color-warning)" />
          <div className="text-center">
            <div className="text-lg font-data font-bold text-warning">{currentStreak}</div>
            <div className="text-xs font-caption text-muted-foreground">Day Streak</div>
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="sm:hidden flex items-center space-x-2 bg-warning/10 px-3 py-2 rounded-lg">
            <Icon name="Flame" size={16} color="var(--color-warning)" />
            <span className="text-sm font-data font-bold text-warning">{currentStreak} days</span>
          </div>
          <div className="text-sm text-muted-foreground">
            Last studied: {lastStudyTime}
          </div>
        </div>
        <div className="flex items-center space-x-1 text-success">
          <Icon name="TrendingUp" size={16} />
          <span className="text-sm font-medium">On track</span>
        </div>
      </div>
    </div>
  );
};

export default WelcomeCard;