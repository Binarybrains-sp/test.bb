import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import PerformanceOverview from './components/PerformanceOverview';
import LearningProgressChart from './components/LearningProgressChart';
import SubjectPerformanceHeatmap from './components/SubjectPerformanceHeatmap';
import QuizPerformanceAnalytics from './components/QuizPerformanceAnalytics';
import SpacedRepetitionInsights from './components/SpacedRepetitionInsights';
import StudyPatternAnalysis from './components/StudyPatternAnalysis';
import AchievementGallery from './components/AchievementGallery';

const ProgressAnalytics = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [dateRange, setDateRange] = useState('30d');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'BarChart3' },
    { id: 'performance', label: 'Performance', icon: 'TrendingUp' },
    { id: 'subjects', label: 'Subjects', icon: 'BookOpen' },
    { id: 'quizzes', label: 'Quizzes', icon: 'Brain' },
    { id: 'spaced', label: 'Spaced Rep', icon: 'RotateCcw' },
    { id: 'patterns', label: 'Patterns', icon: 'Clock' },
    { id: 'achievements', label: 'Achievements', icon: 'Trophy' }
  ];

  const dateRanges = [
    { value: '7d', label: '7 Days' },
    { value: '30d', label: '30 Days' },
    { value: '90d', label: '90 Days' },
    { value: '1y', label: '1 Year' }
  ];

  const handleExportReport = () => {
    // Mock export functionality
    const reportData = {
      dateRange,
      generatedAt: new Date()?.toISOString(),
      studentName: 'Student User',
      totalXP: 2450,
      studyStreak: 15,
      subjectsMastered: 8,
      weeklyStudyTime: '12h 30m'
    };
    
    console.log('Exporting progress report:', reportData);
    // In a real app, this would generate and download a PDF report
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            <PerformanceOverview />
            <LearningProgressChart />
          </div>
        );
      case 'performance':
        return <LearningProgressChart />;
      case 'subjects':
        return <SubjectPerformanceHeatmap />;
      case 'quizzes':
        return <QuizPerformanceAnalytics />;
      case 'spaced':
        return <SpacedRepetitionInsights />;
      case 'patterns':
        return <StudyPatternAnalysis />;
      case 'achievements':
        return <AchievementGallery />;
      default:
        return (
          <div className="space-y-6">
            <PerformanceOverview />
            <LearningProgressChart />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Page Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
            <div className="mb-4 sm:mb-0">
              <h1 className="text-2xl font-heading font-bold text-foreground mb-2">
                Progress Analytics
              </h1>
              <p className="text-sm font-caption text-muted-foreground">
                Comprehensive insights into your learning journey and performance trends
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              {/* Date Range Selector */}
              <div className="flex bg-muted rounded-lg p-1">
                {dateRanges?.map((range) => (
                  <button
                    key={range?.value}
                    onClick={() => setDateRange(range?.value)}
                    className={`px-3 py-1 text-xs font-caption rounded-md transition-colors ${
                      dateRange === range?.value
                        ? 'bg-background text-foreground shadow-sm'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {range?.label}
                  </button>
                ))}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportReport}
                iconName="Download"
                iconPosition="left"
              >
                Export Report
              </Button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="mb-6">
            {/* Desktop Tabs */}
            <div className="hidden lg:flex bg-muted rounded-lg p-1">
              {tabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`flex items-center space-x-2 px-4 py-2 text-sm font-caption rounded-md transition-colors ${
                    activeTab === tab?.id
                      ? 'bg-background text-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon name={tab?.icon} size={16} />
                  <span>{tab?.label}</span>
                </button>
              ))}
            </div>

            {/* Mobile Tab Selector */}
            <div className="lg:hidden">
              <div className="flex items-center justify-between bg-muted rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <Icon name={tabs?.find(t => t?.id === activeTab)?.icon || 'BarChart3'} size={18} />
                  <span className="text-sm font-caption text-foreground">
                    {tabs?.find(t => t?.id === activeTab)?.label || 'Overview'}
                  </span>
                </div>
                <select
                  value={activeTab}
                  onChange={(e) => setActiveTab(e?.target?.value)}
                  className="bg-transparent text-sm font-caption text-foreground border-none outline-none"
                >
                  {tabs?.map((tab) => (
                    <option key={tab?.id} value={tab?.id}>
                      {tab?.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Mobile Swipeable Tabs */}
            <div className="lg:hidden mt-4 overflow-x-auto">
              <div className="flex space-x-2 pb-2">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => setActiveTab(tab?.id)}
                    className={`flex items-center space-x-2 px-3 py-2 text-xs font-caption rounded-lg whitespace-nowrap transition-colors ${
                      activeTab === tab?.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground hover:bg-muted/80'
                    }`}
                  >
                    <Icon name={tab?.icon} size={14} />
                    <span>{tab?.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Tab Content */}
          <div className="animate-in fade-in-50 duration-200">
            {renderTabContent()}
          </div>

          {/* Quick Actions */}
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
              variant="outline"
              fullWidth
              onClick={() => navigate('/study-session-flashcards')}
              iconName="BookOpen"
              iconPosition="left"
            >
              Start Study Session
            </Button>
            <Button
              variant="outline"
              fullWidth
              onClick={() => navigate('/quiz-interface')}
              iconName="Brain"
              iconPosition="left"
            >
              Take Quiz
            </Button>
            <Button
              variant="outline"
              fullWidth
              onClick={() => navigate('/material-upload')}
              iconName="Upload"
              iconPosition="left"
            >
              Upload Material
            </Button>
            <Button
              variant="outline"
              fullWidth
              onClick={() => navigate('/dashboard')}
              iconName="Home"
              iconPosition="left"
            >
              Back to Dashboard
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProgressAnalytics;