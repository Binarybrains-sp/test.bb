import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AchievementGallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const achievements = [
    {
      id: 1,
      title: 'Study Streak Master',
      description: 'Maintain a 30-day study streak',
      category: 'consistency',
      earned: true,
      earnedDate: '15 Aug 2025',
      icon: 'Flame',
      color: 'text-warning',
      bgColor: 'bg-warning/10',
      progress: 100,
      rarity: 'rare',
      xpReward: 500
    },
    {
      id: 2,
      title: 'Quiz Champion',
      description: 'Score 95%+ on 10 consecutive quizzes',
      category: 'performance',
      earned: true,
      earnedDate: '12 Aug 2025',
      icon: 'Trophy',
      color: 'text-success',
      bgColor: 'bg-success/10',
      progress: 100,
      rarity: 'legendary',
      xpReward: 750
    },
    {
      id: 3,
      title: 'Knowledge Seeker',
      description: 'Complete 100 flashcard sessions',
      category: 'engagement',
      earned: true,
      earnedDate: '08 Aug 2025',
      icon: 'BookOpen',
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      progress: 100,
      rarity: 'common',
      xpReward: 200
    },
    {
      id: 4,
      title: 'Speed Learner',
      description: 'Complete a quiz in under 5 minutes with 90%+ score',
      category: 'performance',
      earned: false,
      icon: 'Zap',
      color: 'text-secondary',
      bgColor: 'bg-secondary/10',
      progress: 75,
      rarity: 'rare',
      xpReward: 400
    },
    {
      id: 5,
      title: 'Subject Master',
      description: 'Achieve 95%+ average in any subject',
      category: 'mastery',
      earned: false,
      icon: 'GraduationCap',
      color: 'text-accent',
      bgColor: 'bg-accent/10',
      progress: 92,
      rarity: 'epic',
      xpReward: 600
    },
    {
      id: 6,
      title: 'Early Bird',
      description: 'Study for 7 consecutive days before 8 AM',
      category: 'consistency',
      earned: false,
      icon: 'Sunrise',
      color: 'text-warning',
      bgColor: 'bg-warning/10',
      progress: 42,
      rarity: 'uncommon',
      xpReward: 300
    }
  ];

  const categories = [
    { value: 'all', label: 'All Achievements', count: achievements?.length },
    { value: 'consistency', label: 'Consistency', count: achievements?.filter(a => a?.category === 'consistency')?.length },
    { value: 'performance', label: 'Performance', count: achievements?.filter(a => a?.category === 'performance')?.length },
    { value: 'engagement', label: 'Engagement', count: achievements?.filter(a => a?.category === 'engagement')?.length },
    { value: 'mastery', label: 'Mastery', count: achievements?.filter(a => a?.category === 'mastery')?.length }
  ];

  const milestones = [
    {
      id: 1,
      title: '1000 XP Points',
      description: 'Reach your first thousand experience points',
      progress: 100,
      target: 1000,
      current: 1000,
      completed: true,
      reward: 'Study Streak Multiplier x2'
    },
    {
      id: 2,
      title: '50 Quiz Completions',
      description: 'Complete 50 quizzes across all subjects',
      progress: 86,
      target: 50,
      current: 43,
      completed: false,
      reward: 'Advanced Analytics Unlock'
    },
    {
      id: 3,
      title: '5000 XP Points',
      description: 'Reach the elite 5000 XP milestone',
      progress: 49,
      target: 5000,
      current: 2450,
      completed: false,
      reward: 'Custom Study Plans'
    }
  ];

  const getRarityColor = (rarity) => {
    switch (rarity) {
      case 'common': return 'border-muted-foreground text-muted-foreground';
      case 'uncommon': return 'border-success text-success';
      case 'rare': return 'border-primary text-primary';
      case 'epic': return 'border-accent text-accent';
      case 'legendary': return 'border-warning text-warning';
      default: return 'border-muted text-muted-foreground';
    }
  };

  const filteredAchievements = selectedCategory === 'all' 
    ? achievements 
    : achievements?.filter(a => a?.category === selectedCategory);

  const earnedCount = achievements?.filter(a => a?.earned)?.length;
  const totalXP = achievements?.filter(a => a?.earned)?.reduce((sum, a) => sum + a?.xpReward, 0);

  return (
    <div className="space-y-6">
      {/* Achievement Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="study-card p-4 text-center">
          <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-2">
            <Icon name="Award" size={24} className="text-success" />
          </div>
          <div className="text-2xl font-data font-bold text-foreground">
            {earnedCount}
          </div>
          <div className="text-sm font-caption text-muted-foreground">
            Achievements Earned
          </div>
        </div>
        
        <div className="study-card p-4 text-center">
          <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-2">
            <Icon name="Star" size={24} className="text-warning" />
          </div>
          <div className="text-2xl font-data font-bold text-foreground">
            {totalXP}
          </div>
          <div className="text-sm font-caption text-muted-foreground">
            XP from Achievements
          </div>
        </div>
        
        <div className="study-card p-4 text-center">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-2">
            <Icon name="Target" size={24} className="text-primary" />
          </div>
          <div className="text-2xl font-data font-bold text-foreground">
            {Math.round((earnedCount / achievements?.length) * 100)}%
          </div>
          <div className="text-sm font-caption text-muted-foreground">
            Completion Rate
          </div>
        </div>
      </div>
      {/* Achievement Gallery */}
      <div className="study-card p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <div className="mb-4 sm:mb-0">
            <h2 className="text-lg font-heading font-semibold text-foreground mb-1">
              Achievement Gallery
            </h2>
            <p className="text-sm font-caption text-muted-foreground">
              Track your learning milestones and unlock rewards
            </p>
          </div>
          
          <Button variant="outline" size="sm" iconName="Share" iconPosition="left">
            Share Progress
          </Button>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          {categories?.map((category) => (
            <button
              key={category?.value}
              onClick={() => setSelectedCategory(category?.value)}
              className={`px-3 py-1 rounded-full text-xs font-caption transition-colors ${
                selectedCategory === category?.value
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {category?.label} ({category?.count})
            </button>
          ))}
        </div>

        {/* Achievement Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAchievements?.map((achievement) => (
            <div
              key={achievement?.id}
              className={`border rounded-lg p-4 transition-all hover:scale-105 ${
                achievement?.earned 
                  ? 'border-success/20 bg-success/5' :'border-border hover:border-primary/20'
              }`}
            >
              <div className="flex items-start space-x-3 mb-3">
                <div className={`w-12 h-12 ${achievement?.bgColor} rounded-lg flex items-center justify-center flex-shrink-0 ${
                  achievement?.earned ? 'achievement-celebration' : ''
                }`}>
                  <Icon 
                    name={achievement?.icon} 
                    size={20} 
                    className={achievement?.earned ? achievement?.color : 'text-muted-foreground'} 
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h3 className={`text-sm font-heading font-medium ${
                      achievement?.earned ? 'text-foreground' : 'text-muted-foreground'
                    }`}>
                      {achievement?.title}
                    </h3>
                    {achievement?.earned && (
                      <Icon name="CheckCircle" size={14} className="text-success" />
                    )}
                  </div>
                  <p className="text-xs font-caption text-muted-foreground mb-2">
                    {achievement?.description}
                  </p>
                  <div className={`text-xs font-caption px-2 py-1 rounded-full border inline-block ${getRarityColor(achievement?.rarity)}`}>
                    {achievement?.rarity?.charAt(0)?.toUpperCase() + achievement?.rarity?.slice(1)}
                  </div>
                </div>
              </div>

              {/* Progress Bar for Unearned Achievements */}
              {!achievement?.earned && (
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs font-caption mb-1">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-data text-foreground">{achievement?.progress}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="progress-indicator h-2 rounded-full"
                      style={{ width: `${achievement?.progress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Achievement Details */}
              <div className="flex items-center justify-between text-xs font-caption">
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={12} className="text-warning" />
                  <span className="text-muted-foreground">{achievement?.xpReward} XP</span>
                </div>
                {achievement?.earned && (
                  <span className="text-muted-foreground">
                    Earned {achievement?.earnedDate}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Progress Milestones */}
      <div className="study-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Progress Milestones
          </h3>
          <Button variant="ghost" size="sm" iconName="Eye" iconPosition="left">
            View All
          </Button>
        </div>

        <div className="space-y-4">
          {milestones?.map((milestone) => (
            <div key={milestone?.id} className="border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h4 className="text-sm font-heading font-medium text-foreground">
                    {milestone?.title}
                  </h4>
                  <p className="text-xs font-caption text-muted-foreground">
                    {milestone?.description}
                  </p>
                </div>
                {milestone?.completed && (
                  <Icon name="CheckCircle" size={20} className="text-success" />
                )}
              </div>
              
              <div className="mb-3">
                <div className="flex items-center justify-between text-xs font-caption mb-1">
                  <span className="text-muted-foreground">
                    {milestone?.current} / {milestone?.target}
                  </span>
                  <span className="font-data text-foreground">{milestone?.progress}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      milestone?.completed ? 'bg-success' : 'progress-indicator'
                    }`}
                    style={{ width: `${milestone?.progress}%` }}
                  />
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1 text-xs font-caption text-muted-foreground">
                  <Icon name="Gift" size={12} />
                  <span>Reward: {milestone?.reward}</span>
                </div>
                {!milestone?.completed && (
                  <span className="text-xs font-data text-primary">
                    {milestone?.target - milestone?.current} remaining
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AchievementGallery;