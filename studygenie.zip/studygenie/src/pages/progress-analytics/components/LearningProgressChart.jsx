import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LearningProgressChart = () => {
  const [timeRange, setTimeRange] = useState('7d');
  const [chartType, setChartType] = useState('line');

  const data = {
    '7d': [
      { date: '15 Aug', xp: 120, studyTime: 2.5, accuracy: 85 },
      { date: '16 Aug', xp: 180, studyTime: 3.2, accuracy: 88 },
      { date: '17 Aug', xp: 150, studyTime: 2.8, accuracy: 82 },
      { date: '18 Aug', xp: 220, studyTime: 4.1, accuracy: 91 },
      { date: '19 Aug', xp: 190, studyTime: 3.5, accuracy: 89 },
      { date: '20 Aug', xp: 250, studyTime: 4.8, accuracy: 94 },
      { date: '21 Aug', xp: 280, studyTime: 5.2, accuracy: 96 }
    ],
    '30d': [
      { date: 'Week 1', xp: 850, studyTime: 18.5, accuracy: 82 },
      { date: 'Week 2', xp: 920, studyTime: 21.2, accuracy: 85 },
      { date: 'Week 3', xp: 1100, studyTime: 24.8, accuracy: 88 },
      { date: 'Week 4', xp: 1250, studyTime: 28.3, accuracy: 91 }
    ],
    '90d': [
      { date: 'Month 1', xp: 3200, studyTime: 85.5, accuracy: 78 },
      { date: 'Month 2', xp: 3800, studyTime: 92.2, accuracy: 83 },
      { date: 'Month 3', xp: 4200, studyTime: 98.8, accuracy: 87 }
    ]
  };

  const timeRanges = [
    { value: '7d', label: '7 Days' },
    { value: '30d', label: '30 Days' },
    { value: '90d', label: '90 Days' }
  ];

  const chartData = data?.[timeRange];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg shadow-modal p-3">
          <p className="text-sm font-heading font-medium text-card-foreground mb-2">
            {label}
          </p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-xs font-caption">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-muted-foreground">{entry?.name}:</span>
              <span className="font-data text-foreground">
                {entry?.name === 'studyTime' ? `${entry?.value}h` : 
                 entry?.name === 'accuracy' ? `${entry?.value}%` : 
                 `${entry?.value} XP`}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="study-card p-6 mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div className="mb-4 sm:mb-0">
          <h2 className="text-lg font-heading font-semibold text-foreground mb-1">
            Learning Progress
          </h2>
          <p className="text-sm font-caption text-muted-foreground">
            Track your study performance over time
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <div className="flex bg-muted rounded-lg p-1">
            {timeRanges?.map((range) => (
              <button
                key={range?.value}
                onClick={() => setTimeRange(range?.value)}
                className={`px-3 py-1 text-xs font-caption rounded-md transition-colors ${
                  timeRange === range?.value
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {range?.label}
              </button>
            ))}
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setChartType(chartType === 'line' ? 'area' : 'line')}
          >
            <Icon name={chartType === 'line' ? 'BarChart3' : 'TrendingUp'} size={16} />
          </Button>
        </div>
      </div>
      <div className="h-80 w-full" aria-label="Learning Progress Chart">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'line' ? (
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="date" 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <YAxis 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line 
                type="monotone" 
                dataKey="xp" 
                stroke="var(--color-primary)" 
                strokeWidth={2}
                dot={{ fill: 'var(--color-primary)', strokeWidth: 2, r: 4 }}
                name="XP Points"
              />
              <Line 
                type="monotone" 
                dataKey="accuracy" 
                stroke="var(--color-success)" 
                strokeWidth={2}
                dot={{ fill: 'var(--color-success)', strokeWidth: 2, r: 4 }}
                name="Accuracy"
              />
            </LineChart>
          ) : (
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="date" 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <YAxis 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area 
                type="monotone" 
                dataKey="xp" 
                stroke="var(--color-primary)" 
                fill="var(--color-primary)"
                fillOpacity={0.1}
                strokeWidth={2}
                name="XP Points"
              />
            </AreaChart>
          )}
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-border">
        <div className="text-center">
          <div className="text-lg font-data font-bold text-primary">
            {chartData?.[chartData?.length - 1]?.xp || 0}
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Latest XP
          </div>
        </div>
        <div className="text-center">
          <div className="text-lg font-data font-bold text-success">
            {chartData?.[chartData?.length - 1]?.accuracy || 0}%
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Current Accuracy
          </div>
        </div>
        <div className="text-center">
          <div className="text-lg font-data font-bold text-secondary">
            {chartData?.[chartData?.length - 1]?.studyTime || 0}h
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Study Time
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearningProgressChart;