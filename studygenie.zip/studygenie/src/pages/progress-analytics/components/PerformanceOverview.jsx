import React from 'react';
import Icon from '../../../components/AppIcon';

const PerformanceOverview = ({ 
  studyStreak = 15, 
  totalXP = 2450, 
  subjectsMastered = 8, 
  weeklyStudyTime = "12h 30m" 
}) => {
  const metrics = [
    {
      id: 'streak',
      label: 'Study Streak',
      value: studyStreak,
      unit: 'days',
      icon: 'Flame',
      color: 'text-warning',
      bgColor: 'bg-warning/10',
      trend: '+2 from last week'
    },
    {
      id: 'xp',
      label: 'Total XP',
      value: totalXP?.toLocaleString(),
      unit: 'points',
      icon: 'Star',
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      trend: '+320 this week'
    },
    {
      id: 'mastered',
      label: 'Subjects Mastered',
      value: subjectsMastered,
      unit: 'subjects',
      icon: 'Trophy',
      color: 'text-success',
      bgColor: 'bg-success/10',
      trend: '+1 this month'
    },
    {
      id: 'time',
      label: 'Weekly Study Time',
      value: weeklyStudyTime,
      unit: '',
      icon: 'Clock',
      color: 'text-secondary',
      bgColor: 'bg-secondary/10',
      trend: '+2h 15m from last week'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {metrics?.map((metric) => (
        <div key={metric?.id} className="study-card p-4">
          <div className="flex items-center justify-between mb-3">
            <div className={`w-10 h-10 ${metric?.bgColor} rounded-lg flex items-center justify-center`}>
              <Icon name={metric?.icon} size={20} className={metric?.color} />
            </div>
            <div className="text-right">
              <div className="text-2xl font-data font-bold text-foreground">
                {metric?.value}
              </div>
              {metric?.unit && (
                <div className="text-xs font-caption text-muted-foreground">
                  {metric?.unit}
                </div>
              )}
            </div>
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-heading font-medium text-foreground">
              {metric?.label}
            </h3>
            <p className="text-xs font-caption text-muted-foreground">
              {metric?.trend}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PerformanceOverview;