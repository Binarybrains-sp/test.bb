import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const StudyPatternAnalysis = () => {
  const [selectedView, setSelectedView] = useState('hourly');

  const hourlyData = [
    { hour: '6 AM', sessions: 2, duration: 45, focus: 85 },
    { hour: '8 AM', sessions: 5, duration: 90, focus: 92 },
    { hour: '10 AM', sessions: 8, duration: 120, focus: 88 },
    { hour: '12 PM', sessions: 6, duration: 75, focus: 78 },
    { hour: '2 PM', sessions: 4, duration: 60, focus: 72 },
    { hour: '4 PM', sessions: 7, duration: 105, focus: 85 },
    { hour: '6 PM', sessions: 9, duration: 135, focus: 90 },
    { hour: '8 PM', sessions: 12, duration: 150, focus: 94 },
    { hour: '10 PM', sessions: 6, duration: 80, focus: 82 }
  ];

  const weeklyData = [
    { day: 'Mon', sessions: 8, duration: 240, focus: 88 },
    { day: 'Tue', sessions: 6, duration: 180, focus: 85 },
    { day: 'Wed', sessions: 9, duration: 270, focus: 92 },
    { day: 'Thu', sessions: 7, duration: 210, focus: 87 },
    { day: 'Fri', sessions: 5, duration: 150, focus: 80 },
    { day: 'Sat', sessions: 12, duration: 360, focus: 95 },
    { day: 'Sun', sessions: 10, duration: 300, focus: 90 }
  ];

  const performanceRadarData = [
    { subject: 'Math', morning: 92, afternoon: 85, evening: 88, night: 82 },
    { subject: 'Physics', morning: 88, afternoon: 90, evening: 94, night: 86 },
    { subject: 'Chemistry', morning: 85, afternoon: 82, evening: 87, night: 89 },
    { subject: 'Biology', morning: 90, afternoon: 88, evening: 91, night: 85 }
  ];

  const studyHabits = [
    {
      id: 'peak_time',
      title: 'Peak Performance Time',
      value: '8:00 PM - 10:00 PM',
      icon: 'Clock',
      color: 'text-primary',
      description: 'Your highest focus and retention rates occur during evening hours'
    },
    {
      id: 'avg_session',
      title: 'Average Session Length',
      value: '45 minutes',
      icon: 'Timer',
      color: 'text-success',
      description: 'Optimal session duration for maintaining concentration'
    },
    {
      id: 'best_day',
      title: 'Most Productive Day',
      value: 'Saturday',
      icon: 'Calendar',
      color: 'text-warning',
      description: 'Consistently highest study time and performance scores'
    },
    {
      id: 'focus_score',
      title: 'Average Focus Score',
      value: '87%',
      icon: 'Target',
      color: 'text-secondary',
      description: 'Based on session completion rates and quiz performance'
    }
  ];

  const recommendations = [
    {
      id: 1,
      type: 'schedule',
      title: 'Optimize Study Schedule',
      description: 'Schedule challenging subjects during your peak hours (8-10 PM) for better retention.',
      impact: 'High',
      icon: 'Calendar'
    },
    {
      id: 2,
      type: 'break',
      title: 'Improve Break Patterns',
      description: 'Take 10-minute breaks every 45 minutes to maintain focus throughout longer sessions.',
      impact: 'Medium',
      icon: 'Coffee'
    },
    {
      id: 3,
      type: 'weekend',
      title: 'Weekend Study Strategy',
      description: 'Leverage your high Saturday productivity for review sessions and difficult topics.',
      impact: 'High',
      icon: 'TrendingUp'
    }
  ];

  const getImpactColor = (impact) => {
    switch (impact) {
      case 'High': return 'bg-destructive/10 text-destructive';
      case 'Medium': return 'bg-warning/10 text-warning';
      case 'Low': return 'bg-success/10 text-success';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg shadow-modal p-3">
          <p className="text-sm font-heading font-medium text-card-foreground mb-2">
            {label}
          </p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-xs font-caption">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-muted-foreground">{entry?.name}:</span>
              <span className="font-data text-foreground">
                {entry?.name === 'duration' ? `${entry?.value}m` : 
                 entry?.name === 'focus' ? `${entry?.value}%` : 
                 entry?.value}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Study Habits Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {studyHabits?.map((habit) => (
          <div key={habit?.id} className="study-card p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name={habit?.icon} size={18} className={habit?.color} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-lg font-data font-bold text-foreground">
                  {habit?.value}
                </div>
                <div className="text-xs font-caption text-muted-foreground">
                  {habit?.title}
                </div>
              </div>
            </div>
            <p className="text-xs font-caption text-muted-foreground">
              {habit?.description}
            </p>
          </div>
        ))}
      </div>
      {/* Study Pattern Charts */}
      <div className="study-card p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <div className="mb-4 sm:mb-0">
            <h2 className="text-lg font-heading font-semibold text-foreground mb-1">
              Study Pattern Analysis
            </h2>
            <p className="text-sm font-caption text-muted-foreground">
              Understand your learning patterns and optimize study schedules
            </p>
          </div>
          
          <div className="flex bg-muted rounded-lg p-1">
            <button
              onClick={() => setSelectedView('hourly')}
              className={`px-3 py-1 text-xs font-caption rounded-md transition-colors ${
                selectedView === 'hourly' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Hourly
            </button>
            <button
              onClick={() => setSelectedView('weekly')}
              className={`px-3 py-1 text-xs font-caption rounded-md transition-colors ${
                selectedView === 'weekly' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Weekly
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Pattern Chart */}
          <div className="lg:col-span-2">
            <div className="h-64 w-full" aria-label="Study Pattern Chart">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={selectedView === 'hourly' ? hourlyData : weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis 
                    dataKey={selectedView === 'hourly' ? 'hour' : 'day'}
                    stroke="var(--color-muted-foreground)"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="var(--color-muted-foreground)"
                    fontSize={12}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar 
                    dataKey="sessions" 
                    fill="var(--color-primary)"
                    radius={[4, 4, 0, 0]}
                    name="Sessions"
                  />
                  <Bar 
                    dataKey="focus" 
                    fill="var(--color-success)"
                    radius={[4, 4, 0, 0]}
                    name="Focus Score"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Performance Radar */}
          <div className="space-y-4">
            <h3 className="text-sm font-heading font-medium text-foreground">
              Time-based Performance
            </h3>
            <div className="h-48 w-full" aria-label="Performance Radar Chart">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={performanceRadarData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="subject" fontSize={10} />
                  <PolarRadiusAxis domain={[0, 100]} fontSize={8} />
                  <Radar
                    name="Morning"
                    dataKey="morning"
                    stroke="var(--color-primary)"
                    fill="var(--color-primary)"
                    fillOpacity={0.1}
                  />
                  <Radar
                    name="Evening"
                    dataKey="evening"
                    stroke="var(--color-success)"
                    fill="var(--color-success)"
                    fillOpacity={0.1}
                  />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
      {/* Recommendations */}
      <div className="study-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Personalized Recommendations
          </h3>
          <Button variant="outline" size="sm" iconName="RefreshCw" iconPosition="left">
            Update Analysis
          </Button>
        </div>

        <div className="space-y-4">
          {recommendations?.map((rec) => (
            <div key={rec?.id} className="border border-border rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name={rec?.icon} size={18} className="text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="text-sm font-heading font-medium text-foreground">
                      {rec?.title}
                    </h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-caption ${getImpactColor(rec?.impact)}`}>
                      {rec?.impact} Impact
                    </span>
                  </div>
                  <p className="text-sm font-caption text-muted-foreground mb-3">
                    {rec?.description}
                  </p>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      Apply
                    </Button>
                    <Button variant="ghost" size="sm">
                      Learn More
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudyPatternAnalysis;