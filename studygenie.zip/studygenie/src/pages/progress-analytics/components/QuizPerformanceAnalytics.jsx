import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuizPerformanceAnalytics = () => {
  const [viewType, setViewType] = useState('accuracy');

  const accuracyData = [
    { subject: 'Math', accuracy: 92, quizzes: 15, avgScore: 87 },
    { subject: 'Physics', accuracy: 88, quizzes: 12, avgScore: 84 },
    { subject: 'Chemistry', accuracy: 85, quizzes: 10, avgScore: 81 },
    { subject: 'Biology', accuracy: 91, quizzes: 14, avgScore: 89 }
  ];

  const improvementData = [
    { week: 'Week 1', score: 72, attempts: 8 },
    { week: 'Week 2', score: 78, attempts: 12 },
    { week: 'Week 3', score: 84, attempts: 15 },
    { week: 'Week 4', score: 89, attempts: 18 }
  ];

  const difficultyData = [
    { name: 'Easy', value: 45, color: 'var(--color-success)' },
    { name: 'Medium', value: 35, color: 'var(--color-warning)' },
    { name: 'Hard', value: 20, color: 'var(--color-destructive)' }
  ];

  const recentQuizzes = [
    {
      id: 1,
      subject: 'Mathematics',
      topic: 'Calculus',
      score: 94,
      totalQuestions: 20,
      correctAnswers: 19,
      timeSpent: '15m 30s',
      date: '21 Aug 2025',
      difficulty: 'Hard'
    },
    {
      id: 2,
      subject: 'Physics',
      topic: 'Mechanics',
      score: 87,
      totalQuestions: 15,
      correctAnswers: 13,
      timeSpent: '12m 45s',
      date: '20 Aug 2025',
      difficulty: 'Medium'
    },
    {
      id: 3,
      subject: 'Chemistry',
      topic: 'Organic Chemistry',
      score: 91,
      totalQuestions: 18,
      correctAnswers: 16,
      timeSpent: '18m 20s',
      date: '19 Aug 2025',
      difficulty: 'Hard'
    }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg shadow-modal p-3">
          <p className="text-sm font-heading font-medium text-card-foreground mb-2">
            {label}
          </p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-xs font-caption">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-muted-foreground">{entry?.name}:</span>
              <span className="font-data text-foreground">
                {entry?.name === 'accuracy' ? `${entry?.value}%` : entry?.value}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 80) return 'text-warning';
    if (score >= 70) return 'text-secondary';
    return 'text-destructive';
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy': return 'bg-success/10 text-success';
      case 'Medium': return 'bg-warning/10 text-warning';
      case 'Hard': return 'bg-destructive/10 text-destructive';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Quiz Performance Charts */}
      <div className="study-card p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <div className="mb-4 sm:mb-0">
            <h2 className="text-lg font-heading font-semibold text-foreground mb-1">
              Quiz Performance Analytics
            </h2>
            <p className="text-sm font-caption text-muted-foreground">
              Detailed analysis of your quiz performance and improvement trends
            </p>
          </div>
          
          <div className="flex bg-muted rounded-lg p-1">
            <button
              onClick={() => setViewType('accuracy')}
              className={`px-3 py-1 text-xs font-caption rounded-md transition-colors ${
                viewType === 'accuracy' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Accuracy
            </button>
            <button
              onClick={() => setViewType('improvement')}
              className={`px-3 py-1 text-xs font-caption rounded-md transition-colors ${
                viewType === 'improvement' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Improvement
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Chart */}
          <div className="lg:col-span-2">
            <div className="h-64 w-full" aria-label="Quiz Performance Chart">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={viewType === 'accuracy' ? accuracyData : improvementData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis 
                    dataKey={viewType === 'accuracy' ? 'subject' : 'week'}
                    stroke="var(--color-muted-foreground)"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="var(--color-muted-foreground)"
                    fontSize={12}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar 
                    dataKey={viewType === 'accuracy' ? 'accuracy' : 'score'}
                    fill="var(--color-primary)"
                    radius={[4, 4, 0, 0]}
                    name={viewType === 'accuracy' ? 'Accuracy' : 'Score'}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Difficulty Distribution */}
          <div className="space-y-4">
            <h3 className="text-sm font-heading font-medium text-foreground">
              Question Difficulty Distribution
            </h3>
            <div className="h-48 w-full" aria-label="Difficulty Distribution Chart">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={difficultyData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {difficultyData?.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry?.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2">
              {difficultyData?.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-xs font-caption">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item?.color }}
                    />
                    <span className="text-muted-foreground">{item?.name}</span>
                  </div>
                  <span className="font-data text-foreground">{item?.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Recent Quiz Results */}
      <div className="study-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Recent Quiz Results
          </h3>
          <Button variant="outline" size="sm" iconName="Eye" iconPosition="left">
            View All
          </Button>
        </div>

        <div className="space-y-3">
          {recentQuizzes?.map((quiz) => (
            <div key={quiz?.id} className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="Brain" size={18} className="text-primary" />
                  </div>
                  <div>
                    <h4 className="text-sm font-heading font-medium text-foreground">
                      {quiz?.subject} - {quiz?.topic}
                    </h4>
                    <p className="text-xs font-caption text-muted-foreground">
                      {quiz?.date} • {quiz?.timeSpent}
                    </p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className={`text-lg font-data font-bold ${getScoreColor(quiz?.score)}`}>
                    {quiz?.score}%
                  </div>
                  <div className="text-xs font-caption text-muted-foreground">
                    {quiz?.correctAnswers}/{quiz?.totalQuestions} correct
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className={`px-2 py-1 rounded-full text-xs font-caption ${getDifficultyColor(quiz?.difficulty)}`}>
                  {quiz?.difficulty}
                </span>
                
                <div className="flex items-center space-x-4 text-xs font-caption text-muted-foreground">
                  <span className="flex items-center space-x-1">
                    <Icon name="Clock" size={12} />
                    <span>{quiz?.timeSpent}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Icon name="Target" size={12} />
                    <span>{quiz?.totalQuestions} questions</span>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuizPerformanceAnalytics;