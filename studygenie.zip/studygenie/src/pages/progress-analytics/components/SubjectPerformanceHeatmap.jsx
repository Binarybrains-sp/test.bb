import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SubjectPerformanceHeatmap = () => {
  const [selectedSubject, setSelectedSubject] = useState(null);

  const subjects = [
    {
      id: 'mathematics',
      name: 'Mathematics',
      icon: 'Calculator',
      overallScore: 92,
      topics: [
        { name: 'Algebra', score: 95, sessions: 12, lastStudied: '2 days ago' },
        { name: 'Geometry', score: 88, sessions: 8, lastStudied: '1 day ago' },
        { name: 'Calculus', score: 94, sessions: 15, lastStudied: '3 hours ago' },
        { name: 'Statistics', score: 90, sessions: 6, lastStudied: '1 week ago' },
        { name: 'Trigonometry', score: 85, sessions: 10, lastStudied: '4 days ago' }
      ]
    },
    {
      id: 'physics',
      name: 'Physics',
      icon: 'Atom',
      overallScore: 87,
      topics: [
        { name: 'Mechanics', score: 91, sessions: 14, lastStudied: '1 day ago' },
        { name: 'Thermodynamics', score: 82, sessions: 9, lastStudied: '3 days ago' },
        { name: 'Electromagnetism', score: 89, sessions: 11, lastStudied: '2 days ago' },
        { name: 'Optics', score: 85, sessions: 7, lastStudied: '5 days ago' },
        { name: 'Modern Physics', score: 88, sessions: 8, lastStudied: '1 day ago' }
      ]
    },
    {
      id: 'chemistry',
      name: 'Chemistry',
      icon: 'Flask',
      overallScore: 84,
      topics: [
        { name: 'Organic Chemistry', score: 87, sessions: 13, lastStudied: '2 days ago' },
        { name: 'Inorganic Chemistry', score: 81, sessions: 10, lastStudied: '4 days ago' },
        { name: 'Physical Chemistry', score: 85, sessions: 9, lastStudied: '1 day ago' },
        { name: 'Analytical Chemistry', score: 83, sessions: 6, lastStudied: '1 week ago' }
      ]
    },
    {
      id: 'biology',
      name: 'Biology',
      icon: 'Dna',
      overallScore: 89,
      topics: [
        { name: 'Cell Biology', score: 92, sessions: 11, lastStudied: '1 day ago' },
        { name: 'Genetics', score: 88, sessions: 9, lastStudied: '3 days ago' },
        { name: 'Ecology', score: 86, sessions: 7, lastStudied: '2 days ago' },
        { name: 'Human Anatomy', score: 91, sessions: 12, lastStudied: '4 hours ago' },
        { name: 'Evolution', score: 87, sessions: 8, lastStudied: '5 days ago' }
      ]
    }
  ];

  const getScoreColor = (score) => {
    if (score >= 90) return 'bg-success text-success-foreground';
    if (score >= 80) return 'bg-warning text-warning-foreground';
    if (score >= 70) return 'bg-secondary text-secondary-foreground';
    return 'bg-destructive text-destructive-foreground';
  };

  const getScoreIntensity = (score) => {
    if (score >= 90) return 'opacity-100';
    if (score >= 80) return 'opacity-75';
    if (score >= 70) return 'opacity-50';
    return 'opacity-25';
  };

  return (
    <div className="study-card p-6 mb-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-heading font-semibold text-foreground mb-1">
            Subject Performance Heatmap
          </h2>
          <p className="text-sm font-caption text-muted-foreground">
            Visual breakdown of your strengths and areas for improvement
          </p>
        </div>
        
        <Button variant="outline" size="sm" iconName="Download" iconPosition="left">
          Export
        </Button>
      </div>
      {/* Desktop Grid View */}
      <div className="hidden lg:block">
        <div className="grid grid-cols-4 gap-6">
          {subjects?.map((subject) => (
            <div key={subject?.id} className="space-y-3">
              <div className="flex items-center space-x-2 mb-3">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon name={subject?.icon} size={16} className="text-primary" />
                </div>
                <div>
                  <h3 className="text-sm font-heading font-medium text-foreground">
                    {subject?.name}
                  </h3>
                  <p className="text-xs font-data text-muted-foreground">
                    {subject?.overallScore}% overall
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                {subject?.topics?.map((topic, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded-md border cursor-pointer transition-all hover:scale-105 ${getScoreColor(topic?.score)} ${getScoreIntensity(topic?.score)}`}
                    onClick={() => setSelectedSubject({ subject, topic })}
                  >
                    <div className="text-xs font-caption font-medium">
                      {topic?.name}
                    </div>
                    <div className="text-xs font-data">
                      {topic?.score}%
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Mobile Card View */}
      <div className="lg:hidden space-y-4">
        {subjects?.map((subject) => (
          <div key={subject?.id} className="border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon name={subject?.icon} size={16} className="text-primary" />
                </div>
                <div>
                  <h3 className="text-sm font-heading font-medium text-foreground">
                    {subject?.name}
                  </h3>
                  <p className="text-xs font-data text-muted-foreground">
                    Overall: {subject?.overallScore}%
                  </p>
                </div>
              </div>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedSubject(selectedSubject?.subject?.id === subject?.id ? null : { subject })}
              >
                <Icon 
                  name={selectedSubject?.subject?.id === subject?.id ? 'ChevronUp' : 'ChevronDown'} 
                  size={16} 
                />
              </Button>
            </div>
            
            {selectedSubject?.subject?.id === subject?.id && (
              <div className="grid grid-cols-2 gap-2 mt-3">
                {subject?.topics?.map((topic, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded-md text-center ${getScoreColor(topic?.score)}`}
                  >
                    <div className="text-xs font-caption font-medium mb-1">
                      {topic?.name}
                    </div>
                    <div className="text-sm font-data font-bold">
                      {topic?.score}%
                    </div>
                    <div className="text-xs opacity-75">
                      {topic?.sessions} sessions
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      {/* Performance Legend */}
      <div className="flex items-center justify-center space-x-6 mt-6 pt-4 border-t border-border">
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-success rounded"></div>
          <span className="text-xs font-caption text-muted-foreground">Excellent (90%+)</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-warning rounded"></div>
          <span className="text-xs font-caption text-muted-foreground">Good (80-89%)</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-secondary rounded"></div>
          <span className="text-xs font-caption text-muted-foreground">Average (70-79%)</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-destructive rounded"></div>
          <span className="text-xs font-caption text-muted-foreground">Needs Work (&lt;70%)</span>
        </div>
      </div>
    </div>
  );
};

export default SubjectPerformanceHeatmap;