import React, { useState } from 'react';
import { Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SpacedRepetitionInsights = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('week');

  const retentionData = [
    { interval: '1 day', retention: 95, cards: 45 },
    { interval: '3 days', retention: 88, cards: 38 },
    { interval: '1 week', retention: 82, cards: 32 },
    { interval: '2 weeks', retention: 78, cards: 28 },
    { interval: '1 month', retention: 74, cards: 24 },
    { interval: '3 months', retention: 71, cards: 20 }
  ];

  const upcomingReviews = [
    {
      id: 1,
      subject: 'Mathematics',
      topic: 'Quadratic Equations',
      dueIn: '2 hours',
      difficulty: 'Medium',
      lastScore: 87,
      reviewCount: 3,
      priority: 'high'
    },
    {
      id: 2,
      subject: 'Physics',
      topic: 'Newton\'s Laws',
      dueIn: '4 hours',
      difficulty: 'Easy',
      lastScore: 94,
      reviewCount: 5,
      priority: 'medium'
    },
    {
      id: 3,
      subject: 'Chemistry',
      topic: 'Periodic Table',
      dueIn: '1 day',
      difficulty: 'Hard',
      lastScore: 72,
      reviewCount: 2,
      priority: 'high'
    },
    {
      id: 4,
      subject: 'Biology',
      topic: 'Cell Division',
      dueIn: '2 days',
      difficulty: 'Medium',
      lastScore: 89,
      reviewCount: 4,
      priority: 'low'
    }
  ];

  const reviewStats = {
    totalCards: 156,
    dueToday: 12,
    overdue: 3,
    avgRetention: 84,
    optimalInterval: '5.2 days',
    totalReviews: 1247
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'medium': return 'bg-warning/10 text-warning border-warning/20';
      case 'low': return 'bg-success/10 text-success border-success/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getDifficultyIcon = (difficulty) => {
    switch (difficulty) {
      case 'Easy': return 'Circle';
      case 'Medium': return 'Minus';
      case 'Hard': return 'X';
      default: return 'Circle';
    }
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg shadow-modal p-3">
          <p className="text-sm font-heading font-medium text-card-foreground mb-2">
            {label}
          </p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-xs font-caption">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-muted-foreground">{entry?.name}:</span>
              <span className="font-data text-foreground">
                {entry?.name === 'retention' ? `${entry?.value}%` : `${entry?.value} cards`}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Retention Analysis */}
      <div className="study-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-heading font-semibold text-foreground mb-1">
              Spaced Repetition Effectiveness
            </h2>
            <p className="text-sm font-caption text-muted-foreground">
              Track retention rates and optimize review intervals
            </p>
          </div>
          
          <Button variant="outline" size="sm" iconName="Settings" iconPosition="left">
            Adjust Settings
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-primary">
              {reviewStats?.totalCards}
            </div>
            <div className="text-xs font-caption text-muted-foreground">
              Total Cards
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-warning">
              {reviewStats?.dueToday}
            </div>
            <div className="text-xs font-caption text-muted-foreground">
              Due Today
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-destructive">
              {reviewStats?.overdue}
            </div>
            <div className="text-xs font-caption text-muted-foreground">
              Overdue
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-success">
              {reviewStats?.avgRetention}%
            </div>
            <div className="text-xs font-caption text-muted-foreground">
              Avg Retention
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-secondary">
              {reviewStats?.optimalInterval}
            </div>
            <div className="text-xs font-caption text-muted-foreground">
              Optimal Interval
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-data font-bold text-foreground">
              {reviewStats?.totalReviews?.toLocaleString()}
            </div>
            <div className="text-xs font-caption text-muted-foreground">
              Total Reviews
            </div>
          </div>
        </div>

        {/* Retention Chart */}
        <div className="h-64 w-full" aria-label="Retention Rate Chart">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={retentionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="interval" 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <YAxis 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
                domain={[60, 100]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area 
                type="monotone" 
                dataKey="retention" 
                stroke="var(--color-primary)" 
                fill="var(--color-primary)"
                fillOpacity={0.1}
                strokeWidth={2}
                name="Retention Rate"
              />
              <Line 
                type="monotone" 
                dataKey="cards" 
                stroke="var(--color-secondary)" 
                strokeWidth={2}
                dot={{ fill: 'var(--color-secondary)', strokeWidth: 2, r: 4 }}
                name="Cards Reviewed"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      {/* Upcoming Reviews */}
      <div className="study-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Upcoming Reviews
          </h3>
          <Button variant="default" size="sm" iconName="Play" iconPosition="left">
            Start Review Session
          </Button>
        </div>

        <div className="space-y-3">
          {upcomingReviews?.map((review) => (
            <div key={review?.id} className={`border rounded-lg p-4 ${getPriorityColor(review?.priority)}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="RotateCcw" size={18} className="text-primary" />
                  </div>
                  <div>
                    <h4 className="text-sm font-heading font-medium text-foreground">
                      {review?.subject} - {review?.topic}
                    </h4>
                    <p className="text-xs font-caption text-muted-foreground">
                      Due in {review?.dueIn} • Review #{review?.reviewCount}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <div className="text-right">
                    <div className="text-sm font-data font-bold text-foreground">
                      {review?.lastScore}%
                    </div>
                    <div className="text-xs font-caption text-muted-foreground">
                      Last Score
                    </div>
                  </div>
                  <Icon name={getDifficultyIcon(review?.difficulty)} size={16} className="text-muted-foreground" />
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs font-caption text-muted-foreground">
                  {review?.difficulty} difficulty
                </span>
                
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    Skip
                  </Button>
                  <Button variant="outline" size="sm">
                    Review Now
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Review Schedule Optimization */}
        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Lightbulb" size={16} className="text-warning" />
            <h4 className="text-sm font-heading font-medium text-foreground">
              Optimization Suggestion
            </h4>
          </div>
          <p className="text-sm font-caption text-muted-foreground">
            Based on your performance, consider increasing the review interval for high-scoring cards 
            and decreasing it for cards with scores below 80%. This could improve your retention by 12%.
          </p>
          <div className="flex items-center space-x-2 mt-3">
            <Button variant="outline" size="sm">
              Apply Suggestion
            </Button>
            <Button variant="ghost" size="sm">
              Learn More
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpacedRepetitionInsights;