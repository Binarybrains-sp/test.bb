import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import StudySessionHeader from '../../components/ui/StudySessionHeader';
import ProgressNotificationSystem from '../../components/ui/ProgressNotificationSystem';
import FlashcardDisplay from './components/FlashcardDisplay';
import SessionStats from './components/SessionStats';
import UpcomingCards from './components/UpcomingCards';
import BreakReminder from './components/BreakReminder';
import SessionSettings from './components/SessionSettings';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const StudySessionFlashcards = () => {
  const navigate = useNavigate();
  
  // Mock flashcard data
  const mockFlashcards = [
    {
      id: 1,
      question: "What is the capital of France?",
      answer: "Paris",
      explanation: "Paris is the capital and most populous city of France, located in the north-central part of the country.",
      examples: ["The Eiffel Tower is located in Paris", "Paris is known as the City of Light"],
      subject: "Geography",
      difficulty: "easy",
      isBookmarked: false,
      hasAudio: true
    },
    {
      id: 2,
      question: "What is photosynthesis?",
      answer: "The process by which plants convert sunlight into energy",
      explanation: "Photosynthesis is the biological process where plants use chlorophyll to convert carbon dioxide and water into glucose using sunlight energy.",
      examples: ["Plants produce oxygen as a byproduct", "Chloroplasts are the organelles where photosynthesis occurs"],
      subject: "Biology",
      difficulty: "medium",
      isBookmarked: true,
      hasAudio: true
    },
    {
      id: 3,
      question: "Solve: 2x + 5 = 13",
      answer: "x = 4",
      explanation: "To solve this linear equation: 2x + 5 = 13\nSubtract 5 from both sides: 2x = 8\nDivide by 2: x = 4",
      examples: ["Check: 2(4) + 5 = 8 + 5 = 13 ✓"],
      subject: "Mathematics",
      difficulty: "medium",
      isBookmarked: false,
      hasAudio: true
    },
    {
      id: 4,
      question: "What is the difference between mitosis and meiosis?",
      answer: "Mitosis produces identical diploid cells, meiosis produces genetically diverse haploid gametes",
      explanation: "Mitosis is cell division that produces two identical diploid cells for growth and repair. Meiosis is specialized division that produces four genetically diverse haploid gametes for reproduction.",
      examples: ["Mitosis: skin cell regeneration", "Meiosis: sperm and egg cell formation"],
      subject: "Biology",
      difficulty: "hard",
      isBookmarked: false,
      hasAudio: true
    },
    {
      id: 5,
      question: "What is Newton\'s First Law of Motion?",
      answer: "An object at rest stays at rest, and an object in motion stays in motion, unless acted upon by an external force",
      explanation: "Also known as the Law of Inertia, this law describes the tendency of objects to maintain their state of motion.",
      examples: ["A ball rolling on a frictionless surface continues rolling", "A book on a table remains stationary"],
      subject: "Physics",
      difficulty: "medium",
      isBookmarked: true,
      hasAudio: true
    }
  ];

  // Session state
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [sessionStartTime] = useState(new Date());
  const [timeElapsed, setTimeElapsed] = useState('00:00');
  const [streakCount, setStreakCount] = useState(7);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [difficultyDistribution, setDifficultyDistribution] = useState({
    easy: 0,
    good: 0,
    hard: 0
  });
  const [bookmarkedCards, setBookmarkedCards] = useState(new Set([2, 5]));
  const [showBreakReminder, setShowBreakReminder] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);
  const [notifications, setNotifications] = useState([]);
  const [sessionSettings, setSessionSettings] = useState({
    autoAdvance: false,
    showTimer: true,
    audioEnabled: true,
    language: 'en',
    cardOrder: 'sequential',
    breakReminders: true,
    breakInterval: 25,
    showProgress: true,
    keyboardShortcuts: true
  });

  // Timer effect
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isPaused) {
        const elapsed = Math.floor((new Date() - sessionStartTime) / 1000);
        const minutes = Math.floor(elapsed / 60);
        const seconds = elapsed % 60;
        setTimeElapsed(`${minutes?.toString()?.padStart(2, '0')}:${seconds?.toString()?.padStart(2, '0')}`);
        
        // Check for break reminder
        if (sessionSettings?.breakReminders && minutes > 0 && minutes % sessionSettings?.breakInterval === 0 && seconds === 0) {
          setShowBreakReminder(true);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isPaused, sessionStartTime, sessionSettings?.breakReminders, sessionSettings?.breakInterval]);

  // Handlers
  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleNext = () => {
    if (currentCardIndex < mockFlashcards?.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
      setIsFlipped(false);
    } else {
      handleSessionComplete();
    }
  };

  const handlePrevious = () => {
    if (currentCardIndex > 0) {
      setCurrentCardIndex(prev => prev - 1);
      setIsFlipped(false);
    }
  };

  const handleDifficultySelect = (difficulty) => {
    setDifficultyDistribution(prev => ({
      ...prev,
      [difficulty]: prev?.[difficulty] + 1
    }));

    if (difficulty === 'easy') {
      setCorrectAnswers(prev => prev + 1);
      setStreakCount(prev => prev + 1);
      
      // Add achievement notification
      if (streakCount + 1 === 10) {
        addNotification({
          id: Date.now(),
          type: 'streak',
          title: '10-Card Streak!',
          message: 'You\'re on fire! Keep up the excellent work.',
          details: { streak: 10, points: 50 }
        });
      }
    } else if (difficulty === 'hard') {
      setStreakCount(0);
    }

    if (sessionSettings?.autoAdvance) {
      setTimeout(() => handleNext(), 1000);
    }
  };

  const handleBookmark = (cardId) => {
    setBookmarkedCards(prev => {
      const newSet = new Set(prev);
      if (newSet?.has(cardId)) {
        newSet?.delete(cardId);
      } else {
        newSet?.add(cardId);
      }
      return newSet;
    });
  };

  const handleAudioPlay = (text) => {
    if (sessionSettings?.audioEnabled && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = sessionSettings?.language === 'hi' ? 'hi-IN' : 'en-US';
      speechSynthesis.speak(utterance);
    }
  };

  const handleSessionComplete = () => {
    addNotification({
      id: Date.now(),
      type: 'achievement',
      title: 'Session Complete!',
      message: `Great job! You completed ${mockFlashcards?.length} flashcards.`,
      details: { points: 100, level: 5 },
      actionLabel: 'View Results',
      onAction: () => navigate('/progress-analytics')
    });
    
    setTimeout(() => {
      navigate('/dashboard');
    }, 3000);
  };

  const handleExit = () => {
    const confirmExit = window.confirm('Are you sure you want to exit this study session? Your progress will be saved.');
    if (confirmExit) {
      navigate('/dashboard');
    }
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleSettings = () => {
    setShowSettings(true);
  };

  const addNotification = (notification) => {
    setNotifications(prev => [...prev, notification]);
  };

  const handleDismissNotification = (id) => {
    setNotifications(prev => prev?.filter(n => n?.id !== id));
  };

  const handleCardSelect = (index) => {
    setCurrentCardIndex(index);
    setIsFlipped(false);
  };

  const handleSettingsSave = (newSettings) => {
    setSessionSettings(newSettings);
  };

  const currentCard = mockFlashcards?.[currentCardIndex];
  const updatedCard = {
    ...currentCard,
    isBookmarked: bookmarkedCards?.has(currentCard?.id)
  };

  const averageResponseTime = '12s';
  const progressPercentage = ((currentCardIndex + 1) / mockFlashcards?.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <StudySessionHeader
        currentCard={currentCardIndex + 1}
        totalCards={mockFlashcards?.length}
        sessionType="flashcards"
        onExit={handleExit}
        onPause={handlePause}
        onSettings={handleSettings}
        isPaused={isPaused}
        timeElapsed={timeElapsed}
        streakCount={streakCount}
      />
      {/* Main Content */}
      <div className="pt-16 lg:pt-20">
        <div className="flex">
          {/* Main Study Area */}
          <div className={`flex-1 ${showSidebar ? 'lg:mr-80' : ''} transition-all duration-300`}>
            <div className="container mx-auto px-4 py-6">
              <FlashcardDisplay
                card={updatedCard}
                isFlipped={isFlipped}
                onFlip={handleFlip}
                onDifficultySelect={handleDifficultySelect}
                onNext={handleNext}
                onPrevious={handlePrevious}
                onBookmark={handleBookmark}
                onAudioPlay={handleAudioPlay}
                currentLanguage={sessionSettings?.language}
              />
            </div>
          </div>

          {/* Desktop Sidebar */}
          <div className={`
            hidden lg:block fixed right-0 top-16 bottom-0 w-80 bg-card border-l border-border z-navigation
            transform transition-transform duration-300
            ${showSidebar ? 'translate-x-0' : 'translate-x-full'}
          `}>
            <div className="h-full overflow-y-auto p-4 space-y-4">
              {/* Toggle Button */}
              <div className="flex justify-end">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowSidebar(!showSidebar)}
                >
                  <Icon name={showSidebar ? 'ChevronRight' : 'ChevronLeft'} size={18} />
                </Button>
              </div>

              {/* Session Stats */}
              <SessionStats
                currentCard={currentCardIndex + 1}
                totalCards={mockFlashcards?.length}
                correctAnswers={correctAnswers}
                timeElapsed={timeElapsed}
                averageResponseTime={averageResponseTime}
                streakCount={streakCount}
                difficultyDistribution={difficultyDistribution}
              />

              {/* Upcoming Cards */}
              <UpcomingCards
                upcomingCards={mockFlashcards}
                onCardSelect={handleCardSelect}
                currentCardIndex={currentCardIndex}
              />
            </div>
          </div>
        </div>
      </div>
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden fixed bottom-4 left-4 z-notification">
        <Button
          variant="default"
          size="icon"
          onClick={() => setShowSidebar(!showSidebar)}
          className="w-12 h-12 rounded-full shadow-modal"
        >
          <Icon name="BarChart3" size={20} />
        </Button>
      </div>
      {/* Mobile Sidebar Overlay */}
      {showSidebar && (
        <div className="lg:hidden fixed inset-0 bg-black/50 z-modal" onClick={() => setShowSidebar(false)}>
          <div 
            className="fixed right-0 top-0 bottom-0 w-80 bg-card border-l border-border overflow-y-auto"
            onClick={(e) => e?.stopPropagation()}
          >
            <div className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-heading font-semibold text-card-foreground">
                  Session Overview
                </h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowSidebar(false)}
                >
                  <Icon name="X" size={18} />
                </Button>
              </div>

              <SessionStats
                currentCard={currentCardIndex + 1}
                totalCards={mockFlashcards?.length}
                correctAnswers={correctAnswers}
                timeElapsed={timeElapsed}
                averageResponseTime={averageResponseTime}
                streakCount={streakCount}
                difficultyDistribution={difficultyDistribution}
              />

              <UpcomingCards
                upcomingCards={mockFlashcards}
                onCardSelect={(index) => {
                  handleCardSelect(index);
                  setShowSidebar(false);
                }}
                currentCardIndex={currentCardIndex}
              />
            </div>
          </div>
        </div>
      )}
      {/* Break Reminder Modal */}
      <BreakReminder
        isVisible={showBreakReminder}
        onTakeBreak={() => setIsPaused(true)}
        onContinue={() => setShowBreakReminder(false)}
        onDismiss={() => setShowBreakReminder(false)}
        studyTime={sessionSettings?.breakInterval}
        breakDuration={5}
      />
      {/* Session Settings Modal */}
      <SessionSettings
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        onSave={handleSettingsSave}
        settings={sessionSettings}
      />
      {/* Progress Notifications */}
      <ProgressNotificationSystem
        notifications={notifications}
        onDismiss={handleDismissNotification}
        onViewDetails={(notification) => {
          if (notification?.onAction) {
            notification?.onAction(notification);
          }
        }}
        position="top-right"
      />
    </div>
  );
};

export default StudySessionFlashcards;