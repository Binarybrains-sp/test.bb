import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FlashcardDisplay = ({
  card,
  isFlipped = false,
  onFlip,
  onDifficultySelect,
  onNext,
  onPrevious,
  onBookmark,
  onAudioPlay,
  showControls = true,
  currentLanguage = 'en'
}) => {
  const [touchStart, setTouchStart] = useState(null);
  const [touchEnd, setTouchEnd] = useState(null);
  const [isAnimating, setIsAnimating] = useState(false);

  // Minimum swipe distance (in px)
  const minSwipeDistance = 50;

  const onTouchStart = (e) => {
    setTouchEnd(null);
    setTouchStart(e?.targetTouches?.[0]?.clientX);
  };

  const onTouchMove = (e) => {
    setTouchEnd(e?.targetTouches?.[0]?.clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      onNext?.();
    }
    if (isRightSwipe) {
      onPrevious?.();
    }
  };

  const handleFlip = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    onFlip?.();
    setTimeout(() => setIsAnimating(false), 300);
  };

  const handleDifficultySelect = (difficulty) => {
    onDifficultySelect?.(difficulty);
    setTimeout(() => onNext?.(), 1000);
  };

  const handleKeyPress = (e) => {
    if (e?.code === 'Space') {
      e?.preventDefault();
      handleFlip();
    } else if (e?.code === 'Digit1') {
      handleDifficultySelect('hard');
    } else if (e?.code === 'Digit2') {
      handleDifficultySelect('good');
    } else if (e?.code === 'Digit3') {
      handleDifficultySelect('easy');
    } else if (e?.code === 'ArrowLeft') {
      onPrevious?.();
    } else if (e?.code === 'ArrowRight') {
      onNext?.();
    }
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  if (!card) return null;

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
      {/* Flashcard Container */}
      <div 
        className="relative w-full max-w-2xl h-80 md:h-96 cursor-pointer"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        onClick={handleFlip}
      >
        {/* Card */}
        <div className={`
          study-card w-full h-full p-6 md:p-8 flex flex-col justify-center items-center text-center
          transform transition-all duration-300 ease-in-out
          ${isAnimating ? 'scale-105' : 'scale-100'}
          ${isFlipped ? 'bg-primary/5' : 'bg-card'}
        `}>
          {/* Card Type Indicator */}
          <div className="absolute top-4 left-4 flex items-center space-x-2">
            <div className={`
              w-3 h-3 rounded-full
              ${isFlipped ? 'bg-primary' : 'bg-muted-foreground'}
            `} />
            <span className="text-xs font-caption text-muted-foreground uppercase tracking-wide">
              {isFlipped ? 'Answer' : 'Question'}
            </span>
          </div>

          {/* Bookmark Button */}
          <button
            onClick={(e) => {
              e?.stopPropagation();
              onBookmark?.(card?.id);
            }}
            className="absolute top-4 right-4 p-2 rounded-lg hover:bg-muted/50 transition-colors"
          >
            <Icon 
              name={card?.isBookmarked ? 'Bookmark' : 'BookmarkPlus'} 
              size={18} 
              color={card?.isBookmarked ? 'var(--color-warning)' : 'var(--color-muted-foreground)'}
            />
          </button>

          {/* Card Content */}
          <div className="flex-1 flex flex-col justify-center">
            <div className="mb-4">
              {!isFlipped ? (
                <h2 className="text-xl md:text-2xl font-heading font-medium text-card-foreground leading-relaxed">
                  {card?.question}
                </h2>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-lg md:text-xl font-heading font-medium text-primary mb-3">
                    {card?.answer}
                  </h3>
                  {card?.explanation && (
                    <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                      {card?.explanation}
                    </p>
                  )}
                  {card?.examples && card?.examples?.length > 0 && (
                    <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                      <p className="text-xs font-caption text-muted-foreground mb-2 uppercase tracking-wide">
                        Examples
                      </p>
                      <ul className="text-sm text-card-foreground space-y-1">
                        {card?.examples?.map((example, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <span className="text-primary">•</span>
                            <span>{example}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Audio Button */}
            {card?.hasAudio && (
              <button
                onClick={(e) => {
                  e?.stopPropagation();
                  onAudioPlay?.(isFlipped ? card?.answer : card?.question);
                }}
                className="flex items-center justify-center space-x-2 mx-auto px-4 py-2 bg-muted/50 hover:bg-muted rounded-lg transition-colors"
              >
                <Icon name="Volume2" size={16} />
                <span className="text-sm font-caption">Play Audio</span>
              </button>
            )}
          </div>

          {/* Flip Instruction */}
          {!isFlipped && (
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
              <div className="flex items-center space-x-2 text-xs font-caption text-muted-foreground">
                <Icon name="MousePointer" size={14} />
                <span>Tap to reveal answer</span>
              </div>
            </div>
          )}
        </div>

        {/* Swipe Indicators */}
        <div className="absolute inset-y-0 left-0 w-8 flex items-center justify-center opacity-20">
          <Icon name="ChevronLeft" size={20} />
        </div>
        <div className="absolute inset-y-0 right-0 w-8 flex items-center justify-center opacity-20">
          <Icon name="ChevronRight" size={20} />
        </div>
      </div>
      {/* Difficulty Rating (shown when flipped) */}
      {isFlipped && showControls && (
        <div className="mt-6 w-full max-w-md">
          <p className="text-sm font-caption text-center text-muted-foreground mb-4">
            How well did you know this?
          </p>
          <div className="grid grid-cols-3 gap-3">
            <Button
              variant="outline"
              onClick={() => handleDifficultySelect('hard')}
              className="flex flex-col items-center py-3 text-destructive border-destructive/20 hover:bg-destructive/5"
            >
              <Icon name="X" size={18} className="mb-1" />
              <span className="text-xs">Hard</span>
              <span className="text-xs opacity-60">1</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleDifficultySelect('good')}
              className="flex flex-col items-center py-3 text-warning border-warning/20 hover:bg-warning/5"
            >
              <Icon name="Minus" size={18} className="mb-1" />
              <span className="text-xs">Good</span>
              <span className="text-xs opacity-60">2</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleDifficultySelect('easy')}
              className="flex flex-col items-center py-3 text-success border-success/20 hover:bg-success/5"
            >
              <Icon name="Check" size={18} className="mb-1" />
              <span className="text-xs">Easy</span>
              <span className="text-xs opacity-60">3</span>
            </Button>
          </div>
        </div>
      )}
      {/* Navigation Controls */}
      {!isFlipped && showControls && (
        <div className="mt-6 flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onPrevious}
            className="w-12 h-12"
          >
            <Icon name="ChevronLeft" size={20} />
          </Button>
          
          <Button
            variant="default"
            onClick={handleFlip}
            iconName="RotateCcw"
            iconPosition="left"
            className="px-6"
          >
            Show Answer
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={onNext}
            className="w-12 h-12"
          >
            <Icon name="ChevronRight" size={20} />
          </Button>
        </div>
      )}
      {/* Desktop Keyboard Shortcuts */}
      <div className="hidden lg:block mt-4 text-xs font-caption text-muted-foreground text-center">
        <div className="flex items-center justify-center space-x-6">
          <span>Space: Flip card</span>
          <span>←→: Navigate</span>
          <span>1-3: Rate difficulty</span>
        </div>
      </div>
    </div>
  );
};

export default FlashcardDisplay;