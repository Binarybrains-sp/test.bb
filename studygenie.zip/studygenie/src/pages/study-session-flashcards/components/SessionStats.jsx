import React from 'react';
import Icon from '../../../components/AppIcon';

const SessionStats = ({
  currentCard = 1,
  totalCards = 20,
  correctAnswers = 0,
  timeElapsed = '05:23',
  averageResponseTime = '12s',
  streakCount = 7,
  difficultyDistribution = { easy: 5, good: 8, hard: 2 },
  isVisible = true
}) => {
  const progressPercentage = (currentCard / totalCards) * 100;
  const accuracy = totalCards > 0 ? Math.round((correctAnswers / (currentCard - 1)) * 100) || 0 : 0;

  if (!isVisible) return null;

  return (
    <div className="bg-card border border-border rounded-lg p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-heading font-semibold text-card-foreground">
          Session Overview
        </h3>
        <div className="flex items-center space-x-1">
          <Icon name="Flame" size={16} color="var(--color-warning)" />
          <span className="text-sm font-data text-warning">{streakCount}</span>
        </div>
      </div>
      {/* Progress Section */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm font-caption">
          <span className="text-muted-foreground">Progress</span>
          <span className="font-data text-card-foreground">
            {currentCard}/{totalCards} ({Math.round(progressPercentage)}%)
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="progress-indicator h-2 rounded-full"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>
      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center">
          <div className="text-xl font-data font-bold text-primary">
            {timeElapsed}
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Time Elapsed
          </div>
        </div>
        <div className="text-center">
          <div className="text-xl font-data font-bold text-success">
            {accuracy}%
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Accuracy
          </div>
        </div>
        <div className="text-center">
          <div className="text-xl font-data font-bold text-warning">
            {averageResponseTime}
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Avg Response
          </div>
        </div>
        <div className="text-center">
          <div className="text-xl font-data font-bold text-card-foreground">
            {correctAnswers}
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Correct
          </div>
        </div>
      </div>
      {/* Difficulty Distribution */}
      <div className="space-y-2">
        <h4 className="text-sm font-heading font-medium text-card-foreground">
          Difficulty Breakdown
        </h4>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-success rounded-full" />
              <span className="text-sm font-caption text-muted-foreground">Easy</span>
            </div>
            <span className="text-sm font-data text-card-foreground">
              {difficultyDistribution?.easy}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-warning rounded-full" />
              <span className="text-sm font-caption text-muted-foreground">Good</span>
            </div>
            <span className="text-sm font-data text-card-foreground">
              {difficultyDistribution?.good}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-destructive rounded-full" />
              <span className="text-sm font-caption text-muted-foreground">Hard</span>
            </div>
            <span className="text-sm font-data text-card-foreground">
              {difficultyDistribution?.hard}
            </span>
          </div>
        </div>
      </div>
      {/* Quick Actions */}
      <div className="pt-2 border-t border-border">
        <div className="grid grid-cols-2 gap-2 text-xs font-caption">
          <div className="flex items-center space-x-2 text-muted-foreground">
            <Icon name="Clock" size={12} />
            <span>Break in {Math.max(0, 25 - Math.floor(parseInt(timeElapsed?.split(':')?.[0])))} min</span>
          </div>
          <div className="flex items-center space-x-2 text-muted-foreground">
            <Icon name="Target" size={12} />
            <span>{totalCards - currentCard + 1} remaining</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SessionStats;