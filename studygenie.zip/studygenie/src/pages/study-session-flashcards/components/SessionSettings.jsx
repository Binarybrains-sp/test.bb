import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const SessionSettings = ({
  isOpen = false,
  onClose,
  onSave,
  settings = {
    autoAdvance: false,
    showTimer: true,
    audioEnabled: true,
    language: 'en',
    cardOrder: 'sequential',
    breakReminders: true,
    breakInterval: 25,
    showProgress: true,
    keyboardShortcuts: true
  }
}) => {
  const [localSettings, setLocalSettings] = useState(settings);

  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'hi', label: 'हिंदी (Hindi)' },
    { value: 'mr', label: 'मराठी (Marathi)' },
    { value: 'ta', label: 'தமிழ் (Tamil)' },
    { value: 'te', label: 'తెలుగు (Telugu)' }
  ];

  const cardOrderOptions = [
    { value: 'sequential', label: 'Sequential Order' },
    { value: 'random', label: 'Random Order' },
    { value: 'difficulty', label: 'By Difficulty' },
    { value: 'spaced', label: 'Spaced Repetition' }
  ];

  const breakIntervalOptions = [
    { value: 15, label: '15 minutes' },
    { value: 20, label: '20 minutes' },
    { value: 25, label: '25 minutes (Pomodoro)' },
    { value: 30, label: '30 minutes' },
    { value: 45, label: '45 minutes' },
    { value: 60, label: '1 hour' }
  ];

  const handleSettingChange = (key, value) => {
    setLocalSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSave = () => {
    onSave?.(localSettings);
    onClose?.();
  };

  const handleReset = () => {
    setLocalSettings({
      autoAdvance: false,
      showTimer: true,
      audioEnabled: true,
      language: 'en',
      cardOrder: 'sequential',
      breakReminders: true,
      breakInterval: 25,
      showProgress: true,
      keyboardShortcuts: true
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-modal flex items-center justify-center p-4">
      <div className="bg-card rounded-lg shadow-modal max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-heading font-semibold text-card-foreground">
              Session Settings
            </h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
            >
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        {/* Settings Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh] space-y-6">
          {/* Display Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-heading font-medium text-card-foreground">
              Display
            </h3>
            
            <div className="space-y-3">
              <Checkbox
                label="Show timer during session"
                description="Display elapsed time and remaining cards"
                checked={localSettings?.showTimer}
                onChange={(e) => handleSettingChange('showTimer', e?.target?.checked)}
              />
              
              <Checkbox
                label="Show progress bar"
                description="Visual progress indicator at the top"
                checked={localSettings?.showProgress}
                onChange={(e) => handleSettingChange('showProgress', e?.target?.checked)}
              />
            </div>
          </div>

          {/* Language Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-heading font-medium text-card-foreground">
              Language
            </h3>
            
            <Select
              label="Content Language"
              description="Language for flashcard content and interface"
              options={languageOptions}
              value={localSettings?.language}
              onChange={(value) => handleSettingChange('language', value)}
            />
            
            <Checkbox
              label="Enable audio pronunciation"
              description="Text-to-speech for flashcard content"
              checked={localSettings?.audioEnabled}
              onChange={(e) => handleSettingChange('audioEnabled', e?.target?.checked)}
            />
          </div>

          {/* Study Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-heading font-medium text-card-foreground">
              Study Flow
            </h3>
            
            <Select
              label="Card Order"
              description="How cards are presented during study"
              options={cardOrderOptions}
              value={localSettings?.cardOrder}
              onChange={(value) => handleSettingChange('cardOrder', value)}
            />
            
            <Checkbox
              label="Auto-advance after rating"
              description="Automatically move to next card after difficulty rating"
              checked={localSettings?.autoAdvance}
              onChange={(e) => handleSettingChange('autoAdvance', e?.target?.checked)}
            />
            
            <Checkbox
              label="Enable keyboard shortcuts"
              description="Use keyboard for navigation and rating"
              checked={localSettings?.keyboardShortcuts}
              onChange={(e) => handleSettingChange('keyboardShortcuts', e?.target?.checked)}
            />
          </div>

          {/* Break Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-heading font-medium text-card-foreground">
              Break Reminders
            </h3>
            
            <Checkbox
              label="Enable break reminders"
              description="Get notified to take regular breaks"
              checked={localSettings?.breakReminders}
              onChange={(e) => handleSettingChange('breakReminders', e?.target?.checked)}
            />
            
            {localSettings?.breakReminders && (
              <Select
                label="Break Interval"
                description="How often to suggest breaks"
                options={breakIntervalOptions}
                value={localSettings?.breakInterval}
                onChange={(value) => handleSettingChange('breakInterval', value)}
              />
            )}
          </div>

          {/* Keyboard Shortcuts Info */}
          {localSettings?.keyboardShortcuts && (
            <div className="bg-muted/30 rounded-lg p-4">
              <h4 className="text-sm font-heading font-medium text-card-foreground mb-2">
                Keyboard Shortcuts
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs font-caption text-muted-foreground">
                <div>Space: Flip card</div>
                <div>←→: Navigate</div>
                <div>1: Hard</div>
                <div>2: Good</div>
                <div>3: Easy</div>
                <div>B: Bookmark</div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t border-border">
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={handleReset}
              iconName="RotateCcw"
              iconPosition="left"
            >
              Reset
            </Button>
            <Button
              variant="default"
              fullWidth
              onClick={handleSave}
              iconName="Check"
              iconPosition="left"
            >
              Save Settings
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SessionSettings;