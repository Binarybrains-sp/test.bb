import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BreakReminder = ({
  isVisible = false,
  onTakeBreak,
  onContinue,
  onDismiss,
  studyTime = 25,
  breakDuration = 5
}) => {
  const [countdown, setCountdown] = useState(breakDuration * 60);
  const [isBreakActive, setIsBreakActive] = useState(false);

  useEffect(() => {
    let interval;
    if (isBreakActive && countdown > 0) {
      interval = setInterval(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
    } else if (countdown === 0 && isBreakActive) {
      setIsBreakActive(false);
      setCountdown(breakDuration * 60);
    }
    return () => clearInterval(interval);
  }, [isBreakActive, countdown, breakDuration]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const handleTakeBreak = () => {
    setIsBreakActive(true);
    onTakeBreak?.();
  };

  const handleSkipBreak = () => {
    onContinue?.();
    onDismiss?.();
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-modal flex items-center justify-center p-4">
      <div className="bg-card rounded-lg shadow-modal max-w-md w-full p-6 text-center">
        {!isBreakActive ? (
          <>
            {/* Break Suggestion */}
            <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="Coffee" size={32} color="var(--color-warning)" />
            </div>
            
            <h2 className="text-xl font-heading font-semibold text-card-foreground mb-2">
              Time for a Break!
            </h2>
            
            <p className="text-muted-foreground mb-6">
              You've been studying for {studyTime} minutes. Taking short breaks helps improve focus and retention.
            </p>

            {/* Break Benefits */}
            <div className="bg-muted/30 rounded-lg p-4 mb-6 text-left">
              <h3 className="text-sm font-heading font-medium text-card-foreground mb-2">
                Break Benefits:
              </h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li className="flex items-center space-x-2">
                  <Icon name="Brain" size={14} />
                  <span>Improves memory consolidation</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Eye" size={14} />
                  <span>Reduces eye strain</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Zap" size={14} />
                  <span>Restores mental energy</span>
                </li>
              </ul>
            </div>

            {/* Actions */}
            <div className="flex space-x-3">
              <Button
                variant="outline"
                fullWidth
                onClick={handleSkipBreak}
              >
                Continue Studying
              </Button>
              <Button
                variant="default"
                fullWidth
                onClick={handleTakeBreak}
                iconName="Play"
                iconPosition="left"
              >
                Take {breakDuration} Min Break
              </Button>
            </div>
          </>
        ) : (
          <>
            {/* Break Timer */}
            <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-data font-bold text-success">
                {formatTime(countdown)}
              </span>
            </div>
            
            <h2 className="text-xl font-heading font-semibold text-card-foreground mb-2">
              Break Time
            </h2>
            
            <p className="text-muted-foreground mb-6">
              Relax and recharge. Your study session will resume automatically when the timer ends.
            </p>

            {/* Break Activities */}
            <div className="bg-muted/30 rounded-lg p-4 mb-6">
              <h3 className="text-sm font-heading font-medium text-card-foreground mb-3">
                Suggested Activities:
              </h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="Droplets" size={14} />
                  <span>Drink water</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="Move" size={14} />
                  <span>Stretch</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="Wind" size={14} />
                  <span>Deep breathing</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="Sun" size={14} />
                  <span>Look outside</span>
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-muted rounded-full h-2 mb-4">
              <div 
                className="bg-success h-2 rounded-full transition-all duration-1000"
                style={{ 
                  width: `${((breakDuration * 60 - countdown) / (breakDuration * 60)) * 100}%` 
                }}
              />
            </div>

            {/* Early Return Option */}
            <Button
              variant="ghost"
              onClick={() => {
                setIsBreakActive(false);
                setCountdown(breakDuration * 60);
                onContinue?.();
                onDismiss?.();
              }}
              className="text-sm"
            >
              I'm ready to continue
            </Button>
          </>
        )}
      </div>
    </div>
  );
};

export default BreakReminder;