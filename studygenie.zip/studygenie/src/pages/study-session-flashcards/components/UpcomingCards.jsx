import React from 'react';
import Icon from '../../../components/AppIcon';

const UpcomingCards = ({
  upcomingCards = [],
  onCardSelect,
  currentCardIndex = 0,
  isVisible = true
}) => {
  if (!isVisible || upcomingCards?.length === 0) return null;

  const visibleCards = upcomingCards?.slice(currentCardIndex + 1, currentCardIndex + 6);

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-heading font-semibold text-card-foreground">
          Coming Up
        </h3>
        <span className="text-xs font-caption text-muted-foreground">
          Next {visibleCards?.length} cards
        </span>
      </div>
      <div className="space-y-2">
        {visibleCards?.map((card, index) => (
          <div
            key={card?.id}
            onClick={() => onCardSelect?.(currentCardIndex + index + 1)}
            className="p-3 bg-muted/30 hover:bg-muted/50 rounded-lg cursor-pointer transition-colors group"
          >
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
                <span className="text-xs font-data text-primary">
                  {currentCardIndex + index + 2}
                </span>
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-card-foreground line-clamp-2 group-hover:text-primary transition-colors">
                  {card?.question}
                </p>
                
                <div className="flex items-center space-x-3 mt-2">
                  {/* Difficulty Indicator */}
                  <div className="flex items-center space-x-1">
                    <div className={`
                      w-2 h-2 rounded-full
                      ${card?.difficulty === 'easy' ? 'bg-success' : 
                        card?.difficulty === 'medium' ? 'bg-warning' : 'bg-destructive'}
                    `} />
                    <span className="text-xs font-caption text-muted-foreground capitalize">
                      {card?.difficulty || 'new'}
                    </span>
                  </div>
                  
                  {/* Subject Tag */}
                  {card?.subject && (
                    <span className="text-xs font-caption text-muted-foreground bg-muted/50 px-2 py-1 rounded">
                      {card?.subject}
                    </span>
                  )}
                  
                  {/* Bookmark Indicator */}
                  {card?.isBookmarked && (
                    <Icon name="Bookmark" size={12} color="var(--color-warning)" />
                  )}
                </div>
              </div>
              
              <div className="flex-shrink-0">
                <Icon 
                  name="ChevronRight" 
                  size={16} 
                  className="text-muted-foreground group-hover:text-primary transition-colors" 
                />
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Load More Indicator */}
      {upcomingCards?.length > currentCardIndex + 6 && (
        <div className="mt-3 text-center">
          <span className="text-xs font-caption text-muted-foreground">
            +{upcomingCards?.length - currentCardIndex - 6} more cards
          </span>
        </div>
      )}
      {/* Quick Stats */}
      <div className="mt-4 pt-3 border-t border-border">
        <div className="grid grid-cols-3 gap-2 text-center text-xs font-caption">
          <div>
            <div className="text-success font-medium">
              {visibleCards?.filter(c => c?.difficulty === 'easy')?.length}
            </div>
            <div className="text-muted-foreground">Easy</div>
          </div>
          <div>
            <div className="text-warning font-medium">
              {visibleCards?.filter(c => c?.difficulty === 'medium')?.length}
            </div>
            <div className="text-muted-foreground">Medium</div>
          </div>
          <div>
            <div className="text-destructive font-medium">
              {visibleCards?.filter(c => c?.difficulty === 'hard')?.length}
            </div>
            <div className="text-muted-foreground">Hard</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpcomingCards;