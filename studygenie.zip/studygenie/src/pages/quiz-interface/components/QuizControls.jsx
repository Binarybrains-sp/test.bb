import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuizControls = ({
  currentQuestion = 1,
  totalQuestions = 20,
  onPrevious,
  onNext,
  onSubmit,
  onPause,
  onBookmark,
  onReview,
  isPaused = false,
  isBookmarked = false,
  canGoNext = true,
  canGoPrevious = true,
  showSubmit = false,
  answeredQuestions = [],
  flaggedQuestions = []
}) => {
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);

  const handleSubmitClick = () => {
    const unansweredCount = totalQuestions - answeredQuestions?.length;
    if (unansweredCount > 0) {
      setShowSubmitConfirm(true);
    } else {
      onSubmit?.();
    }
  };

  const handleConfirmSubmit = () => {
    setShowSubmitConfirm(false);
    onSubmit?.();
  };

  const unansweredCount = totalQuestions - answeredQuestions?.length;
  const isLastQuestion = currentQuestion === totalQuestions;

  return (
    <>
      {/* Main Controls */}
      <div className="bg-card border-t border-border p-4">
        <div className="flex items-center justify-between">
          {/* Left Controls */}
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={onPrevious}
              disabled={!canGoPrevious}
              iconName="ChevronLeft"
              iconPosition="left"
              className="hidden sm:flex"
            >
              Previous
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={onPrevious}
              disabled={!canGoPrevious}
              className="sm:hidden"
            >
              <Icon name="ChevronLeft" size={20} />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => onBookmark(currentQuestion)}
              className={isBookmarked ? 'text-warning' : 'text-muted-foreground'}
            >
              <Icon name={isBookmarked ? 'Bookmark' : 'BookmarkPlus'} size={20} />
            </Button>
          </div>

          {/* Center - Question Counter */}
          <div className="flex items-center space-x-2">
            <span className="text-sm font-data text-muted-foreground">
              {currentQuestion} / {totalQuestions}
            </span>
            <div className="w-2 h-2 rounded-full bg-primary"></div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onPause}
              className="hidden sm:flex"
            >
              <Icon name={isPaused ? 'Play' : 'Pause'} size={20} />
            </Button>

            {showSubmit || isLastQuestion ? (
              <Button
                variant="default"
                onClick={handleSubmitClick}
                iconName="Send"
                iconPosition="right"
                className="hidden sm:flex"
              >
                Submit Quiz
              </Button>
            ) : (
              <Button
                variant="default"
                onClick={onNext}
                disabled={!canGoNext}
                iconName="ChevronRight"
                iconPosition="right"
                className="hidden sm:flex"
              >
                Next
              </Button>
            )}

            {/* Mobile Next/Submit */}
            <Button
              variant="default"
              size="icon"
              onClick={showSubmit || isLastQuestion ? handleSubmitClick : onNext}
              disabled={!canGoNext && !(showSubmit || isLastQuestion)}
              className="sm:hidden"
            >
              <Icon name={showSubmit || isLastQuestion ? 'Send' : 'ChevronRight'} size={20} />
            </Button>
          </div>
        </div>

        {/* Mobile Bottom Row */}
        <div className="sm:hidden mt-3 flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={onReview}
            iconName="Grid3x3"
            iconPosition="left"
          >
            Review
          </Button>

          <div className="flex items-center space-x-2 text-xs font-caption text-muted-foreground">
            <span>{answeredQuestions?.length} answered</span>
            {flaggedQuestions?.length > 0 && (
              <>
                <div className="w-1 h-1 rounded-full bg-muted-foreground"></div>
                <span>{flaggedQuestions?.length} flagged</span>
              </>
            )}
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={onPause}
            iconName={isPaused ? 'Play' : 'Pause'}
            iconPosition="left"
          >
            {isPaused ? 'Resume' : 'Pause'}
          </Button>
        </div>
      </div>
      {/* Submit Confirmation Modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 bg-black/50 z-modal flex items-center justify-center p-4">
          <div className="bg-card rounded-lg shadow-modal max-w-md w-full p-6">
            <div className="flex items-start space-x-3 mb-4">
              <div className="w-10 h-10 bg-warning/10 rounded-full flex items-center justify-center flex-shrink-0">
                <Icon name="AlertTriangle" size={20} className="text-warning" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-heading font-semibold text-card-foreground mb-2">
                  Submit Quiz?
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  You have {unansweredCount} unanswered question{unansweredCount > 1 ? 's' : ''}. 
                  Are you sure you want to submit your quiz?
                </p>
                
                {flaggedQuestions?.length > 0 && (
                  <div className="bg-warning/10 rounded-lg p-3 mb-4">
                    <div className="flex items-center space-x-2 mb-1">
                      <Icon name="Flag" size={16} className="text-warning" />
                      <span className="text-sm font-medium text-warning">
                        Flagged Questions
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      You have {flaggedQuestions?.length} question{flaggedQuestions?.length > 1 ? 's' : ''} flagged for review.
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex space-x-3">
              <Button
                variant="outline"
                fullWidth
                onClick={() => setShowSubmitConfirm(false)}
              >
                Continue Quiz
              </Button>
              <Button
                variant="default"
                fullWidth
                onClick={handleConfirmSubmit}
                iconName="Send"
                iconPosition="right"
              >
                Submit Now
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default QuizControls;