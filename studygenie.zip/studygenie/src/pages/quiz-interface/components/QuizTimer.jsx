import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const QuizTimer = ({
  totalTime = 3600, // 60 minutes in seconds
  onTimeUp,
  isPaused = false,
  showWarnings = true,
  warningThresholds = [300, 600, 900] // 5, 10, 15 minutes in seconds
}) => {
  const [timeRemaining, setTimeRemaining] = useState(totalTime);
  const [warningsShown, setWarningsShown] = useState(new Set());

  useEffect(() => {
    if (isPaused || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        const newTime = prev - 1;
        
        // Check for warnings
        if (showWarnings) {
          warningThresholds?.forEach(threshold => {
            if (newTime === threshold && !warningsShown?.has(threshold)) {
              setWarningsShown(prev => new Set([...prev, threshold]));
              // You can add notification logic here
            }
          });
        }
        
        // Time up
        if (newTime <= 0) {
          onTimeUp?.();
          return 0;
        }
        
        return newTime;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isPaused, timeRemaining, onTimeUp, showWarnings, warningThresholds, warningsShown]);

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${secs?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const getTimeColor = () => {
    const percentage = (timeRemaining / totalTime) * 100;
    if (percentage <= 5) return 'text-error';
    if (percentage <= 15) return 'text-warning';
    if (percentage <= 25) return 'text-warning';
    return 'text-foreground';
  };

  const getProgressColor = () => {
    const percentage = (timeRemaining / totalTime) * 100;
    if (percentage <= 5) return 'bg-error';
    if (percentage <= 15) return 'bg-warning';
    if (percentage <= 25) return 'bg-warning';
    return 'bg-primary';
  };

  const progressPercentage = (timeRemaining / totalTime) * 100;
  const isLowTime = timeRemaining <= 300; // 5 minutes
  const isCriticalTime = timeRemaining <= 60; // 1 minute

  return (
    <div className="flex items-center space-x-3">
      {/* Timer Icon */}
      <div className={`${getTimeColor()} ${isCriticalTime ? 'animate-pulse' : ''}`}>
        <Icon 
          name={isPaused ? 'PauseCircle' : 'Clock'} 
          size={20} 
        />
      </div>

      {/* Time Display */}
      <div className="flex flex-col">
        <div className={`font-data font-medium ${getTimeColor()} ${isCriticalTime ? 'animate-pulse' : ''}`}>
          {formatTime(timeRemaining)}
        </div>
        
        {/* Progress Bar - Mobile */}
        <div className="lg:hidden w-16 bg-muted rounded-full h-1 mt-1">
          <div 
            className={`h-1 rounded-full transition-all duration-1000 ${getProgressColor()}`}
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>

      {/* Progress Bar - Desktop */}
      <div className="hidden lg:block w-24 bg-muted rounded-full h-2">
        <div 
          className={`h-2 rounded-full transition-all duration-1000 ${getProgressColor()}`}
          style={{ width: `${progressPercentage}%` }}
        />
      </div>

      {/* Status Indicators */}
      <div className="flex items-center space-x-1">
        {isPaused && (
          <div className="w-2 h-2 rounded-full bg-warning animate-pulse"></div>
        )}
        {isLowTime && !isCriticalTime && (
          <div className="w-2 h-2 rounded-full bg-warning"></div>
        )}
        {isCriticalTime && (
          <div className="w-2 h-2 rounded-full bg-error animate-pulse"></div>
        )}
      </div>

      {/* Time Status Text - Desktop Only */}
      <div className="hidden xl:block text-xs font-caption text-muted-foreground">
        {isCriticalTime ? 'Critical Time!' : isLowTime ?'Low Time': isPaused ?'Paused' : 'Time Remaining'}
      </div>
    </div>
  );
};

export default QuizTimer;