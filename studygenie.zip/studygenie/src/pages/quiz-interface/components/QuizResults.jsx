import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuizResults = ({
  score = 0,
  totalQuestions = 20,
  correctAnswers = 0,
  timeSpent = '45:30',
  subjectBreakdown = [],
  wrongAnswers = [],
  onReviewAnswers,
  onRetakeQuiz,
  onBackToDashboard,
  onShareResults,
  performanceLevel = 'good'
}) => {
  const [showDetailedResults, setShowDetailedResults] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState(null);

  const percentage = Math.round((correctAnswers / totalQuestions) * 100);
  const incorrectAnswers = totalQuestions - correctAnswers;
  
  const getPerformanceColor = () => {
    if (percentage >= 90) return 'text-success';
    if (percentage >= 70) return 'text-primary';
    if (percentage >= 50) return 'text-warning';
    return 'text-error';
  };

  const getPerformanceIcon = () => {
    if (percentage >= 90) return 'Trophy';
    if (percentage >= 70) return 'Target';
    if (percentage >= 50) return 'TrendingUp';
    return 'TrendingDown';
  };

  const getPerformanceMessage = () => {
    if (percentage >= 90) return 'Excellent work! Outstanding performance!';
    if (percentage >= 70) return 'Great job! You did really well!';
    if (percentage >= 50) return 'Good effort! Keep practicing to improve!';
    return 'Keep studying! You can do better next time!';
  };

  const getGradeLevel = () => {
    if (percentage >= 90) return 'A+';
    if (percentage >= 80) return 'A';
    if (percentage >= 70) return 'B';
    if (percentage >= 60) return 'C';
    if (percentage >= 50) return 'D';
    return 'F';
  };

  return (
    <div className="min-h-screen bg-background pt-16">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Results Header */}
        <div className="text-center mb-8">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
            percentage >= 70 ? 'bg-success/10' : percentage >= 50 ? 'bg-warning/10' : 'bg-error/10'
          }`}>
            <Icon 
              name={getPerformanceIcon()} 
              size={40} 
              className={getPerformanceColor()}
            />
          </div>
          
          <h1 className="text-3xl font-heading font-bold text-foreground mb-2">
            Quiz Completed!
          </h1>
          <p className="text-lg text-muted-foreground">
            {getPerformanceMessage()}
          </p>
        </div>

        {/* Score Card */}
        <div className="bg-card rounded-lg border border-border p-6 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="space-y-2">
              <div className={`text-4xl font-data font-bold ${getPerformanceColor()}`}>
                {percentage}%
              </div>
              <div className="text-sm font-caption text-muted-foreground">
                Overall Score
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-4xl font-data font-bold text-success">
                {correctAnswers}
              </div>
              <div className="text-sm font-caption text-muted-foreground">
                Correct Answers
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-4xl font-data font-bold text-error">
                {incorrectAnswers}
              </div>
              <div className="text-sm font-caption text-muted-foreground">
                Incorrect Answers
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-4xl font-data font-bold text-primary">
                {getGradeLevel()}
              </div>
              <div className="text-sm font-caption text-muted-foreground">
                Grade Level
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-border">
            <div className="flex items-center justify-center space-x-6 text-sm font-caption text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Icon name="Clock" size={16} />
                <span>Time: {timeSpent}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="FileText" size={16} />
                <span>Questions: {totalQuestions}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Target" size={16} />
                <span>Accuracy: {percentage}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Subject Breakdown */}
        {subjectBreakdown?.length > 0 && (
          <div className="bg-card rounded-lg border border-border p-6">
            <h3 className="text-lg font-heading font-semibold text-card-foreground mb-4">
              Subject-wise Performance
            </h3>
            
            <div className="space-y-4">
              {subjectBreakdown?.map((subject, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">
                      {subject?.name}
                    </span>
                    <span className="text-sm font-data text-muted-foreground">
                      {subject?.correct}/{subject?.total} ({Math.round((subject?.correct/subject?.total)*100)}%)
                    </span>
                  </div>
                  
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-500 ${
                        (subject?.correct/subject?.total) >= 0.7 ? 'bg-success' :
                        (subject?.correct/subject?.total) >= 0.5 ? 'bg-warning' : 'bg-error'
                      }`}
                      style={{ width: `${(subject?.correct/subject?.total)*100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Wrong Answers Preview */}
        {wrongAnswers?.length > 0 && (
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-heading font-semibold text-card-foreground">
                Questions to Review
              </h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDetailedResults(!showDetailedResults)}
                iconName={showDetailedResults ? 'ChevronUp' : 'ChevronDown'}
                iconPosition="right"
              >
                {showDetailedResults ? 'Hide' : 'Show'} Details
              </Button>
            </div>

            {!showDetailedResults ? (
              <div className="space-y-3">
                {wrongAnswers?.slice(0, 3)?.map((question, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 bg-error/5 rounded-lg border border-error/20">
                    <div className="w-6 h-6 bg-error/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-data text-error">
                        {question?.questionNumber}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {question?.question}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Your answer: {question?.userAnswer} • Correct: {question?.correctAnswer}
                      </p>
                    </div>
                  </div>
                ))}
                
                {wrongAnswers?.length > 3 && (
                  <p className="text-sm text-muted-foreground text-center">
                    And {wrongAnswers?.length - 3} more question{wrongAnswers?.length - 3 > 1 ? 's' : ''}...
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {wrongAnswers?.map((question, index) => (
                  <div key={index} className="p-4 bg-error/5 rounded-lg border border-error/20">
                    <div className="flex items-start space-x-3 mb-3">
                      <div className="w-8 h-8 bg-error/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-data text-error">
                          {question?.questionNumber}
                        </span>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground mb-2">
                          {question?.question}
                        </p>
                        
                        <div className="space-y-2 text-xs">
                          <div className="flex items-center space-x-2">
                            <Icon name="X" size={14} className="text-error" />
                            <span className="text-muted-foreground">Your answer:</span>
                            <span className="text-error font-medium">{question?.userAnswer}</span>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Icon name="Check" size={14} className="text-success" />
                            <span className="text-muted-foreground">Correct answer:</span>
                            <span className="text-success font-medium">{question?.correctAnswer}</span>
                          </div>
                        </div>
                        
                        {question?.explanation && (
                          <div className="mt-3 p-3 bg-muted/50 rounded-lg">
                            <div className="flex items-start space-x-2">
                              <Icon name="Lightbulb" size={14} className="text-warning mt-0.5" />
                              <div>
                                <p className="text-xs font-medium text-foreground mb-1">Explanation:</p>
                                <p className="text-xs text-muted-foreground leading-relaxed">
                                  {question?.explanation}
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button
            variant="default"
            fullWidth
            onClick={onReviewAnswers}
            iconName="Eye"
            iconPosition="left"
          >
            Review Answers
          </Button>
          
          <Button
            variant="outline"
            fullWidth
            onClick={onRetakeQuiz}
            iconName="RotateCcw"
            iconPosition="left"
          >
            Retake Quiz
          </Button>
          
          <Button
            variant="secondary"
            fullWidth
            onClick={onShareResults}
            iconName="Share"
            iconPosition="left"
          >
            Share Results
          </Button>
          
          <Button
            variant="ghost"
            fullWidth
            onClick={onBackToDashboard}
            iconName="Home"
            iconPosition="left"
          >
            Back to Dashboard
          </Button>
        </div>

        {/* Achievement Celebration */}
        {percentage >= 90 && (
          <div className="bg-gradient-to-r from-warning/10 to-success/10 rounded-lg border border-warning/20 p-6 text-center">
            <div className="w-16 h-16 bg-warning/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="Trophy" size={32} className="text-warning" />
            </div>
            <h3 className="text-xl font-heading font-bold text-foreground mb-2">
              Outstanding Performance!
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              You've achieved an excellent score! Keep up the great work!
            </p>
            <div className="flex items-center justify-center space-x-4 text-sm font-caption">
              <div className="flex items-center space-x-1">
                <Icon name="Plus" size={14} className="text-primary" />
                <span className="text-primary font-medium">+50 XP</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Star" size={14} className="text-warning" />
                <span className="text-warning font-medium">Achievement Unlocked</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizResults;