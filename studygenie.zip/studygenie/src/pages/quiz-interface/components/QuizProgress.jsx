import React from 'react';
import Icon from '../../../components/AppIcon';

const QuizProgress = ({
  currentQuestion = 1,
  totalQuestions = 20,
  answeredQuestions = [],
  flaggedQuestions = [],
  correctAnswers = 0,
  showDetailedStats = false,
  onQuestionJump
}) => {
  const progressPercentage = (currentQuestion / totalQuestions) * 100;
  const answeredCount = answeredQuestions?.length;
  const flaggedCount = flaggedQuestions?.length;
  const unansweredCount = totalQuestions - answeredCount;
  const accuracyPercentage = answeredCount > 0 ? Math.round((correctAnswers / answeredCount) * 100) : 0;

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      {/* Main Progress Bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-heading font-medium text-foreground">
            Question {currentQuestion} of {totalQuestions}
          </span>
          <span className="text-sm font-data text-muted-foreground">
            {Math.round(progressPercentage)}% Complete
          </span>
        </div>
        
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="progress-indicator h-2 rounded-full transition-all duration-300"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>
      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4 text-center">
        <div className="space-y-1">
          <div className="text-lg font-data font-bold text-success">
            {answeredCount}
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Answered
          </div>
        </div>
        
        <div className="space-y-1">
          <div className="text-lg font-data font-bold text-warning">
            {flaggedCount}
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Flagged
          </div>
        </div>
        
        <div className="space-y-1">
          <div className="text-lg font-data font-bold text-muted-foreground">
            {unansweredCount}
          </div>
          <div className="text-xs font-caption text-muted-foreground">
            Remaining
          </div>
        </div>
      </div>
      {/* Detailed Stats */}
      {showDetailedStats && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="space-y-1">
              <div className="flex items-center justify-center space-x-1">
                <Icon name="Target" size={16} className="text-primary" />
                <span className="text-sm font-data font-bold text-primary">
                  {accuracyPercentage}%
                </span>
              </div>
              <div className="text-xs font-caption text-muted-foreground">
                Accuracy
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="flex items-center justify-center space-x-1">
                <Icon name="CheckCircle" size={16} className="text-success" />
                <span className="text-sm font-data font-bold text-success">
                  {correctAnswers}
                </span>
              </div>
              <div className="text-xs font-caption text-muted-foreground">
                Correct
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Question Navigation Dots - Mobile */}
      {totalQuestions <= 20 && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="grid grid-cols-10 gap-1">
            {Array.from({ length: totalQuestions }, (_, index) => {
              const questionNum = index + 1;
              const isAnswered = answeredQuestions?.includes(questionNum);
              const isFlagged = flaggedQuestions?.includes(questionNum);
              const isCurrent = questionNum === currentQuestion;
              
              return (
                <button
                  key={questionNum}
                  onClick={() => onQuestionJump?.(questionNum)}
                  className={`
                    w-6 h-6 rounded text-xs font-data transition-all duration-200
                    ${isCurrent 
                      ? 'bg-primary text-primary-foreground scale-110' 
                      : isAnswered 
                        ? 'bg-success text-success-foreground hover:scale-105' 
                        : isFlagged 
                          ? 'bg-warning text-warning-foreground hover:scale-105'
                          : 'bg-muted text-muted-foreground hover:bg-muted/80 hover:scale-105'
                    }
                  `}
                  title={`Question ${questionNum}${isAnswered ? ' (Answered)' : ''}${isFlagged ? ' (Flagged)' : ''}`}
                >
                  {isFlagged && !isAnswered ? (
                    <Icon name="Flag" size={10} />
                  ) : (
                    questionNum
                  )}
                </button>
              );
            })}
          </div>
          
          {/* Legend */}
          <div className="flex items-center justify-center space-x-4 mt-3 text-xs font-caption">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded bg-success"></div>
              <span className="text-muted-foreground">Answered</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded bg-warning"></div>
              <span className="text-muted-foreground">Flagged</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded bg-primary"></div>
              <span className="text-muted-foreground">Current</span>
            </div>
          </div>
        </div>
      )}
      {/* Progress Insights */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center space-x-2 text-xs font-caption text-muted-foreground">
          <Icon name="TrendingUp" size={14} />
          <span>
            {progressPercentage < 25 ? 'Just getting started!' :
             progressPercentage < 50 ? 'Making good progress!' :
             progressPercentage < 75 ? 'More than halfway there!' :
             progressPercentage < 100 ? 'Almost finished!': 'Quiz completed!'}
          </span>
        </div>
        
        {flaggedCount > 0 && (
          <div className="flex items-center space-x-2 text-xs font-caption text-warning mt-1">
            <Icon name="Flag" size={14} />
            <span>
              {flaggedCount} question{flaggedCount > 1 ? 's' : ''} flagged for review
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizProgress;