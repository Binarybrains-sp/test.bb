import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const QuizQuestion = ({
  question,
  currentAnswer,
  onAnswerChange,
  onBookmark,
  isBookmarked = false,
  showExplanation = false,
  isReviewMode = false,
  questionNumber,
  totalQuestions
}) => {
  const renderQuestionContent = () => {
    switch (question?.type) {
      case 'mcq':
        return (
          <div className="space-y-3">
            {question?.options?.map((option, index) => (
              <label
                key={index}
                className={`
                  flex items-start space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all duration-200
                  ${currentAnswer === option?.id 
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 hover:bg-muted/50'
                  }
                  ${isReviewMode && option?.isCorrect ? 'border-success bg-success/5' : ''}
                  ${isReviewMode && currentAnswer === option?.id && !option?.isCorrect ? 'border-error bg-error/5' : ''}
                `}
              >
                <input
                  type="radio"
                  name={`question-${question?.id}`}
                  value={option?.id}
                  checked={currentAnswer === option?.id}
                  onChange={(e) => onAnswerChange(e?.target?.value)}
                  className="mt-1 w-4 h-4 text-primary border-border focus:ring-primary"
                  disabled={isReviewMode}
                />
                <div className="flex-1">
                  <span className="text-sm font-medium text-foreground">
                    {option?.text}
                  </span>
                  {option?.description && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {option?.description}
                    </p>
                  )}
                </div>
                {isReviewMode && option?.isCorrect && (
                  <Icon name="Check" size={16} className="text-success mt-1" />
                )}
                {isReviewMode && currentAnswer === option?.id && !option?.isCorrect && (
                  <Icon name="X" size={16} className="text-error mt-1" />
                )}
              </label>
            ))}
          </div>
        );

      case 'fill_blank':
        return (
          <div className="space-y-4">
            <div className="text-foreground leading-relaxed">
              {question?.text?.split('___')?.map((part, index) => (
                <React.Fragment key={index}>
                  {part}
                  {index < question?.blanks?.length && (
                    <Input
                      type="text"
                      value={currentAnswer?.[index] || ''}
                      onChange={(e) => {
                        const newAnswers = [...(currentAnswer || [])];
                        newAnswers[index] = e?.target?.value;
                        onAnswerChange(newAnswers);
                      }}
                      className="inline-block w-32 mx-2"
                      placeholder={`Blank ${index + 1}`}
                      disabled={isReviewMode}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>
            {isReviewMode && (
              <div className="mt-4 p-3 bg-muted rounded-lg">
                <p className="text-sm font-medium text-foreground mb-2">Correct answers:</p>
                <div className="space-y-1">
                  {question?.blanks?.map((blank, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <span className="text-xs text-muted-foreground">Blank {index + 1}:</span>
                      <span className="text-sm font-medium text-success">{blank?.correctAnswer}</span>
                      {currentAnswer?.[index] && currentAnswer?.[index] !== blank?.correctAnswer && (
                        <span className="text-sm text-error">(Your answer: {currentAnswer?.[index]})</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );

      case 'true_false':
        return (
          <div className="space-y-3">
            {['true', 'false']?.map((option) => (
              <label
                key={option}
                className={`
                  flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all duration-200
                  ${currentAnswer === option 
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 hover:bg-muted/50'
                  }
                  ${isReviewMode && question?.correctAnswer === option ? 'border-success bg-success/5' : ''}
                  ${isReviewMode && currentAnswer === option && question?.correctAnswer !== option ? 'border-error bg-error/5' : ''}
                `}
              >
                <input
                  type="radio"
                  name={`question-${question?.id}`}
                  value={option}
                  checked={currentAnswer === option}
                  onChange={(e) => onAnswerChange(e?.target?.value)}
                  className="w-4 h-4 text-primary border-border focus:ring-primary"
                  disabled={isReviewMode}
                />
                <span className="text-sm font-medium text-foreground capitalize">
                  {option}
                </span>
                {isReviewMode && question?.correctAnswer === option && (
                  <Icon name="Check" size={16} className="text-success ml-auto" />
                )}
                {isReviewMode && currentAnswer === option && question?.correctAnswer !== option && (
                  <Icon name="X" size={16} className="text-error ml-auto" />
                )}
              </label>
            ))}
          </div>
        );

      case 'multiple_select':
        return (
          <div className="space-y-3">
            {question?.options?.map((option, index) => (
              <div
                key={index}
                className={`
                  p-4 rounded-lg border-2 transition-all duration-200
                  ${(currentAnswer || [])?.includes(option?.id) 
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 hover:bg-muted/50'
                  }
                  ${isReviewMode && option?.isCorrect ? 'border-success bg-success/5' : ''}
                  ${isReviewMode && (currentAnswer || [])?.includes(option?.id) && !option?.isCorrect ? 'border-error bg-error/5' : ''}
                `}
              >
                <Checkbox
                  label={option?.text}
                  checked={(currentAnswer || [])?.includes(option?.id)}
                  onChange={(e) => {
                    const newAnswers = currentAnswer || [];
                    if (e?.target?.checked) {
                      onAnswerChange([...newAnswers, option?.id]);
                    } else {
                      onAnswerChange(newAnswers?.filter(id => id !== option?.id));
                    }
                  }}
                  disabled={isReviewMode}
                />
                {option?.description && (
                  <p className="text-xs text-muted-foreground mt-2 ml-6">
                    {option?.description}
                  </p>
                )}
                <div className="flex items-center justify-end mt-2">
                  {isReviewMode && option?.isCorrect && (
                    <Icon name="Check" size={16} className="text-success" />
                  )}
                  {isReviewMode && (currentAnswer || [])?.includes(option?.id) && !option?.isCorrect && (
                    <Icon name="X" size={16} className="text-error" />
                  )}
                </div>
              </div>
            ))}
          </div>
        );

      default:
        return (
          <div className="text-center py-8">
            <Icon name="AlertCircle" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Unsupported question type</p>
          </div>
        );
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      {/* Question Header */}
      <div className="flex items-start justify-between mb-6">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-sm font-caption text-muted-foreground">
              Question {questionNumber} of {totalQuestions}
            </span>
            <div className="w-2 h-2 rounded-full bg-primary"></div>
            <span className="text-sm font-caption text-primary capitalize">
              {question?.type?.replace('_', ' ')}
            </span>
            {question?.difficulty && (
              <>
                <div className="w-2 h-2 rounded-full bg-muted-foreground"></div>
                <span className={`text-sm font-caption capitalize ${
                  question?.difficulty === 'easy' ? 'text-success' :
                  question?.difficulty === 'medium' ? 'text-warning' : 'text-error'
                }`}>
                  {question?.difficulty}
                </span>
              </>
            )}
          </div>
          <h2 className="text-lg font-heading font-semibold text-foreground leading-relaxed">
            {question?.question}
          </h2>
          {question?.description && (
            <p className="text-sm text-muted-foreground mt-2">
              {question?.description}
            </p>
          )}
        </div>
        
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onBookmark(question?.id)}
          className={`ml-4 ${isBookmarked ? 'text-warning' : 'text-muted-foreground'}`}
        >
          <Icon name={isBookmarked ? 'Bookmark' : 'BookmarkPlus'} size={20} />
        </Button>
      </div>
      {/* Question Content */}
      <div className="mb-6">
        {renderQuestionContent()}
      </div>
      {/* Question Image */}
      {question?.image && (
        <div className="mb-6">
          <div className="rounded-lg overflow-hidden border border-border">
            <img
              src={question?.image}
              alt="Question illustration"
              className="w-full h-auto max-h-64 object-contain bg-muted"
              onError={(e) => {
                e.target.src = '/assets/images/no_image.png';
              }}
            />
          </div>
        </div>
      )}
      {/* Explanation */}
      {showExplanation && question?.explanation && (
        <div className="mt-6 p-4 bg-muted/50 rounded-lg border border-border">
          <div className="flex items-start space-x-2 mb-2">
            <Icon name="Lightbulb" size={16} className="text-warning mt-1" />
            <h4 className="text-sm font-heading font-semibold text-foreground">
              Explanation
            </h4>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {question?.explanation}
          </p>
          
          {question?.eli5Explanation && (
            <div className="mt-3 pt-3 border-t border-border">
              <div className="flex items-start space-x-2 mb-2">
                <Icon name="Baby" size={16} className="text-primary mt-1" />
                <h5 className="text-sm font-heading font-medium text-foreground">
                  ELI5 (Explain Like I'm 5)
                </h5>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {question?.eli5Explanation}
              </p>
            </div>
          )}
        </div>
      )}
      {/* Question Tags */}
      {question?.tags && question?.tags?.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {question?.tags?.map((tag, index) => (
            <span
              key={index}
              className="px-2 py-1 text-xs font-caption bg-muted text-muted-foreground rounded-md"
            >
              {tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
};

export default QuizQuestion;