import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import StudySessionHeader from '../../components/ui/StudySessionHeader';
import QuizNavigationPanel from '../../components/ui/QuizNavigationPanel';
import ProgressNotificationSystem from '../../components/ui/ProgressNotificationSystem';
import QuizQuestion from './components/QuizQuestion';
import QuizTimer from './components/QuizTimer';
import QuizProgress from './components/QuizProgress';
import QuizControls from './components/QuizControls';
import QuizResults from './components/QuizResults';

const QuizInterface = () => {
  const navigate = useNavigate();
  
  // Quiz State
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [flaggedQuestions, setFlaggedQuestions] = useState([]);
  const [isQuizCompleted, setIsQuizCompleted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [showNavigationPanel, setShowNavigationPanel] = useState(false);
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [timeSpent, setTimeSpent] = useState(0);
  const [notifications, setNotifications] = useState([]);

  // Mock Quiz Data
  const quizData = {
    id: 'quiz_001',
    title: 'Physics - Motion and Forces',
    description: 'Test your understanding of motion, velocity, acceleration, and Newton\'s laws',
    duration: 3600, // 60 minutes
    totalQuestions: 15,
    passingScore: 70,
    questions: [
      {
        id: 'q1',
        type: 'mcq',
        question: 'What is the SI unit of force?',
        description: 'Choose the correct unit for measuring force in the International System of Units.',
        options: [
          { id: 'a', text: 'Newton (N)', isCorrect: true },
          { id: 'b', text: 'Joule (J)', isCorrect: false },
          { id: 'c', text: 'Watt (W)', isCorrect: false },
          { id: 'd', text: 'Pascal (Pa)', isCorrect: false }
        ],
        difficulty: 'easy',
        tags: ['units', 'force', 'SI system'],
        explanation: `The Newton (N) is the SI unit of force. It is defined as the force required to accelerate a mass of one kilogram at a rate of one meter per second squared.`,
        eli5Explanation: `Think of force like a push or pull. The Newton is just the name we give to measure how strong that push or pull is, like how we use "meters" to measure distance.`
      },
      {
        id: 'q2',
        type: 'fill_blank',
        question: 'Newton\'s first law states that an object at rest stays at ___ and an object in motion stays in ___ unless acted upon by an external force.',
        text: 'Newton\'s first law states that an object at rest stays at ___ and an object in motion stays in ___ unless acted upon by an external force.',
        blanks: [
          { correctAnswer: 'rest', alternatives: ['stationary', 'still'] },
          { correctAnswer: 'motion', alternatives: ['movement', 'moving'] }
        ],
        difficulty: 'medium',
        tags: ['Newton\'s laws', 'inertia'],
        explanation: `Newton's first law, also known as the law of inertia, describes the tendency of objects to maintain their current state of motion unless a force acts upon them.`,
        eli5Explanation: `Imagine a ball on a table. It won't move by itself (stays at rest). If you roll it, it would keep rolling forever if nothing stopped it (stays in motion). But things like friction make it stop.`
      },
      {
        id: 'q3',
        type: 'true_false',
        question: 'Acceleration is the rate of change of velocity.',
        correctAnswer: 'true',
        difficulty: 'easy',
        tags: ['acceleration', 'velocity', 'definitions'],
        explanation: `This is true. Acceleration is defined as the rate of change of velocity with respect to time. It can be positive (speeding up), negative (slowing down), or involve a change in direction.`,
        eli5Explanation: `Acceleration is like how fast you speed up or slow down. When you press the gas pedal in a car, you accelerate (speed up). When you press the brake, you decelerate (slow down).`
      },
      {
        id: 'q4',
        type: 'mcq',
        question: 'A car travels 100 meters in 10 seconds. What is its average speed?',
        options: [
          { id: 'a', text: '5 m/s', isCorrect: false },
          { id: 'b', text: '10 m/s', isCorrect: true },
          { id: 'c', text: '15 m/s', isCorrect: false },
          { id: 'd', text: '20 m/s', isCorrect: false }
        ],
        difficulty: 'medium',
        tags: ['speed', 'calculation', 'kinematics'],
        explanation: `Average speed = Distance ÷ Time = 100 meters ÷ 10 seconds = 10 m/s. This is a straightforward application of the speed formula.`,
        eli5Explanation: `Speed is how far you go divided by how long it takes. The car went 100 meters in 10 seconds, so 100 ÷ 10 = 10 meters per second.`
      },
      {
        id: 'q5',
        type: 'multiple_select',
        question: 'Which of the following are examples of contact forces?',
        description: 'Select all forces that require physical contact between objects.',
        options: [
          { id: 'a', text: 'Friction', isCorrect: true },
          { id: 'b', text: 'Gravitational force', isCorrect: false },
          { id: 'c', text: 'Normal force', isCorrect: true },
          { id: 'd', text: 'Magnetic force', isCorrect: false },
          { id: 'e', text: 'Tension', isCorrect: true }
        ],
        difficulty: 'medium',
        tags: ['forces', 'contact forces', 'non-contact forces'],
        explanation: `Contact forces require physical contact: friction (surfaces touching), normal force (objects pressing against each other), and tension (rope/string pulling). Gravitational and magnetic forces act at a distance.`,
        eli5Explanation: `Contact forces are like when you push a door (you touch it) or when your shoes grip the ground (they touch). Gravity pulls you down without touching you, so it's not a contact force.`
      },
      {
        id: 'q6',type: 'mcq',question: 'According to Newton\'s second law, if the mass of an object doubles while the force remains constant, what happens to the acceleration?',
        options: [
          { id: 'a', text: 'It doubles', isCorrect: false },
          { id: 'b', text: 'It halves', isCorrect: true },
          { id: 'c', text: 'It remains the same', isCorrect: false },
          { id: 'd', text: 'It quadruples', isCorrect: false }
        ],
        difficulty: 'hard',
        tags: ['Newton\'s second law', 'mass', 'acceleration'],
        explanation: `Newton's second law: F = ma. If mass doubles and force stays constant, then a = F/(2m) = (1/2)(F/m). The acceleration is halved.`,
        eli5Explanation: `Think of pushing a shopping cart. An empty cart (less mass) speeds up quickly. A full cart (more mass) with the same push speeds up slowly. Double the weight, half the acceleration.`
      },
      {
        id: 'q7',type: 'fill_blank',question: 'The formula for calculating kinetic energy is KE = ___ × m × v², where m is mass and v is velocity.',text: 'The formula for calculating kinetic energy is KE = ___ × m × v², where m is mass and v is velocity.',
        blanks: [
          { correctAnswer: '1/2', alternatives: ['0.5', 'half'] }
        ],
        difficulty: 'medium',
        tags: ['kinetic energy', 'formula', 'energy'],
        explanation: `The kinetic energy formula is KE = ½mv². The factor of ½ comes from the integration of force over distance in the derivation of the work-energy theorem.`,
        eli5Explanation: `Kinetic energy is the energy of movement. The formula has a ½ in front because of how the math works out when we calculate how much energy a moving object has.`
      },
      {
        id: 'q8',type: 'true_false',question: 'An object can have zero velocity but non-zero acceleration.',correctAnswer: 'true',
        difficulty: 'hard',
        tags: ['velocity', 'acceleration', 'motion'],
        explanation: `This is true. At the highest point of a thrown ball's trajectory, its velocity is zero (momentarily), but it still has acceleration due to gravity (9.8 m/s² downward).`,
        eli5Explanation: `Imagine throwing a ball up. At the very top, it stops moving for just a moment (zero velocity), but gravity is still pulling it down (acceleration). Then it starts falling.`
      },
      {
        id: 'q9',
        type: 'mcq',
        question: 'What is the acceleration due to gravity on Earth?',
        options: [
          { id: 'a', text: '9.8 m/s²', isCorrect: true },
          { id: 'b', text: '10.8 m/s²', isCorrect: false },
          { id: 'c', text: '8.8 m/s²', isCorrect: false },
          { id: 'd', text: '11.8 m/s²', isCorrect: false }
        ],
        difficulty: 'easy',
        tags: ['gravity', 'acceleration', 'Earth'],
        explanation: `The standard acceleration due to gravity on Earth is approximately 9.8 m/s² or 9.81 m/s² for more precision. This value can vary slightly with location.`,
        eli5Explanation: `Gravity makes things fall faster and faster. On Earth, every second an object falls, it gets about 9.8 meters per second faster. That's why things speed up when they fall.`
      },
      {
        id: 'q10',type: 'multiple_select',question: 'Which of the following quantities are vectors?',description: 'Select all quantities that have both magnitude and direction.',
        options: [
          { id: 'a', text: 'Velocity', isCorrect: true },
          { id: 'b', text: 'Speed', isCorrect: false },
          { id: 'c', text: 'Displacement', isCorrect: true },
          { id: 'd', text: 'Distance', isCorrect: false },
          { id: 'e', text: 'Acceleration', isCorrect: true },
          { id: 'f', text: 'Mass', isCorrect: false }
        ],
        difficulty: 'medium',
        tags: ['vectors', 'scalars', 'physics quantities'],
        explanation: `Vectors have both magnitude and direction: velocity (speed + direction), displacement (distance + direction), and acceleration (rate of change + direction). Scalars have only magnitude.`,
        eli5Explanation: `Vectors are like giving directions: "Go 5 miles north" (displacement) or "Drive 60 mph toward the school" (velocity). Scalars are just amounts: "5 miles" or "60 mph" without saying which way.`
      },
      {
        id: 'q11',type: 'fill_blank',question: 'Newton\'s third law states that for every action, there is an equal and ___ reaction.',
        text: 'Newton\'s third law states that for every action, there is an equal and ___ reaction.',
        blanks: [
          { correctAnswer: 'opposite', alternatives: ['opposing', 'reverse'] }
        ],
        difficulty: 'easy',
        tags: ['Newton\'s third law', 'action-reaction'],
        explanation: `Newton's third law states that forces always come in pairs. When object A exerts a force on object B, object B exerts an equal and opposite force on object A.`,
        eli5Explanation: `When you push against a wall, the wall pushes back on you with the same force. When you walk, you push back on the ground, and the ground pushes you forward. That's action and reaction.`
      },
      {
        id: 'q12',
        type: 'mcq',
        question: 'A 5 kg object experiences a net force of 20 N. What is its acceleration?',
        options: [
          { id: 'a', text: '2 m/s²', isCorrect: false },
          { id: 'b', text: '4 m/s²', isCorrect: true },
          { id: 'c', text: '6 m/s²', isCorrect: false },
          { id: 'd', text: '8 m/s²', isCorrect: false }
        ],
        difficulty: 'medium',
        tags: ['Newton\'s second law', 'calculation', 'force'],
        explanation: `Using Newton's second law: F = ma, so a = F/m = 20 N / 5 kg = 4 m/s². This is a direct application of the formula.`,
        eli5Explanation: `Newton's second law is like a recipe: Force = mass × acceleration. We know the force (20 N) and mass (5 kg), so acceleration = 20 ÷ 5 = 4 m/s².`
      },
      {
        id: 'q13',
        type: 'true_false',
        question: 'Friction always opposes motion.',
        correctAnswer: 'false',
        difficulty: 'hard',
        tags: ['friction', 'motion'],
        explanation: `This is false. While kinetic friction opposes motion, static friction can actually enable motion. For example, friction between your shoes and the ground allows you to walk forward.`,
        eli5Explanation: `Usually friction slows things down, like when you slide on the floor. But sometimes friction helps you move, like when your shoes grip the ground so you can walk without slipping.`
      },
      {
        id: 'q14',
        type: 'mcq',
        question: 'What happens to the gravitational force between two objects if the distance between them is doubled?',
        options: [
          { id: 'a', text: 'It doubles', isCorrect: false },
          { id: 'b', text: 'It halves', isCorrect: false },
          { id: 'c', text: 'It becomes one-fourth', isCorrect: true },
          { id: 'd', text: 'It becomes four times stronger', isCorrect: false }
        ],
        difficulty: 'hard',
        tags: ['gravity', 'inverse square law', 'distance'],
        explanation: `Gravitational force follows an inverse square law: F ∝ 1/r². If distance doubles, force becomes 1/(2²) = 1/4 of the original value.`,
        eli5Explanation: `Gravity gets weaker quickly as things get farther apart. If you double the distance, gravity becomes 4 times weaker. It's like how a flashlight gets much dimmer when you move it away.`
      },
      {
        id: 'q15',type: 'multiple_select',question: 'Which of the following are examples of Newton\'s first law (inertia)?',
        description: 'Select all scenarios that demonstrate the law of inertia.',
        options: [
          { id: 'a', text: 'A passenger lurches forward when a car brakes suddenly', isCorrect: true },
          { id: 'b', text: 'A ball rolling on grass gradually slows down', isCorrect: false },
          { id: 'c', text: 'A book remains on a table until someone moves it', isCorrect: true },
          { id: 'd', text: 'A satellite orbits Earth at constant speed', isCorrect: false },
          { id: 'e', text: 'Your body presses against the car door when turning', isCorrect: true }
        ],
        difficulty: 'medium',
        tags: ['Newton\'s first law', 'inertia', 'examples'],
        explanation: `Newton's first law examples: passenger continues forward motion when car stops (a), book stays at rest (c), body continues straight when car turns (e). Options b and d involve forces acting.`,
        eli5Explanation: `Inertia means things want to keep doing what they're already doing. If you're moving, you want to keep moving. If you're still, you want to stay still. That's why you slide forward when a car stops suddenly.`
      }
    ]
  };

  // Quiz Logic
  const currentQuestionData = quizData?.questions?.[currentQuestion];
  const answeredQuestions = Object.keys(answers)?.map(q => parseInt(q) + 1);
  const totalQuestions = quizData?.questions?.length;

  useEffect(() => {
    // Timer logic
    if (!isPaused && !isQuizCompleted) {
      const timer = setInterval(() => {
        setTimeSpent(prev => prev + 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isPaused, isQuizCompleted]);

  const handleAnswerChange = (answer) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion]: answer
    }));
  };

  const handleBookmark = (questionId) => {
    const questionIndex = currentQuestion + 1;
    setFlaggedQuestions(prev => 
      prev?.includes(questionIndex) 
        ? prev?.filter(q => q !== questionIndex)
        : [...prev, questionIndex]
    );
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const handleQuestionSelect = (questionIndex) => {
    setCurrentQuestion(questionIndex);
    setShowNavigationPanel(false);
  };

  const handleSubmitQuiz = () => {
    setIsQuizCompleted(true);
    
    // Add completion notification
    const completionNotification = {
      id: Date.now(),
      type: 'achievement',
      title: 'Quiz Completed!',
      message: 'Great job finishing the Physics quiz. Check your results below.',
      details: {
        points: 25,
        level: 'Quiz Master'
      },
      duration: 5000
    };
    
    setNotifications(prev => [...prev, completionNotification]);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleTimeUp = () => {
    setIsQuizCompleted(true);
    
    const timeUpNotification = {
      id: Date.now(),
      type: 'warning',
      title: 'Time\'s Up!',
      message: 'The quiz time has expired. Your answers have been automatically submitted.',
      duration: 5000
    };
    
    setNotifications(prev => [...prev, timeUpNotification]);
  };

  const handleReviewMode = () => {
    setIsReviewMode(true);
  };

  const handleExitQuiz = () => {
    if (window.confirm('Are you sure you want to exit the quiz? Your progress will be lost.')) {
      navigate('/dashboard');
    }
  };

  const calculateResults = () => {
    let correctCount = 0;
    const wrongAnswers = [];
    const subjectBreakdown = {};

    quizData?.questions?.forEach((question, index) => {
      const userAnswer = answers?.[index];
      let isCorrect = false;

      // Check answer based on question type
      switch (question?.type) {
        case 'mcq':
          isCorrect = question?.options?.find(opt => opt?.id === userAnswer)?.isCorrect || false;
          break;
        case 'true_false':
          isCorrect = userAnswer === question?.correctAnswer;
          break;
        case 'fill_blank':
          isCorrect = question?.blanks?.every((blank, blankIndex) => {
            const userBlankAnswer = userAnswer?.[blankIndex]?.toLowerCase()?.trim();
            return userBlankAnswer === blank?.correctAnswer?.toLowerCase() || 
                   blank?.alternatives?.some(alt => alt?.toLowerCase() === userBlankAnswer);
          });
          break;
        case 'multiple_select':
          const correctIds = question?.options?.filter(opt => opt?.isCorrect)?.map(opt => opt?.id);
          const userIds = userAnswer || [];
          isCorrect = correctIds?.length === userIds?.length && 
                     correctIds?.every(id => userIds?.includes(id));
          break;
      }

      if (isCorrect) {
        correctCount++;
      } else if (userAnswer !== undefined) {
        wrongAnswers?.push({
          questionNumber: index + 1,
          question: question?.question,
          userAnswer: formatUserAnswer(question, userAnswer),
          correctAnswer: formatCorrectAnswer(question),
          explanation: question?.explanation
        });
      }

      // Subject breakdown
      const subject = question?.tags?.[0] || 'General';
      if (!subjectBreakdown?.[subject]) {
        subjectBreakdown[subject] = { correct: 0, total: 0 };
      }
      subjectBreakdown[subject].total++;
      if (isCorrect) {
        subjectBreakdown[subject].correct++;
      }
    });

    return {
      correctAnswers: correctCount,
      wrongAnswers,
      subjectBreakdown: Object.entries(subjectBreakdown)?.map(([name, data]) => ({
        name,
        ...data
      }))
    };
  };

  const formatUserAnswer = (question, answer) => {
    switch (question?.type) {
      case 'mcq':
        return question?.options?.find(opt => opt?.id === answer)?.text || 'No answer';
      case 'true_false':
        return answer || 'No answer';
      case 'fill_blank':
        return Array.isArray(answer) ? answer?.join(', ') : 'No answer';
      case 'multiple_select':
        return Array.isArray(answer) 
          ? question?.options?.filter(opt => answer?.includes(opt?.id))?.map(opt => opt?.text)?.join(', ')
          : 'No answer';
      default:
        return 'No answer';
    }
  };

  const formatCorrectAnswer = (question) => {
    switch (question?.type) {
      case 'mcq':
        return question?.options?.find(opt => opt?.isCorrect)?.text || '';
      case 'true_false':
        return question?.correctAnswer;
      case 'fill_blank':
        return question?.blanks?.map(blank => blank?.correctAnswer)?.join(', ');
      case 'multiple_select':
        return question?.options?.filter(opt => opt?.isCorrect)?.map(opt => opt?.text)?.join(', ');
      default:
        return '';
    }
  };

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const handleDismissNotification = (id) => {
    setNotifications(prev => prev?.filter(n => n?.id !== id));
  };

  if (isQuizCompleted) {
    const results = calculateResults();
    
    return (
      <>
        <Header />
        <QuizResults
          score={Math.round((results?.correctAnswers / totalQuestions) * 100)}
          totalQuestions={totalQuestions}
          correctAnswers={results?.correctAnswers}
          timeSpent={formatTime(timeSpent)}
          subjectBreakdown={results?.subjectBreakdown}
          wrongAnswers={results?.wrongAnswers}
          onReviewAnswers={() => setIsReviewMode(true)}
          onRetakeQuiz={() => window.location?.reload()}
          onBackToDashboard={() => navigate('/dashboard')}
          onShareResults={() => {
            // Mock share functionality
            navigator.share?.({
              title: 'My Quiz Results',
              text: `I scored ${Math.round((results?.correctAnswers / totalQuestions) * 100)}% on the Physics quiz!`,
              url: window.location?.href
            });
          }}
        />
        <ProgressNotificationSystem
          notifications={notifications}
          onDismiss={handleDismissNotification}
          onViewDetails={() => {}}
          position="top-right"
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <StudySessionHeader
        currentCard={currentQuestion + 1}
        totalCards={totalQuestions}
        sessionType="quiz"
        onExit={handleExitQuiz}
        onPause={handlePause}
        onSettings={() => {}}
        isPaused={isPaused}
        timeElapsed={formatTime(timeSpent)}
        streakCount={answeredQuestions?.length}
      />
      <div className="pt-32 pb-20 lg:pr-80">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          {/* Quiz Header */}
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h1 className="text-2xl font-heading font-bold text-card-foreground mb-2">
                  {quizData?.title}
                </h1>
                <p className="text-muted-foreground">
                  {quizData?.description}
                </p>
              </div>
              
              <div className="ml-6">
                <QuizTimer
                  totalTime={quizData?.duration}
                  onTimeUp={handleTimeUp}
                  isPaused={isPaused}
                />
              </div>
            </div>

            <QuizProgress
              currentQuestion={currentQuestion + 1}
              totalQuestions={totalQuestions}
              answeredQuestions={answeredQuestions}
              flaggedQuestions={flaggedQuestions}
              onQuestionJump={handleQuestionSelect}
            />
          </div>

          {/* Question */}
          <QuizQuestion
            question={currentQuestionData}
            currentAnswer={answers?.[currentQuestion]}
            onAnswerChange={handleAnswerChange}
            onBookmark={handleBookmark}
            isBookmarked={flaggedQuestions?.includes(currentQuestion + 1)}
            showExplanation={isReviewMode}
            isReviewMode={isReviewMode}
            questionNumber={currentQuestion + 1}
            totalQuestions={totalQuestions}
          />
        </div>
      </div>
      {/* Quiz Controls */}
      <QuizControls
        currentQuestion={currentQuestion + 1}
        totalQuestions={totalQuestions}
        onPrevious={handlePrevious}
        onNext={handleNext}
        onSubmit={handleSubmitQuiz}
        onPause={handlePause}
        onBookmark={handleBookmark}
        onReview={() => setShowNavigationPanel(true)}
        isPaused={isPaused}
        isBookmarked={flaggedQuestions?.includes(currentQuestion + 1)}
        canGoNext={currentQuestion < totalQuestions - 1}
        canGoPrevious={currentQuestion > 0}
        showSubmit={currentQuestion === totalQuestions - 1}
        answeredQuestions={answeredQuestions}
        flaggedQuestions={flaggedQuestions}
      />
      {/* Navigation Panel */}
      <QuizNavigationPanel
        questions={quizData?.questions}
        currentQuestion={currentQuestion}
        answeredQuestions={answeredQuestions}
        flaggedQuestions={flaggedQuestions}
        onQuestionSelect={handleQuestionSelect}
        onToggleFlag={(questionIndex) => {
          const questionNum = questionIndex + 1;
          setFlaggedQuestions(prev => 
            prev?.includes(questionNum) 
              ? prev?.filter(q => q !== questionNum)
              : [...prev, questionNum]
          );
        }}
        onSubmitQuiz={handleSubmitQuiz}
        onReviewMode={handleReviewMode}
        isReviewMode={isReviewMode}
        timeRemaining={formatTime(quizData?.duration - timeSpent)}
        isVisible={true}
        onTogglePanel={() => setShowNavigationPanel(!showNavigationPanel)}
      />
      {/* Notifications */}
      <ProgressNotificationSystem
        notifications={notifications}
        onDismiss={handleDismissNotification}
        onViewDetails={() => {}}
        position="top-right"
      />
    </div>
  );
};

export default QuizInterface;